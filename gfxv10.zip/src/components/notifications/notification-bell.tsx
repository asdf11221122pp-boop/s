'use client'

import { useState, useEffect, useRef } from 'react'
import { useSession } from 'next-auth/react'
import { io, Socket } from 'socket.io-client'
import { Bell, X, Check, CheckCheck } from 'lucide-react'
import { Button } from '@/components/ui/button'

interface Notification {
  id: string
  title: string
  content: string
  type: string
  isRead: boolean
  createdAt: string
  itemId?: string
}

export function NotificationBell() {
  const { data: session } = useSession()
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [unreadCount, setUnreadCount] = useState(0)
  const [isOpen, setIsOpen] = useState(false)
  const socketRef = useRef<Socket | null>(null)
  const dropdownRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!session?.user || typeof window === 'undefined') return

    fetchNotifications()

    try {
      const notifSocket = io(`${window.location.origin}/notifications`, {
        path: '/socket.io/',
        transports: ['websocket', 'polling'],
        auth: {
          userId: session.user.id,
          sessionId: session.user.id
        }
      })

      notifSocket.on('connect', () => {
        console.log('✅ Notification bell connected')
      })

      notifSocket.on('notification', (notification: Notification) => {
        setNotifications(prev => [notification, ...prev].slice(0, 20))
        setUnreadCount(prev => prev + 1)
      })

      notifSocket.on('notifications', (notifs: Notification[]) => {
        setNotifications(notifs)
        setUnreadCount(notifs.filter(n => !n.isRead).length)
      })

      socketRef.current = notifSocket

      return () => {
        notifSocket.disconnect()
      }
    } catch (error) {
      console.error('Failed to connect to notifications:', error)
    }
  }, [session?.user])

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false)
      }
    }
    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setIsOpen(false)
    }
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside)
      document.addEventListener('keydown', handleEscape)
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside)
      document.removeEventListener('keydown', handleEscape)
    }
  }, [isOpen])

  const fetchNotifications = async () => {
    try {
      const response = await fetch('/api/notifications?limit=20')
      if (response.ok) {
        const data = await response.json()
        setNotifications(data.notifications)
        setUnreadCount(data.unreadCount)
      }
    } catch (error) {
      console.error('Failed to fetch notifications:', error)
    }
  }

  const markAsRead = async (notificationId: string) => {
    try {
      await fetch(`/api/notifications?id=${notificationId}`, { method: 'PATCH' })
      setNotifications(prev =>
        prev.map(n => n.id === notificationId ? { ...n, isRead: true } : n)
      )
      setUnreadCount(prev => Math.max(0, prev - 1))
    } catch (error) {
      console.error('Failed to mark as read:', error)
    }
  }

  const markAllRead = async () => {
    try {
      await fetch('/api/notifications?readAll=true', { method: 'PATCH' })
      setNotifications(prev => prev.map(n => ({ ...n, isRead: true })))
      setUnreadCount(0)
    } catch (error) {
      console.error('Failed to mark all as read:', error)
    }
  }

  const getNotificationIcon = (type: string) => {
    const icons: { [key: string]: string } = {
      ITEM_APPROVED: '✅',
      ITEM_REJECTED: '❌',
      ITEM_LIKED: '❤️',
      NEW_REVIEW: '⭐',
      TRANSACTION_APPROVED: '💰',
      DEPOSIT_APPROVED: '💰',
      NEW_MESSAGE: '💬',
      USER_MENTIONED: '👋',
      ADMIN_ANNOUNCEMENT: '📢',
      SYSTEM_ANNOUNCEMENT: '📣',
      DOWNLOAD_COMPLETE: '⬇️'
    }
    return icons[type] || '🔔'
  }

  const timeAgo = (dateStr: string) => {
    const seconds = Math.floor((Date.now() - new Date(dateStr).getTime()) / 1000)
    if (seconds < 60) return 'just now'
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`
    if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`
    return `${Math.floor(seconds / 86400)}d ago`
  }

  if (!session?.user) return null

  return (
    <div className="relative" ref={dropdownRef}>
      <Button
        variant="ghost"
        size="icon"
        onClick={() => setIsOpen(!isOpen)}
        className="relative hover:bg-white/10 rounded-xl"
      >
        <Bell className="h-5 w-5 text-white/60" />
        {unreadCount > 0 && (
          <span className="absolute -top-0.5 -right-0.5 bg-red-500 text-white text-[10px] font-bold rounded-full min-w-[18px] h-[18px] flex items-center justify-center px-1">
            {unreadCount > 99 ? '99+' : unreadCount}
          </span>
        )}
      </Button>

      {isOpen && (
        <>
          <div className="fixed inset-0 z-[9998]" onClick={() => setIsOpen(false)} />
          <div className="fixed right-4 top-16 w-80 sm:w-96 bg-[#0f0f1a] border border-white/10 rounded-2xl shadow-2xl shadow-black/50 z-[9999] overflow-hidden">
          <div className="p-4 border-b border-white/5 flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-white">Notifications</h3>
              {unreadCount > 0 && <p className="text-[10px] text-white/30 mt-0.5">{unreadCount} unread</p>}
            </div>
            <div className="flex items-center gap-1">
              {unreadCount > 0 && (
                <Button variant="ghost" size="sm" onClick={markAllRead} className="text-[10px] text-purple-400 hover:text-purple-300 hover:bg-purple-500/10 h-7 px-2 rounded-lg">
                  <CheckCheck className="h-3 w-3 mr-1" />
                  Read all
                </Button>
              )}
              <Button variant="ghost" size="icon" onClick={() => setIsOpen(false)} className="h-7 w-7 hover:bg-white/10 rounded-lg">
                <X className="h-3.5 w-3.5 text-white/40" />
              </Button>
            </div>
          </div>
          <div className="max-h-80 overflow-y-auto">
            {notifications.length === 0 ? (
              <div className="py-12 text-center">
                <Bell className="w-8 h-8 mx-auto text-white/10 mb-2" />
                <p className="text-sm text-white/30">No notifications yet</p>
              </div>
            ) : (
              notifications.map(notif => (
                <div
                  key={notif.id}
                  className={`px-4 py-3 border-b border-white/[0.03] cursor-pointer transition-colors hover:bg-white/[0.03] ${!notif.isRead ? 'bg-purple-500/[0.03]' : ''}`}
                  onClick={() => {
                    if (!notif.isRead) markAsRead(notif.id)
                    // Navigate to item if notification has itemId
                    if (notif.itemId) {
                      window.location.href = `/items/${notif.itemId}`
                    }
                  }}
                >
                  <div className="flex items-start gap-3">
                    <span className="text-lg mt-0.5 flex-shrink-0">{getNotificationIcon(notif.type)}</span>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium text-white/80 line-clamp-1">{notif.title}</p>
                      <p className="text-[11px] text-white/40 line-clamp-2 mt-0.5">{notif.content}</p>
                      <p className="text-[10px] text-white/20 mt-1">{timeAgo(notif.createdAt)}</p>
                    </div>
                    {!notif.isRead && (
                      <div className="w-2 h-2 bg-purple-400 rounded-full mt-1.5 flex-shrink-0" />
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
          </div>
        </>
      )}
    </div>
  )
}
