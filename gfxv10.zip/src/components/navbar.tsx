'use client'

import Link from 'next/link'
import { useSession, signOut } from 'next-auth/react'
import { Button } from '@/components/ui/button'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuSeparator, DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Input } from '@/components/ui/input'
import {
  Upload, User, LogOut, Settings, Package, Wallet, Server,
  MessageCircle, Search, Heart, ShoppingCart, Zap, LayoutDashboard,
  Crown, Menu, X, Bell, Users, Users2, Home, Grid3X3, Gift, Briefcase,
  CalendarDays, Award, Handshake, ChevronRight, ArrowRight, Code2, Play
} from 'lucide-react'
import { useState, useEffect } from 'react'
import { NotificationBell } from '@/components/notifications/notification-bell'
import { FriendRequestPanel } from '@/components/messaging/friend-request-panel'
import { DepositModal } from './deposit-modal'
import { useRouter, usePathname } from 'next/navigation'

interface NavbarProps { onChatToggle?: () => void }

export function Navbar({ onChatToggle }: NavbarProps) {
  const { data: session } = useSession()
  const [balance, setBalance] = useState(0)
  const [showDepositModal, setShowDepositModal] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)
  const [cartCount, setCartCount] = useState(0)
  const [wishlistCount, setWishlistCount] = useState(0)
  const [searchQuery, setSearchQuery] = useState('')
  const [showAnn, setShowAnn] = useState(true)
  const router = useRouter()
  const pathname = usePathname()

  useEffect(() => {
    if (session?.user?.id) {
      fetchBalance(); fetchCartCount(); fetchWishlistCount()
      const interval = setInterval(fetchBalance, 30000)
      return () => clearInterval(interval)
    }
  }, [session?.user?.id])

  useEffect(() => { setMobileOpen(false) }, [pathname])

  const fetchBalance = async () => {
    try { const r = await fetch('/api/users/me'); if (r.ok) { const d = await r.json(); setBalance(d.walletBalance || 0) } } catch {}
  }
  const fetchCartCount = async () => {
    try { const r = await fetch('/api/cart'); if (r.ok) { const d = await r.json(); setCartCount(d.count || 0) } } catch {}
  }
  const fetchWishlistCount = async () => {
    try { const r = await fetch('/api/wishlist'); if (r.ok) { const d = await r.json(); setWishlistCount(d.wishlist?.length || 0) } } catch {}
  }

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim()) { router.push(`/browse?q=${encodeURIComponent(searchQuery.trim())}`); setMobileOpen(false) }
  }

  const isAdmin = session?.user?.role === 'ADMIN' || session?.user?.role === 'SUPER_ADMIN'

  const navLinks = [
    { href: '/browse', label: 'Browse', icon: <Grid3X3 className="w-4 h-4" /> },
    { href: '/watch', label: 'Watch', icon: <Play className="w-4 h-4" /> },
    { href: '/apps', label: 'Apps', icon: <Package className="w-4 h-4" /> },
    { href: '/code', label: 'Code', icon: <Code2 className="w-4 h-4" /> },
    { href: '/ai', label: 'AI', icon: <Zap className="w-4 h-4" /> },
    { href: '/memberships', label: 'Memberships', icon: <Crown className="w-4 h-4" /> },
    { href: '/freebies', label: 'Freebies', icon: <Gift className="w-4 h-4" /> },
    { href: '/categories', label: 'Categories', icon: <Package className="w-4 h-4" /> },
    { href: '/creators', label: 'Creators', icon: <Users className="w-4 h-4" /> },
    { href: '/badges', label: 'Badges', icon: <Award className="w-4 h-4" /> },
    { href: '/teams', label: 'Teams', icon: <Users2 className="w-4 h-4" /> },
    { href: '/campaigns', label: 'Campaigns', icon: <CalendarDays className="w-4 h-4" /> },
    { href: '/collaborations', label: 'Collaborations', icon: <Handshake className="w-4 h-4" /> },
    { href: '/custom-orders', label: 'Custom Orders', icon: <Briefcase className="w-4 h-4" /> },
    { href: '/rewards', label: 'Rewards', icon: <Gift className="w-4 h-4" /> },
  ]

  const isActive = (href: string) => pathname === href

  return (
    <>
      {showAnn && (
        <div className="w-full bg-gradient-to-r from-purple-600/20 via-blue-600/15 to-purple-600/20 border-b border-purple-500/20">
          <div className="container mx-auto flex items-center justify-between px-4 py-1.5">
            <div className="flex items-center gap-2 text-xs sm:text-sm text-white/70 truncate">
              <Zap className="h-3 w-3 text-yellow-400 flex-shrink-0" />
              <span className="truncate">Welcome to GfxStore — the #1 Minecraft content marketplace!</span>
            </div>
            <button onClick={() => setShowAnn(false)} className="text-white/30 hover:text-white/60 ml-2 flex-shrink-0 p-1">
              <X className="h-3 w-3" />
            </button>
          </div>
        </div>
      )}

      <header className="sticky top-0 z-50 w-full border-b border-white/[0.06] bg-[#0a0a0f]/95 backdrop-blur-xl">
        <div className="container mx-auto flex h-14 items-center px-3 sm:px-4 gap-1 sm:gap-2">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-1 sm:gap-2 flex-shrink-0 mr-0 sm:mr-1">
            <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg bg-gradient-to-br from-purple-500 to-blue-600 flex items-center justify-center shadow-lg shadow-purple-500/25 flex-shrink-0">
              <Zap className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-white" />
            </div>
            <span className="font-bold text-white text-base sm:text-lg hidden sm:block tracking-tight whitespace-nowrap">GfxStore</span>
          </Link>

          {/* Desktop nav — adjust breakpoint from lg to md */}
          <nav className="hidden md:flex items-center gap-0.5 ml-1 overflow-x-auto scrollbar-hide flex-nowrap">
            {navLinks.map(link => (
              <Link key={link.href} href={link.href}
                className={`px-2.5 lg:px-3 py-1.5 rounded-lg text-[10px] lg:text-[12px] font-medium transition-all whitespace-nowrap flex-shrink-0 ${isActive(link.href) ? 'text-purple-300 bg-purple-500/10' : 'text-white/50 hover:text-white hover:bg-white/5'}`}>
                {link.label}
              </Link>
            ))}
          </nav>

          {/* Search — show on md and up instead of just desktop */}
          <form onSubmit={handleSearch} className="hidden sm:flex flex-1 max-w-xs lg:max-w-sm ml-auto mr-1 sm:mr-1">
            <div className="relative w-full">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-white/25" />
              <Input
                value={searchQuery} onChange={e => setSearchQuery(e.target.value)}
                placeholder="Search..."
                className="pl-8 h-8 bg-white/[0.04] border-white/[0.08] text-white placeholder:text-white/25 text-xs rounded-lg focus:border-purple-500/40 focus:bg-white/[0.06]"
              />
            </div>
          </form>

          {/* Right icons */}
          <div className="flex items-center gap-1 ml-auto md:ml-0 flex-shrink-0">
            {session ? (
              <>
                {/* Always show chat on sm+ */}
                <Button variant="ghost" size="icon" onClick={onChatToggle} className="h-8 w-8 text-white/40 hover:text-white hover:bg-white/5 rounded-lg flex-shrink-0" title="Live Chat">
                  <MessageCircle className="h-4 w-4" />
                </Button>

                {/* Show wishlist and cart on sm+ */}
                <Link href="/wishlist" className="flex-shrink-0">
                  <Button variant="ghost" size="icon" className="h-8 w-8 relative text-white/40 hover:text-white hover:bg-white/5 rounded-lg" title="Wishlist">
                    <Heart className="h-4 w-4" />
                    {wishlistCount > 0 && <span className="absolute -top-0.5 -right-0.5 h-3.5 w-3.5 rounded-full bg-pink-500 text-[8px] font-bold text-white flex items-center justify-center">{wishlistCount > 9 ? '9+' : wishlistCount}</span>}
                  </Button>
                </Link>

                <Link href="/cart" className="flex-shrink-0">
                  <Button variant="ghost" size="icon" className="h-8 w-8 relative text-white/40 hover:text-white hover:bg-white/5 rounded-lg" title="Cart">
                    <ShoppingCart className="h-4 w-4" />
                    {cartCount > 0 && <span className="absolute -top-0.5 -right-0.5 h-3.5 w-3.5 rounded-full bg-blue-500 text-[8px] font-bold text-white flex items-center justify-center">{cartCount > 9 ? '9+' : cartCount}</span>}
                  </Button>
                </Link>

                {/* Show friend requests and notifications on all screens */}
                <div className="flex items-center gap-0.5 flex-shrink-0 relative">
                  <FriendRequestPanel />
                  <NotificationBell />
                </div>

                {/* Wallet — md and up */}
                <Button variant="ghost" size="sm" onClick={() => setShowDepositModal(true)}
                  className="h-8 px-2 text-white/60 hover:text-white hover:bg-white/5 rounded-lg text-xs gap-1 hidden md:flex flex-shrink-0">
                  <Wallet className="h-3.5 w-3.5 text-green-400" />
                  <span className="text-green-400 font-semibold whitespace-nowrap hidden lg:inline">${balance.toFixed(2)}</span>
                </Button>

                {/* Upload — md and up */}
                <Link href="/upload" className="hidden md:block flex-shrink-0">
                  <Button size="sm" className="h-8 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 text-white text-xs rounded-lg shadow-md shadow-purple-500/20 border-0 px-3 whitespace-nowrap">
                    <Upload className="h-3.5 w-3.5 mr-1" />Upload
                  </Button>
                </Link>

                {/* User menu */}
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="h-8 w-8 rounded-full p-0 ml-0.5 ring-1 ring-white/10 hover:ring-purple-500/40 transition-all flex-shrink-0">
                      <Avatar className="h-7 w-7">
                        <AvatarImage src={session.user?.image || (session.user as any)?.avatar || ''} />
                        <AvatarFallback className="bg-gradient-to-br from-purple-600 to-blue-600 text-white text-[10px] font-bold">
                          {(session.user?.name || session.user?.username || 'U').charAt(0).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className="w-56 bg-[#0f0f1a] border-white/10 shadow-2xl shadow-black/50" align="end" forceMount>
                    <div className="p-3 border-b border-white/[0.06]">
                      <div className="flex items-center gap-2.5">
                        <Avatar className="h-9 w-9">
                          <AvatarImage src={session.user?.image || (session.user as any)?.avatar || ''} />
                          <AvatarFallback className="bg-gradient-to-br from-purple-600 to-blue-600 text-white text-xs font-bold">
                            {(session.user?.name || session.user?.username || 'U').charAt(0).toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold text-white text-sm truncate">{session.user?.name || session.user?.username}</p>
                          <p className="text-[10px] text-white/30 truncate">{session.user?.email}</p>
                          {isAdmin && <Badge className="mt-0.5 h-4 text-[8px] bg-purple-500/20 text-purple-300 border-purple-500/30"><Crown className="w-2.5 h-2.5 mr-0.5" />{session.user?.role}</Badge>}
                        </div>
                      </div>
                    </div>
                    <div className="p-1">
                      {[
                        { href: '/dashboard', icon: <LayoutDashboard className="h-4 w-4 text-purple-400" />, label: 'Dashboard' },
                        { href: '/profile', icon: <User className="h-4 w-4 text-blue-400" />, label: 'Profile' },
                        { href: '/settings', icon: <Settings className="h-4 w-4 text-gray-400" />, label: 'Settings' },
                        { href: '/messages', icon: <MessageCircle className="h-4 w-4 text-green-400" />, label: 'Messages' },
                        { href: '/orders', icon: <Package className="h-4 w-4 text-indigo-400" />, label: 'My Orders' },
                        { href: '/wishlist', icon: <Heart className="h-4 w-4 text-pink-400" />, label: 'Wishlist', badge: wishlistCount },
                        { href: '/cart', icon: <ShoppingCart className="h-4 w-4 text-orange-400" />, label: 'Cart', badge: cartCount },
                      ].map(item => (
                        <DropdownMenuItem key={item.href} asChild className="rounded-lg text-white/60 hover:text-white focus:text-white focus:bg-white/[0.06] text-[13px]">
                          <Link href={item.href} className="flex items-center gap-2.5">
                            {item.icon}{item.label}
                            {item.badge ? <span className="ml-auto text-[10px] bg-white/10 text-white/50 rounded px-1.5 py-0.5">{item.badge}</span> : null}
                          </Link>
                        </DropdownMenuItem>
                      ))}
                      <DropdownMenuItem asChild className="rounded-lg text-white/60 hover:text-white focus:text-white focus:bg-white/[0.06] text-[13px]">
                        <Link href="/wallet" className="flex items-center gap-2.5">
                          <Wallet className="h-4 w-4 text-yellow-400" />Wallet
                          <span className="ml-auto text-green-400 font-semibold text-[11px]">${balance.toFixed(2)}</span>
                        </Link>
                      </DropdownMenuItem>
                    </div>
                    {isAdmin && (
                      <>
                        <DropdownMenuSeparator className="bg-white/[0.06]" />
                        <div className="p-1">
                          <DropdownMenuItem asChild className="rounded-lg text-purple-300 hover:text-purple-200 focus:text-purple-200 focus:bg-purple-500/10 text-[13px]">
                            <Link href="/admin" className="flex items-center gap-2.5"><Crown className="h-4 w-4" />Admin Panel</Link>
                          </DropdownMenuItem>
                        </div>
                      </>
                    )}
                    <DropdownMenuSeparator className="bg-white/[0.06]" />
                    <div className="p-1">
                      <DropdownMenuItem onClick={() => signOut()} className="rounded-lg text-red-400/80 hover:text-red-300 focus:text-red-300 focus:bg-red-500/10 cursor-pointer text-[13px]">
                        <LogOut className="h-4 w-4 mr-2.5" />Sign out
                      </DropdownMenuItem>
                    </div>
                  </DropdownMenuContent>
                </DropdownMenu>
              </>
            ) : (
              <div className="flex items-center gap-1.5">
                <Link href="/auth/signin">
                  <Button variant="ghost" size="sm" className="h-8 text-white/50 hover:text-white hover:bg-white/5 rounded-lg text-xs px-2.5">Sign In</Button>
                </Link>
                <Link href="/auth/signup">
                  <Button size="sm" className="h-8 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 text-white text-xs rounded-lg shadow-md shadow-purple-500/20 border-0 px-3">Sign Up</Button>
                </Link>
              </div>
            )}

            {/* Mobile hamburger — only show on sm */}
            <button
              type="button"
              aria-label={mobileOpen ? 'Close menu' : 'Open menu'}
              className="h-8 w-8 md:hidden flex items-center justify-center text-white/50 hover:text-white hover:bg-white/5 rounded-lg ml-1 flex-shrink-0"
              onClick={() => setMobileOpen(!mobileOpen)}>
              {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>

        {/* Mobile drawer — show on tablets too */}
        {mobileOpen && (
          <div className="md:hidden border-t border-white/[0.06] bg-[#0a0a0f]/98 backdrop-blur-xl max-h-[70vh] overflow-y-auto">
            {/* Search on mobile */}
            <div className="sm:hidden px-4 pt-3 pb-2">
              <form onSubmit={handleSearch}>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-white/25" />
                  <Input value={searchQuery} onChange={e => setSearchQuery(e.target.value)} placeholder="Search content..."
                    className="pl-9 h-9 bg-white/[0.04] border-white/[0.08] text-white placeholder:text-white/25 text-sm rounded-xl w-full" />
                </div>
              </form>
            </div>

            <div className="px-2 pb-3">
              <div className="text-[10px] font-semibold text-white/20 uppercase tracking-wider px-3 py-1.5">Navigation</div>
              {navLinks.map(link => (
                <Link key={link.href} href={link.href}
                  className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all ${isActive(link.href) ? 'text-purple-300 bg-purple-500/10' : 'text-white/60 hover:text-white hover:bg-white/5'}`}>
                  {link.icon}{link.label}
                  <ChevronRight className="w-3.5 h-3.5 text-white/20 ml-auto" />
                </Link>
              ))}

              {session && (
                <>
                  <div className="h-px bg-white/[0.06] my-2 mx-3" />
                  <div className="text-[10px] font-semibold text-white/20 uppercase tracking-wider px-3 py-1.5">Account</div>
                  {[
                    { href: '/messages', icon: <MessageCircle className="w-4 h-4 text-green-400" />, label: 'Messages' },
                    { href: '/dashboard', icon: <LayoutDashboard className="w-4 h-4 text-purple-400" />, label: 'Dashboard' },
                    { href: '/profile', icon: <User className="w-4 h-4 text-blue-400" />, label: 'Profile' },
                    { href: '/orders', icon: <Package className="w-4 h-4 text-indigo-400" />, label: 'My Orders' },
                    { href: '/wishlist', icon: <Heart className="w-4 h-4 text-pink-400" />, label: 'Wishlist', badge: wishlistCount },
                    { href: '/cart', icon: <ShoppingCart className="w-4 h-4 text-blue-400" />, label: 'Cart', badge: cartCount },
                    { href: '/wallet', icon: <Wallet className="w-4 h-4 text-yellow-400" />, label: `Wallet — $${balance.toFixed(2)}` },
                  ].map(item => (
                    <Link key={item.href} href={item.href}
                      className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all ${isActive(item.href) ? 'text-purple-300 bg-purple-500/10' : 'text-white/60 hover:text-white hover:bg-white/5'}`}>
                      {item.icon}{item.label}
                      {item.badge ? <span className="ml-auto text-[10px] bg-white/10 text-white/50 rounded-full px-1.5 py-0.5">{item.badge}</span> : <ChevronRight className="w-3.5 h-3.5 text-white/20 ml-auto" />}
                    </Link>
                  ))}

                  <div className="h-px bg-white/[0.06] my-2 mx-3" />
                  <Link href="/upload" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-purple-300 hover:bg-purple-500/10 transition-all">
                    <Upload className="w-4 h-4" />Upload Content
                    <ArrowRight className="w-3.5 h-3.5 text-purple-500/50 ml-auto" />
                  </Link>
                  {isAdmin && (
                    <Link href="/admin" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-purple-300 hover:bg-purple-500/10 transition-all">
                      <Crown className="w-4 h-4" />Admin Panel
                      <ArrowRight className="w-3.5 h-3.5 text-purple-500/50 ml-auto" />
                    </Link>
                  )}
                  <div className="h-px bg-white/[0.06] my-2 mx-3" />
                  <button onClick={() => signOut()} className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-red-400/80 hover:text-red-300 hover:bg-red-500/10 transition-all">
                    <LogOut className="w-4 h-4" />Sign out
                  </button>
                </>
              )}
            </div>
          </div>
        )}
      </header>

      <DepositModal isOpen={showDepositModal} onClose={() => setShowDepositModal(false)} onSuccess={() => { fetchBalance(); setShowDepositModal(false) }} />
    </>
  )
}
