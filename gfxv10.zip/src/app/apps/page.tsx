'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Package, ArrowRight } from 'lucide-react'

export const dynamic = 'force-dynamic'

interface AppItem {
  id: string
  name: string
  shortDesc?: string | null
  category?: string | null
  tags: string[]
  logoUrl?: string | null
  screenshotUrls?: string[] | null
  repoUrl?: string | null
  downloadUrl?: string | null
  author: { username: string }
}

export default function AppsPage() {
  const [apps, setApps] = useState<AppItem[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const loadApps = async () => {
      setLoading(true)
      try {
        const response = await fetch('/api/apps?limit=40')
        if (response.ok) {
          const data = await response.json()
          setApps(Array.isArray(data.apps) ? data.apps : [])
        }
      } catch (error) {
        console.error('Failed to fetch apps', error)
      } finally {
        setLoading(false)
      }
    }
    loadApps()
  }, [])

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white">
      <Navbar />
      <main className="container mx-auto px-4 py-10">
        <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
          <div>
            <h1 className="text-4xl font-bold">Apps</h1>
            <p className="mt-2 text-white/60 max-w-2xl">Publish apps with screenshots, version releases, and download links. Add new versions as your app grows.</p>
          </div>
          <Link href="/apps/submit">
            <Button className="bg-gradient-to-r from-purple-600 to-blue-600">Submit an App</Button>
          </Link>
        </div>

        <section className="mt-10 grid gap-6 md:grid-cols-2 xl:grid-cols-3">
          {apps.map((app) => (
            <article key={app.id} className="overflow-hidden rounded-3xl border border-white/10 bg-slate-950 shadow-lg shadow-black/20">
              {app.screenshotUrls?.[0] ? (
                <div className="h-48 overflow-hidden bg-black">
                  <img src={app.screenshotUrls[0]} alt={app.name} className="h-full w-full object-cover transition duration-300 hover:scale-105" />
                </div>
              ) : null}
              <div className="p-5 space-y-4">
                <div className="flex items-start gap-4">
                  <div className="h-16 w-16 rounded-3xl bg-white/5 flex items-center justify-center overflow-hidden">
                    {app.logoUrl ? <img src={app.logoUrl} alt={app.name} className="h-full w-full object-cover" /> : <Package className="h-8 w-8 text-white/50" />}
                  </div>
                  <div className="space-y-1">
                    <h2 className="text-xl font-semibold">{app.name}</h2>
                    <p className="text-sm text-white/50">By {app.author.username}</p>
                  </div>
                </div>
                <p className="text-sm text-white/60 line-clamp-3">{app.shortDesc || 'No description yet.'}</p>
                <div className="flex flex-wrap gap-2">
                  {app.category ? <Badge className="bg-white/5 text-white/70">{app.category}</Badge> : null}
                  {app.tags?.map((tag) => (
                    <Badge key={`${app.id}-${tag}`} className="bg-white/5 text-white/70">#{tag}</Badge>
                  ))}
                </div>
                <div className="flex flex-wrap gap-3">
                  {app.repoUrl ? (
                    <Link href={app.repoUrl} className="inline-flex items-center gap-2 rounded-full border border-white/10 px-4 py-2 text-sm text-white/80 hover:bg-white/5">
                      Repository <ArrowRight className="w-4 h-4" />
                    </Link>
                  ) : null}
                  {app.downloadUrl ? (
                    <Link href={app.downloadUrl} className="inline-flex items-center gap-2 rounded-full bg-purple-600/90 px-4 py-2 text-sm text-white hover:bg-purple-500">
                      Download <ArrowRight className="w-4 h-4" />
                    </Link>
                  ) : null}
                </div>
              </div>
            </article>
          ))}
        </section>

        {!loading && apps.length === 0 ? (
          <div className="mt-10 rounded-3xl border border-dashed border-white/10 bg-white/5 p-8 text-center text-white/60">
            No apps have been added yet. Create one and share it with the community.
          </div>
        ) : null}
      </main>
      <Footer />
    </div>
  )
}
