'use client'

import { useEffect, useRef, useState } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { toast } from 'sonner'
import Link from 'next/link'
import { ArrowLeft, Upload, X } from 'lucide-react'

export default function AppsSubmitPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const logoInputRef = useRef<HTMLInputElement>(null)
  const screenshotInputRef = useRef<HTMLInputElement>(null)
  const appFileInputRef = useRef<HTMLInputElement>(null)
  const [name, setName] = useState('')
  const [slug, setSlug] = useState('')
  const [description, setDescription] = useState('')
  const [shortDesc, setShortDesc] = useState('')
  const [category, setCategory] = useState('')
  const [tags, setTags] = useState('')
  const [repoUrl, setRepoUrl] = useState('')
  const [downloadUrl, setDownloadUrl] = useState('')
  const [logoUrl, setLogoUrl] = useState('')
  const [screenshotUrls, setScreenshotUrls] = useState('')
  const [logoFile, setLogoFile] = useState<File | null>(null)
  const [screenshotFiles, setScreenshotFiles] = useState<File[]>([])
  const [appFile, setAppFile] = useState<File | null>(null)
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/auth/signin')
    }
  }, [status, router])

  const handleLogoFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0] || null
    setLogoFile(file)
    if (file) setLogoUrl('')
  }

  const handleScreenshotFilesChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || [])
    setScreenshotFiles(files)
    if (files.length > 0) setScreenshotUrls('')
  }

  const handleAppFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0] || null
    setAppFile(file)
    if (file) setDownloadUrl('')
  }

  const removeScreenshot = (index: number) => {
    setScreenshotFiles(prev => prev.filter((_, i) => i !== index))
  }

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault()
    if (!name.trim() || !description.trim()) {
      toast.error('Name and description are required')
      return
    }

    setLoading(true)
    try {
      const formData = new FormData()
      formData.append('name', name.trim())
      formData.append('slug', slug.trim())
      formData.append('description', description.trim())
      formData.append('shortDesc', shortDesc.trim())
      formData.append('category', category.trim())
      formData.append('tags', tags)
      formData.append('repoUrl', repoUrl.trim())
      formData.append('downloadUrl', downloadUrl.trim())
      formData.append('logoUrl', logoUrl.trim())
      formData.append('screenshotUrls', screenshotUrls)
      if (logoFile) formData.append('logoFile', logoFile)
      screenshotFiles.forEach(file => formData.append('screenshotFiles', file))
      if (appFile) formData.append('appFile', appFile)

      const response = await fetch('/api/apps/submit', {
        method: 'POST',
        body: formData
      })

      const result = await response.json()
      if (!response.ok) {
        toast.error(result.error || 'Failed to submit app')
      } else {
        toast.success('App submitted successfully!')
        router.push('/apps')
      }
    } catch (error) {
      console.error(error)
      toast.error('Submission failed')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white">
      <Navbar />
      <main className="container mx-auto px-4 py-10">
        <div className="mb-8 flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
          <div>
            <Link href="/apps" className="inline-flex items-center gap-2 text-white/60 hover:text-white">
              <ArrowLeft className="w-4 h-4" /> Back to Apps
            </Link>
            <h1 className="mt-4 text-4xl font-bold">Submit an App</h1>
            <p className="mt-2 text-white/50 max-w-2xl">Add your app, share screenshots, and let users download or install your latest release.</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} encType="multipart/form-data" className="space-y-6 rounded-3xl border border-white/10 bg-white/5 p-8">
          <div className="grid gap-6 lg:grid-cols-2">
            <div>
              <Label htmlFor="name">App Name</Label>
              <Input id="name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Enter app name" className="mt-2 bg-[#10121b] border-white/10 text-white" />
            </div>
            <div>
              <Label htmlFor="slug">Slug (optional)</Label>
              <Input id="slug" value={slug} onChange={(e) => setSlug(e.target.value)} placeholder="custom-app-slug" className="mt-2 bg-[#10121b] border-white/10 text-white" />
            </div>
          </div>

          <div>
            <Label htmlFor="shortDesc">Short Description</Label>
            <Input id="shortDesc" value={shortDesc} onChange={(e) => setShortDesc(e.target.value)} placeholder="One sentence summary" className="mt-2 bg-[#10121b] border-white/10 text-white" />
          </div>

          <div>
            <Label htmlFor="description">Detailed Description</Label>
            <Textarea id="description" value={description} onChange={(e) => setDescription(e.target.value)} rows={5} placeholder="Describe the app, features and use cases" className="mt-2 bg-[#10121b] border-white/10 text-white" />
          </div>

          <div className="grid gap-6 lg:grid-cols-2">
            <div>
              <Label htmlFor="category">Category</Label>
              <Input id="category" value={category} onChange={(e) => setCategory(e.target.value)} placeholder="Productivity, Utility, Game, etc." className="mt-2 bg-[#10121b] border-white/10 text-white" />
            </div>
            <div>
              <Label htmlFor="tags">Tags</Label>
              <Input id="tags" value={tags} onChange={(e) => setTags(e.target.value)} placeholder="e.g. app, tool, frontend" className="mt-2 bg-[#10121b] border-white/10 text-white" />
            </div>
          </div>

          <div className="grid gap-6 lg:grid-cols-2">
            <div>
              <Label htmlFor="repoUrl">Repository URL</Label>
              <Input id="repoUrl" value={repoUrl} onChange={(e) => setRepoUrl(e.target.value)} placeholder="https://github.com/your-project" className="mt-2 bg-[#10121b] border-white/10 text-white" />
            </div>
            <div>
              <Label htmlFor="downloadUrl">Download URL</Label>
              <Input id="downloadUrl" value={downloadUrl} onChange={(e) => setDownloadUrl(e.target.value)} placeholder="Direct download or release page" className="mt-2 bg-[#10121b] border-white/10 text-white" />
            </div>
          </div>

          <div className="grid gap-6 lg:grid-cols-2">
            <div>
              <Label htmlFor="logoUrl">Logo URL (or upload file)</Label>
              <Input id="logoUrl" value={logoUrl} onChange={(e) => setLogoUrl(e.target.value)} placeholder="Cover image URL" className="mt-2 bg-[#10121b] border-white/10 text-white" />
              <div className="mt-2">
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleLogoFileChange}
                  className="w-full text-sm text-white file:bg-transparent file:border-0 file:text-sm file:font-medium"
                />
                {logoFile && <p className="mt-2 text-sm text-green-400">Selected logo: {logoFile.name}</p>}
              </div>
            </div>
            <div>
              <Label htmlFor="screenshotUrls">Screenshot URLs (or upload files)</Label>
              <Textarea id="screenshotUrls" value={screenshotUrls} onChange={(e) => setScreenshotUrls(e.target.value)} rows={3} placeholder="Comma-separated image URLs" className="mt-2 bg-[#10121b] border-white/10 text-white" />
              <div className="mt-2">
                <input
                  type="file"
                  accept="image/*"
                  multiple
                  onChange={handleScreenshotFilesChange}
                  className="w-full text-sm text-white file:bg-transparent file:border-0 file:text-sm file:font-medium"
                />
                {screenshotFiles.length > 0 && (
                  <div className="mt-2 space-y-1">
                    {screenshotFiles.map((file, index) => (
                      <div key={index} className="flex items-center gap-2 text-sm text-green-400">
                        <span>{file.name}</span>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => removeScreenshot(index)}
                          className="h-4 w-4 p-0 text-red-400 hover:text-red-300"
                        >
                          <X className="w-3 h-3" />
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>

          <div>
            <Label htmlFor="downloadUrl">Download URL (or upload file)</Label>
            <Input id="downloadUrl" value={downloadUrl} onChange={(e) => setDownloadUrl(e.target.value)} placeholder="Direct download or release page" className="mt-2 bg-[#10121b] border-white/10 text-white" />
            <div className="mt-2">
              <input
                type="file"
                onChange={handleAppFileChange}
                className="w-full text-sm text-white file:bg-transparent file:border-0 file:text-sm file:font-medium"
              />
              {appFile && <p className="mt-2 text-sm text-green-400">Selected app file: {appFile.name}</p>}
            </div>
          </div>

          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <p className="text-sm text-white/50">Share your app with the community. Keep details up to date when you release new versions.</p>
            <Button type="submit" disabled={loading} className="bg-gradient-to-r from-purple-600 to-blue-600">
              {loading ? 'Submitting...' : 'Submit App'}
            </Button>
          </div>
        </form>
      </main>
      <Footer />
    </div>
  )
}
