'use client'

import { useEffect, useRef, useState } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { toast } from 'sonner'
import Link from 'next/link'
import { ArrowLeft, Upload, X } from 'lucide-react'

export default function CodeSubmitPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const screenshotInputRef = useRef<HTMLInputElement>(null)
  const codeFileInputRef = useRef<HTMLInputElement>(null)
  const [title, setTitle] = useState('')
  const [slug, setSlug] = useState('')
  const [description, setDescription] = useState('')
  const [projectType, setProjectType] = useState('FULLSTACK')
  const [tags, setTags] = useState('')
  const [repoUrl, setRepoUrl] = useState('')
  const [downloadUrl, setDownloadUrl] = useState('')
  const [screenshotUrls, setScreenshotUrls] = useState('')
  const [screenshotFiles, setScreenshotFiles] = useState<File[]>([])
  const [codeFile, setCodeFile] = useState<File | null>(null)
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/auth/signin')
    }
  }, [status, router])

  const handleScreenshotFilesChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || [])
    setScreenshotFiles(files)
    if (files.length > 0) setScreenshotUrls('')
  }

  const handleCodeFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0] || null
    setCodeFile(file)
    if (file) setDownloadUrl('')
  }

  const removeScreenshot = (index: number) => {
    setScreenshotFiles(prev => prev.filter((_, i) => i !== index))
  }

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault()
    if (!title.trim() || !description.trim()) {
      toast.error('Title and description are required')
      return
    }

    setLoading(true)
    try {
      const formData = new FormData()
      formData.append('title', title.trim())
      formData.append('slug', slug.trim())
      formData.append('description', description.trim())
      formData.append('projectType', projectType)
      formData.append('tags', tags)
      formData.append('repoUrl', repoUrl.trim())
      formData.append('downloadUrl', downloadUrl.trim())
      formData.append('screenshotUrls', screenshotUrls)
      screenshotFiles.forEach(file => formData.append('screenshotFiles', file))
      if (codeFile) formData.append('codeFile', codeFile)

      const response = await fetch('/api/code/submit', {
        method: 'POST',
        body: formData
      })

      const result = await response.json()
      if (!response.ok) {
        toast.error(result.error || 'Failed to submit project')
      } else {
        toast.success('Project submitted successfully!')
        router.push('/code')
      }
    } catch (error) {
      console.error('Code submission failed', error)
      toast.error('Submission failed')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white">
      <Navbar />
      <main className="container mx-auto px-4 py-10">
        <div className="mb-8 flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
          <div>
            <Link href="/code" className="inline-flex items-center gap-2 text-white/60 hover:text-white">
              <ArrowLeft className="w-4 h-4" /> Back to Code Projects
            </Link>
            <h1 className="mt-4 text-4xl font-bold">Submit a Code Project</h1>
            <p className="mt-2 text-white/50 max-w-2xl">Publish your frontend, backend, or fullstack source code with screenshots and download options.</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} encType="multipart/form-data" className="space-y-6 rounded-3xl border border-white/10 bg-white/5 p-8">
          <div className="grid gap-6 lg:grid-cols-2">
            <div>
              <Label htmlFor="title">Project Title</Label>
              <Input id="title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Enter project title" className="mt-2 bg-[#10121b] border-white/10 text-white" />
            </div>
            <div>
              <Label htmlFor="slug">Slug (optional)</Label>
              <Input id="slug" value={slug} onChange={(e) => setSlug(e.target.value)} placeholder="project-slug" className="mt-2 bg-[#10121b] border-white/10 text-white" />
            </div>
          </div>

          <div>
            <Label htmlFor="projectType">Project Type</Label>
            <select id="projectType" value={projectType} onChange={(e) => setProjectType(e.target.value)} className="mt-2 w-full rounded-xl border border-white/10 bg-[#10121b] px-3 py-2 text-white">
              <option value="FULLSTACK">Fullstack</option>
              <option value="FRONTEND">Frontend</option>
              <option value="BACKEND">Backend</option>
              <option value="OTHER">Other</option>
            </select>
          </div>

          <div>
            <Label htmlFor="description">Description</Label>
            <Textarea id="description" value={description} onChange={(e) => setDescription(e.target.value)} rows={5} placeholder="Describe your project and its features" className="mt-2 bg-[#10121b] border-white/10 text-white" />
          </div>

          <div className="grid gap-6 lg:grid-cols-2">
            <div>
              <Label htmlFor="tags">Tags</Label>
              <Input id="tags" value={tags} onChange={(e) => setTags(e.target.value)} placeholder="e.g. react, node, api" className="mt-2 bg-[#10121b] border-white/10 text-white" />
            </div>
            <div>
              <Label htmlFor="repoUrl">Repository URL</Label>
              <Input id="repoUrl" value={repoUrl} onChange={(e) => setRepoUrl(e.target.value)} placeholder="https://github.com/your/repo" className="mt-2 bg-[#10121b] border-white/10 text-white" />
            </div>
          </div>

          <div>
            <Label htmlFor="downloadUrl">Download URL (or upload file)</Label>
            <Input id="downloadUrl" value={downloadUrl} onChange={(e) => setDownloadUrl(e.target.value)} placeholder="Direct download link" className="mt-2 bg-[#10121b] border-white/10 text-white" />
            <div className="mt-2">
              <input
                type="file"
                accept=".zip,.rar,.7z,.tar.gz"
                onChange={handleCodeFileChange}
                className="w-full text-sm text-white file:bg-transparent file:border-0 file:text-sm file:font-medium"
              />
              {codeFile && <p className="mt-2 text-sm text-green-400">Selected code file: {codeFile.name}</p>}
            </div>
          </div>

          <div>
            <Label htmlFor="screenshotUrls">Screenshot URLs (or upload files)</Label>
            <Textarea id="screenshotUrls" value={screenshotUrls} onChange={(e) => setScreenshotUrls(e.target.value)} rows={3} placeholder="Comma-separated image URLs" className="mt-2 bg-[#10121b] border-white/10 text-white" />
            <div className="mt-2">
              <input
                type="file"
                accept="image/*"
                multiple
                onChange={handleScreenshotFilesChange}
                className="w-full text-sm text-white file:bg-transparent file:border-0 file:text-sm file:font-medium"
              />
              {screenshotFiles.length > 0 && (
                <div className="mt-2 space-y-1">
                  {screenshotFiles.map((file, index) => (
                    <div key={index} className="flex items-center gap-2 text-sm text-green-400">
                      <span>{file.name}</span>
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => removeScreenshot(index)}
                        className="h-4 w-4 p-0 text-red-400 hover:text-red-300"
                      >
                        <X className="w-3 h-3" />
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <p className="text-sm text-white/50">Make sure your repo and download links are public so the community can access them.</p>
            <Button type="submit" disabled={loading} className="bg-gradient-to-r from-purple-600 to-blue-600">
              {loading ? 'Submitting...' : 'Submit Project'}
            </Button>
          </div>
        </form>
      </main>
      <Footer />
    </div>
  )
}
