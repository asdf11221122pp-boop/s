'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Code2, ArrowRight } from 'lucide-react'

export const dynamic = 'force-dynamic'

interface CodeProject {
  id: string
  title: string
  description: string
  projectType: string
  repoUrl?: string | null
  downloadUrl?: string | null
  screenshotUrls?: string[] | null
  tags: string[]
  author: { username: string }
}

export default function CodePage() {
  const [projects, setProjects] = useState<CodeProject[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const loadProjects = async () => {
      setLoading(true)
      try {
        const response = await fetch('/api/code?limit=40')
        if (response.ok) {
          const data = await response.json()
          setProjects(Array.isArray(data.projects) ? data.projects : [])
        }
      } catch (error) {
        console.error('Failed to fetch code projects', error)
      } finally {
        setLoading(false)
      }
    }
    loadProjects()
  }, [])

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white">
      <Navbar />
      <main className="container mx-auto px-4 py-10">
        <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
          <div>
            <h1 className="text-4xl font-bold">Code Projects</h1>
            <p className="mt-2 text-white/60 max-w-2xl">Share frontend and backend projects, show screenshots, and let others download your code or visit the repo.</p>
          </div>
          <Link href="/code/submit">
            <Button className="bg-gradient-to-r from-purple-600 to-blue-600">Submit Code</Button>
          </Link>
        </div>

        <section className="mt-10 grid gap-6 md:grid-cols-2 xl:grid-cols-3">
          {projects.map((project) => (
            <article key={project.id} className="overflow-hidden rounded-3xl border border-white/10 bg-slate-950 shadow-lg shadow-black/20">
              {project.screenshotUrls?.[0] ? (
                <div className="h-48 overflow-hidden bg-black">
                  <img src={project.screenshotUrls[0]} alt={project.title} className="h-full w-full object-cover transition duration-300 hover:scale-105" />
                </div>
              ) : null}
              <div className="p-5 space-y-4">
                <div className="flex items-start gap-4">
                  <div className="h-16 w-16 rounded-3xl bg-white/5 flex items-center justify-center">
                    <Code2 className="h-8 w-8 text-white/50" />
                  </div>
                  <div>
                    <h2 className="text-xl font-semibold">{project.title}</h2>
                    <p className="text-sm text-white/50">{project.projectType}</p>
                  </div>
                </div>
                <p className="text-sm text-white/60 line-clamp-3">{project.description}</p>
                <div className="flex flex-wrap gap-2">
                  {project.tags?.map((tag) => (
                    <Badge key={`${project.id}-${tag}`} className="bg-white/5 text-white/70">#{tag}</Badge>
                  ))}
                </div>
                <div className="flex flex-wrap gap-3">
                  {project.repoUrl ? (
                    <Link href={project.repoUrl} className="inline-flex items-center gap-2 rounded-full border border-white/10 px-4 py-2 text-sm text-white/80 hover:bg-white/5">
                      Repository <ArrowRight className="w-4 h-4" />
                    </Link>
                  ) : null}
                  {project.downloadUrl ? (
                    <Link href={project.downloadUrl} className="inline-flex items-center gap-2 rounded-full bg-purple-600/90 px-4 py-2 text-sm text-white hover:bg-purple-500">
                      Download <ArrowRight className="w-4 h-4" />
                    </Link>
                  ) : null}
                </div>
              </div>
            </article>
          ))}
        </section>

        {!loading && projects.length === 0 ? (
          <div className="mt-10 rounded-3xl border border-dashed border-white/10 bg-white/5 p-8 text-center text-white/60">
            No projects added yet. Upload your first frontend or backend release.
          </div>
        ) : null}
      </main>
      <Footer />
    </div>
  )
}
