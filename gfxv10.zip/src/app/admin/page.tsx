'use client'

import { useState, useEffect, useRef, useMemo } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { io, Socket } from 'socket.io-client'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Switch } from '@/components/ui/switch'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import {
  Users, Package, TrendingUp, Download, Shield, Check, X, Eye, Trash2, Edit,
  RefreshCw, AlertTriangle, Bell, Database, Globe, LayoutDashboard, Zap, ShoppingCart,
  FolderOpen, CreditCard, Server, Send, Clock, CheckCircle, XCircle, Loader2,
  Star, DollarSign, UserCheck, MessageSquare, Search, ChevronRight, Ban, MoreVertical,
  Settings, Plus, Save, Crown, Menu, ChevronLeft, Activity, FileText, Layers,
  ArrowUpRight, ArrowDownRight, BarChart3, PieChart, Heart, Tag, Megaphone, Ticket,
  ToggleLeft, ToggleRight, Power, Wrench, Image, Link2, MousePointerClick, Copy,
  Trophy, Gift, Share2, Users2, Handshake, Award, Sparkles, Target, CalendarDays
} from 'lucide-react'
import Link from 'next/link'
import { toast } from 'sonner'

interface AdminStats {
  totalUsers: number; totalItems: number; totalDownloads: number; totalRevenue: number
  activeUsers: number; pendingItems: number; pendingWithdrawals: number; pendingApplications: number
  pendingReports: number; totalOrders: number
}

interface User { id: string; username: string; email: string; role: string; isActive: boolean; isBanned: boolean; walletBalance: number; totalSales: number; sellerLevel: number; isVerified: boolean; createdAt: string; _count?: { items: number } }
interface Item { id: string; title: string; slug: string; status: string; downloads: number; price: number; createdAt: string; author: { username: string } }
interface Application { id: string; userId: string; displayName: string; experience: string; status: string; createdAt: string; user: { username: string; email: string; avatar?: string } }
interface Withdrawal { id: string; amount: number; method: string; accountInfo: string; status: string; adminNote?: string; createdAt: string; user: { username: string; email: string } }
interface Report { id: string; reason: string; details?: string; status: string; createdAt: string; reporter: { username: string }; reportedUser?: { username: string }; item?: { title: string; slug: string } }
interface VpsOrder { id: string; userId: string; user?: { username: string; email: string }; plan: { name: string }; amount: number; paymentMethod: string; transactionRef?: string; status: string; serverInfo?: any; createdAt: string }
interface Transaction { id: string; userId: string; user?: { username: string; email: string }; amount: number; method: string; reference: string; status: string; createdAt: string }
interface ServerPlan { id: string; name: string; description: string; price: number; specs: any; isActive: boolean; sortOrder: number }
interface MembershipType { id: string; name: string; roleName: string; description?: string; price: number; color: string; isActive: boolean; sortOrder: number }

const STATUS_COLORS: Record<string, string> = {
  PENDING: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
  APPROVED: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
  COMPLETED: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
  REJECTED: 'bg-red-500/10 text-red-400 border-red-500/20',
  RESOLVED: 'bg-sky-500/10 text-sky-400 border-sky-500/20',
  DISMISSED: 'bg-zinc-500/10 text-zinc-400 border-zinc-500/20',
  ARCHIVED: 'bg-zinc-500/10 text-zinc-400 border-zinc-500/20',
  DRAFT: 'bg-zinc-500/10 text-zinc-400 border-zinc-500/20',
}

type Section = 'overview' | 'items' | 'users' | 'applications' | 'withdrawals' | 'vps' | 'transactions' | 'reports' | 'categories' | 'plans' | 'memberships' | 'ads' | 'coupons' | 'features' | 'settings' | 'campaigns' | 'badges' | 'referrals' | 'leaderboard' | 'mysteryRewards' | 'teams' | 'collaborations'

interface AdItem { id: string; title: string; description?: string; imageUrl?: string; linkUrl?: string; position: string; isActive: boolean; sortOrder: number; clicks: number; impressions: number; startDate?: string; endDate?: string; createdAt: string }
interface CouponItem { id: string; code: string; description?: string; discountType: string; discountValue: number; minOrderAmount?: number; maxUsage?: number; usageCount: number; expiresAt?: string; isActive: boolean; createdAt: string; createdBy?: { username: string }; _count?: { usages: number } }
interface FeatureToggleItem { id: string; featureKey: string; featureName: string; description?: string; isEnabled: boolean; category: string }

const NAV_SECTIONS: { key: Section; label: string; icon: any; group: string }[] = [
  { key: 'overview', label: 'Overview', icon: LayoutDashboard, group: 'Main' },
  { key: 'items', label: 'Items', icon: Package, group: 'Main' },
  { key: 'users', label: 'Users', icon: Users, group: 'Main' },
  { key: 'applications', label: 'Seller Apps', icon: UserCheck, group: 'Management' },
  { key: 'withdrawals', label: 'Withdrawals', icon: CreditCard, group: 'Management' },
  { key: 'vps', label: 'VPS Orders', icon: Server, group: 'Management' },
  { key: 'transactions', label: 'Transactions', icon: DollarSign, group: 'Management' },
  { key: 'reports', label: 'Reports', icon: AlertTriangle, group: 'Management' },
  { key: 'categories', label: 'Categories', icon: FolderOpen, group: 'Config' },
  { key: 'plans', label: 'Server Plans', icon: Layers, group: 'Config' },
  { key: 'memberships', label: 'Memberships', icon: Crown, group: 'Config' },
  { key: 'ads', label: 'Advertisements', icon: Megaphone, group: 'Marketing' },
  { key: 'coupons', label: 'Coupons', icon: Ticket, group: 'Marketing' },
  { key: 'campaigns', label: 'Campaigns', icon: CalendarDays, group: 'Marketing' },
  { key: 'referrals', label: 'Referrals', icon: Share2, group: 'Marketing' },
  { key: 'badges', label: 'Badges', icon: Award, group: 'Engagement' },
  { key: 'leaderboard', label: 'Leaderboard', icon: Trophy, group: 'Engagement' },
  { key: 'mysteryRewards', label: 'Mystery Rewards', icon: Gift, group: 'Engagement' },
  { key: 'teams', label: 'Teams', icon: Users2, group: 'Engagement' },
  { key: 'collaborations', label: 'Collaborations', icon: Handshake, group: 'Engagement' },
  { key: 'features', label: 'Feature Toggles', icon: ToggleLeft, group: 'System' },
  { key: 'settings', label: 'Settings', icon: Settings, group: 'System' },
]

export default function AdminPage() {
  const { data: session, status: authStatus } = useSession()
  const router = useRouter()
  const socketRef = useRef<Socket | null>(null)
  const [activeSection, setActiveSection] = useState<Section>('overview')
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [stats, setStats] = useState<AdminStats>({ totalUsers: 0, totalItems: 0, totalDownloads: 0, totalRevenue: 0, activeUsers: 0, pendingItems: 0, pendingWithdrawals: 0, pendingApplications: 0, pendingReports: 0, totalOrders: 0 })
  const [users, setUsers] = useState<User[]>([])
  const [items, setItems] = useState<Item[]>([])
  const [applications, setApplications] = useState<Application[]>([])
  const [withdrawals, setWithdrawals] = useState<Withdrawal[]>([])
  const [reports, setReports] = useState<Report[]>([])
  const [categories, setCategories] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [searchUsers, setSearchUsers] = useState('')
  const [searchItems, setSearchItems] = useState('')
  const [newCategory, setNewCategory] = useState({ name: '', description: '' })
  const [announcement, setAnnouncement] = useState('')
  const [siteSettings, setSiteSettings] = useState({
    siteName: 'GfxStore',
    maintenance: true,
    bkashNumber: '',
    nagadNumber: '',
    openAiApiKey: '',
    privacyUrl: '',
    helpCenterUrl: '',
    documentationUrl: '',
    contactUsUrl: '',
    statusPageUrl: '',
    discordUrl: '',
    githubUrl: '',
    twitterUrl: '',
    privacyPolicy: '',
    termsOfService: '',
    guidelines: '',
    dmcaUrl: ''
  })
  const [activeWdNote, setActiveWdNote] = useState<Record<string, string>>({})
  const [activeAppNote, setActiveAppNote] = useState<Record<string, string>>({})
  const [vpsOrders, setVpsOrders] = useState<VpsOrder[]>([])
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [plans, setPlans] = useState<ServerPlan[]>([])
  const [memberships, setMemberships] = useState<MembershipType[]>([])
  const [selectedVps, setSelectedVps] = useState<VpsOrder | null>(null)
  const [vpsServerInfo, setVpsServerInfo] = useState('')
  const [vpsApproving, setVpsApproving] = useState(false)
  const [editPlan, setEditPlan] = useState<Partial<ServerPlan> | null>(null)
  const [editMembership, setEditMembership] = useState<Partial<MembershipType> | null>(null)
  const [ads, setAds] = useState<AdItem[]>([])
  const [editAd, setEditAd] = useState<Partial<AdItem> | null>(null)
  const [coupons, setCoupons] = useState<CouponItem[]>([])
  const [editCoupon, setEditCoupon] = useState<Partial<CouponItem & { code: string; discountType: string; discountValue: number }> | null>(null)
  const [featureToggles, setFeatureToggles] = useState<FeatureToggleItem[]>([])
  const [campaignsList, setCampaignsList] = useState<any[]>([])
  const [editCampaign, setEditCampaign] = useState<any | null>(null)
  const [badgesList, setBadgesList] = useState<any[]>([])
  const [editBadge, setEditBadge] = useState<any | null>(null)
  const [referralStats, setReferralStats] = useState<any>({ totalReferrals: 0, totalEarnings: 0, topReferrers: [], recentReferrals: [] })
  const [leaderboardData, setLeaderboardData] = useState<any>({ topSellers: [], topBuyers: [], topItems: [] })
  const [mysteryRewards, setMysteryRewards] = useState<any[]>([])
  const [editReward, setEditReward] = useState<any | null>(null)
  const [rewardLogs, setRewardLogs] = useState<any[]>([])
  const [teamsList, setTeamsList] = useState<any[]>([])
  const [collaborationsList, setCollaborationsList] = useState<any[]>([])

  useEffect(() => {
    if (authStatus === 'loading') return
    if (authStatus === 'unauthenticated') { router.push('/auth/signin'); return }
    if (!['ADMIN', 'SUPER_ADMIN'].includes(session?.user?.role || '')) { router.push('/'); return }
    loadAll()
    initSocket()
    return () => { socketRef.current?.disconnect() }
  }, [authStatus, session])

  const initSocket = () => {
    try {
      const socket = io(window.location.origin, { path: '/socket.io/', transports: ['websocket', 'polling'], reconnectionAttempts: 5 })
      socket.on('onlineUsers', (count: number) => setStats(p => ({ ...p, activeUsers: count })))
      socketRef.current = socket
    } catch { }
  }

  const loadAll = async () => {
    setLoading(true)
    try {
      const [statsRes, usersRes, itemsRes, appsRes, wdRes, rptRes, catsRes, vpsRes, txRes, plansRes, membRes, adsRes, couponsRes, featRes, settingsRes, campaignsRes, badgesRes, referralsRes, leaderboardRes, rewardsRes, teamsRes, collabsRes] = await Promise.all([
        fetch('/api/admin/stats').then(r => r.ok ? r.json() : {}).catch(() => ({})),
        fetch('/api/admin/users').then(r => r.ok ? r.json() : { users: [] }).catch(() => ({ users: [] })),
        fetch('/api/admin/items-all?limit=100').then(r => r.ok ? r.json() : []).catch(() => []),
        fetch('/api/admin/seller-applications').then(r => r.ok ? r.json() : { applications: [] }).catch(() => ({ applications: [] })),
        fetch('/api/admin/withdraw').then(r => r.ok ? r.json() : { requests: [] }).catch(() => ({ requests: [] })),
        fetch('/api/admin/reports').then(r => r.ok ? r.json() : { reports: [] }).catch(() => ({ reports: [] })),
        fetch('/api/categories').then(r => r.ok ? r.json() : []).catch(() => []),
        fetch('/api/admin/vps-orders').then(r => r.ok ? r.json() : []).catch(() => []),
        fetch('/api/admin/transactions').then(r => r.ok ? r.json() : []).catch(() => []),
        fetch('/api/admin/plans').then(r => r.ok ? r.json() : []).catch(() => []),
        fetch('/api/memberships').then(r => r.ok ? r.json() : []).catch(() => []),
        fetch('/api/admin/ads').then(r => r.ok ? r.json() : { ads: [] }).catch(() => ({ ads: [] })),
        fetch('/api/admin/coupons').then(r => r.ok ? r.json() : { coupons: [] }).catch(() => ({ coupons: [] })),
        fetch('/api/admin/feature-toggles').then(r => r.ok ? r.json() : { features: [] }).catch(() => ({ features: [] })),
        fetch('/api/admin/settings').then(r => r.ok ? r.json() : {}).catch(() => ({})),
        fetch('/api/admin/campaigns').then(r => r.ok ? r.json() : { campaigns: [] }).catch(() => ({ campaigns: [] })),
        fetch('/api/admin/badges').then(r => r.ok ? r.json() : { badges: [] }).catch(() => ({ badges: [] })),
        fetch('/api/admin/referrals').then(r => r.ok ? r.json() : {}).catch(() => ({})),
        fetch('/api/admin/leaderboard').then(r => r.ok ? r.json() : {}).catch(() => ({})),
        fetch('/api/admin/mystery-rewards').then(r => r.ok ? r.json() : { rewards: [], recentLogs: [] }).catch(() => ({ rewards: [], recentLogs: [] })),
        fetch('/api/admin/teams').then(r => r.ok ? r.json() : { teams: [] }).catch(() => ({ teams: [] })),
        fetch('/api/admin/collaborations').then(r => r.ok ? r.json() : { collaborations: [] }).catch(() => ({ collaborations: [] })),
      ])
      setStats({ ...statsRes, activeUsers: stats.activeUsers })
      setUsers(usersRes.users || [])
      setItems(Array.isArray(itemsRes) ? itemsRes : (itemsRes.items || []))
      setApplications(appsRes.applications || [])
      setWithdrawals(wdRes.requests || [])
      setReports(rptRes.reports || [])
      setCategories(Array.isArray(catsRes) ? catsRes : catsRes.categories || [])
      setVpsOrders(Array.isArray(vpsRes) ? vpsRes : (vpsRes.orders || []))
      setTransactions(Array.isArray(txRes) ? txRes : (txRes.transactions || []))
      setPlans(Array.isArray(plansRes) ? plansRes : (plansRes.plans || []))
      setMemberships(Array.isArray(membRes) ? membRes : (membRes.memberships || []))
      setAds(adsRes.ads || [])
      setCoupons(couponsRes.coupons || [])
      setFeatureToggles(featRes.features || [])
      setCampaignsList(campaignsRes.campaigns || [])
      setBadgesList(badgesRes.badges || [])
      setReferralStats(referralsRes || { totalReferrals: 0, totalEarnings: 0, topReferrers: [], recentReferrals: [] })
      setLeaderboardData(leaderboardRes || { topSellers: [], topBuyers: [], topItems: [] })
      setMysteryRewards(rewardsRes.rewards || [])
      setRewardLogs(rewardsRes.recentLogs || [])
      setTeamsList(teamsRes.teams || [])
      setCollaborationsList(collabsRes.collaborations || [])
      if (settingsRes && (settingsRes.siteName || settingsRes.maintenance !== undefined || settingsRes.id)) {
        setSiteSettings(prev => ({
          ...prev,
          siteName: settingsRes.siteName || prev.siteName,
          maintenance: settingsRes.maintenance ?? prev.maintenance,
          bkashNumber: settingsRes.bkashNumber || prev.bkashNumber,
          nagadNumber: settingsRes.nagadNumber || prev.nagadNumber,
          openAiApiKey: settingsRes.openAiApiKey || prev.openAiApiKey,
          privacyUrl: settingsRes.privacyUrl || prev.privacyUrl,
          helpCenterUrl: settingsRes.helpCenterUrl || prev.helpCenterUrl,
          documentationUrl: settingsRes.documentationUrl || prev.documentationUrl,
          contactUsUrl: settingsRes.contactUsUrl || prev.contactUsUrl,
          statusPageUrl: settingsRes.statusPageUrl || prev.statusPageUrl,
          discordUrl: settingsRes.discordUrl || prev.discordUrl,
          githubUrl: settingsRes.githubUrl || prev.githubUrl,
          twitterUrl: settingsRes.twitterUrl || prev.twitterUrl,
          privacyPolicy: settingsRes.privacyPolicy || prev.privacyPolicy,
          termsOfService: settingsRes.termsOfService || prev.termsOfService,
          guidelines: settingsRes.guidelines || prev.guidelines,
          dmcaUrl: settingsRes.dmcaUrl || prev.dmcaUrl,
        }))
      }
    } catch { toast.error('Failed to load admin data') } finally { setLoading(false) }
  }

  const updateItemStatus = async (id: string, status: string) => {
    const res = await fetch(`/api/admin/items/${id}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status }) })
    if (res.ok) { toast.success('Item updated'); loadAll() } else toast.error('Failed')
  }
  const updateUserRole = async (id: string, role: string) => {
    const res = await fetch(`/api/admin/users/${id}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ role }) })
    if (res.ok) { toast.success('Role updated'); loadAll() } else toast.error('Failed')
  }
  const toggleUserBan = async (id: string, ban: boolean) => {
    const res = await fetch(`/api/admin/users/${id}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ isBanned: ban }) })
    if (res.ok) { toast.success(ban ? 'User banned' : 'User unbanned'); loadAll() } else toast.error('Failed')
  }
  const processWithdrawal = async (id: string, status: 'APPROVED' | 'REJECTED') => {
    const adminNote = activeWdNote[id] || ''
    const res = await fetch('/api/admin/withdraw', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id, status, adminNote }) })
    if (res.ok) { toast.success(`Withdrawal ${status.toLowerCase()}`); setActiveWdNote(p => { const n = { ...p }; delete n[id]; return n }); loadAll() }
    else { const d = await res.json().catch(() => ({})); toast.error(d.error || 'Failed') }
  }
  const processApplication = async (id: string, status: 'APPROVED' | 'REJECTED') => {
    const adminNote = activeAppNote[id] || ''
    const res = await fetch('/api/admin/seller-applications', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id, status, adminNote }) })
    if (res.ok) { toast.success(`Application ${status.toLowerCase()}`); setActiveAppNote(p => { const n = { ...p }; delete n[id]; return n }); loadAll() } else toast.error('Failed')
  }
  const processReport = async (id: string, status: string) => {
    const res = await fetch('/api/admin/reports', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id, status }) })
    if (res.ok) { toast.success('Report updated'); loadAll() } else toast.error('Failed')
  }
  const addCategory = async () => {
    if (!newCategory.name) return toast.error('Name required')
    const res = await fetch('/api/admin/categories', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(newCategory) })
    if (res.ok) { toast.success('Category added'); setNewCategory({ name: '', description: '' }); loadAll() }
    else { const d = await res.json().catch(() => ({})); toast.error(d.error || 'Failed') }
  }
  const deleteCategory = async (id: string) => {
    if (!confirm('Delete this category?')) return
    const res = await fetch(`/api/admin/categories/${id}`, { method: 'DELETE' })
    if (res.ok) { toast.success('Category deleted'); loadAll() } else toast.error('Failed')
  }
  const sendAnnouncement = async () => {
    if (!announcement.trim()) return toast.error('Message required')
    const res = await fetch('/api/admin/announcements', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ message: announcement }) })
    if (res.ok) { const d = await res.json().catch(() => ({})); toast.success(`Announcement sent to ${d.sentTo || 'all'} users`); setAnnouncement('') } else toast.error('Failed')
  }
  const approveVpsOrder = async () => {
    if (!selectedVps) return
    setVpsApproving(true)
    try {
      let parsedInfo: any = {}
      if (vpsServerInfo.trim()) { try { parsedInfo = JSON.parse(vpsServerInfo) } catch { parsedInfo = vpsServerInfo } }
      const res = await fetch(`/api/admin/vps-orders/${selectedVps.id}/approve`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ serverInfo: parsedInfo }) })
      if (res.ok) { toast.success('VPS order approved'); setSelectedVps(null); setVpsServerInfo(''); loadAll() } else toast.error('Failed')
    } catch { toast.error('Failed') } finally { setVpsApproving(false) }
  }
  const rejectVpsOrder = async (id: string) => {
    const res = await fetch(`/api/admin/vps-orders/${id}/reject`, { method: 'POST' }).catch(() => null)
    if (res?.ok) { toast.success('VPS order rejected'); loadAll() } else toast.error('Failed')
  }
  const approveTx = async (id: string) => {
    const res = await fetch(`/api/admin/transactions/${id}/approve`, { method: 'POST' })
    if (res.ok) { toast.success('Transaction approved'); loadAll() } else toast.error('Failed')
  }
  const rejectTx = async (id: string) => {
    const res = await fetch(`/api/admin/transactions/${id}/reject`, { method: 'POST' })
    if (res.ok) { toast.success('Transaction rejected'); loadAll() } else toast.error('Failed')
  }
  const savePlan = async () => {
    if (!editPlan?.name) return toast.error('Name required')
    const method = editPlan.id ? 'PATCH' : 'POST'
    const url = editPlan.id ? `/api/admin/plans/${editPlan.id}` : '/api/admin/plans'
    const res = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(editPlan) })
    if (res.ok) { toast.success(editPlan.id ? 'Plan updated' : 'Plan created'); setEditPlan(null); loadAll() } else toast.error('Failed')
  }
  const deletePlan = async (id: string) => {
    if (!confirm('Delete this plan?')) return
    const res = await fetch(`/api/admin/plans/${id}`, { method: 'DELETE' })
    if (res.ok) { toast.success('Plan deleted'); loadAll() } else toast.error('Failed')
  }
  const saveMembership = async () => {
    if (!editMembership?.name) return toast.error('Name required')
    const method = editMembership.id ? 'PATCH' : 'POST'
    const url = editMembership.id ? `/api/memberships/${editMembership.id}` : '/api/memberships'
    const res = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(editMembership) })
    if (res.ok) { toast.success(editMembership.id ? 'Membership updated' : 'Membership created'); setEditMembership(null); loadAll() } else toast.error('Failed')
  }
  const deleteMembership = async (id: string) => {
    if (!confirm('Delete this membership?')) return
    const res = await fetch(`/api/memberships/${id}`, { method: 'DELETE' })
    if (res.ok) { toast.success('Membership deleted'); loadAll() } else toast.error('Failed')
  }

  const saveAd = async () => {
    if (!editAd?.title) return toast.error('Title required')
    const method = editAd.id ? 'PATCH' : 'POST'
    const url = editAd.id ? `/api/admin/ads/${editAd.id}` : '/api/admin/ads'
    const res = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(editAd) })
    if (res.ok) { toast.success(editAd.id ? 'Ad updated' : 'Ad created'); setEditAd(null); loadAll() } else toast.error('Failed')
  }
  const deleteAd = async (id: string) => {
    if (!confirm('Delete this ad?')) return
    const res = await fetch(`/api/admin/ads/${id}`, { method: 'DELETE' })
    if (res.ok) { toast.success('Ad deleted'); loadAll() } else toast.error('Failed')
  }
  const toggleAd = async (id: string, isActive: boolean) => {
    const res = await fetch(`/api/admin/ads/${id}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ isActive }) })
    if (res.ok) { toast.success(isActive ? 'Ad enabled' : 'Ad disabled'); loadAll() } else toast.error('Failed')
  }
  const saveCoupon = async () => {
    if (!editCoupon?.code || !editCoupon?.discountValue) return toast.error('Code and discount required')
    const res = await fetch('/api/admin/coupons', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(editCoupon) })
    if (res.ok) { toast.success('Coupon created'); setEditCoupon(null); loadAll() } else { const d = await res.json().catch(() => ({})); toast.error(d.error || 'Failed') }
  }
  const deleteCoupon = async (id: string) => {
    if (!confirm('Delete this coupon?')) return
    const res = await fetch('/api/admin/coupons', { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id }) })
    if (res.ok) { toast.success('Coupon deleted'); loadAll() } else toast.error('Failed')
  }
  const toggleCoupon = async (id: string, isActive: boolean) => {
    const res = await fetch('/api/admin/coupons', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id, isActive }) })
    if (res.ok) { toast.success(isActive ? 'Coupon enabled' : 'Coupon disabled'); loadAll() } else toast.error('Failed')
  }
  const toggleFeature = async (id: string, isEnabled: boolean) => {
    const res = await fetch('/api/admin/feature-toggles', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id, isEnabled }) })
    if (res.ok) { toast.success(isEnabled ? 'Feature enabled' : 'Feature disabled'); loadAll() } else toast.error('Failed')
  }
  const saveSettings = async () => {
    const res = await fetch('/api/admin/settings', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(siteSettings) })
    if (res.ok) toast.success('Settings saved'); else toast.error('Failed to save settings')
  }
  const toggleMaintenance = async (maintenance: boolean) => {
    await fetch('/api/admin/maintenance', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ maintenance })
    })

    // 🔥 save in localStorage
    localStorage.setItem('maintenance', maintenance.toString())

    window.location.reload()
  }

  const saveCampaign = async () => {
    if (!editCampaign?.name || !editCampaign?.startDate || !editCampaign?.endDate) return toast.error('Name and dates required')
    const method = editCampaign.id ? 'PUT' : 'POST'
    const url = editCampaign.id ? `/api/admin/campaigns/${editCampaign.id}` : '/api/admin/campaigns'
    const res = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(editCampaign) })
    if (res.ok) { toast.success(editCampaign.id ? 'Campaign updated' : 'Campaign created'); setEditCampaign(null); loadAll() } else toast.error('Failed')
  }
  const deleteCampaign = async (id: string) => {
    if (!confirm('Delete this campaign?')) return
    const res = await fetch(`/api/admin/campaigns/${id}`, { method: 'DELETE' })
    if (res.ok) { toast.success('Campaign deleted'); loadAll() } else toast.error('Failed')
  }
  const saveBadge = async () => {
    if (!editBadge?.name) return toast.error('Badge name required')
    const method = editBadge.id ? 'PUT' : 'POST'
    const url = editBadge.id ? `/api/admin/badges/${editBadge.id}` : '/api/admin/badges'
    const res = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(editBadge) })
    if (res.ok) { toast.success(editBadge.id ? 'Badge updated' : 'Badge created'); setEditBadge(null); loadAll() } else toast.error('Failed')
  }
  const deleteBadge = async (id: string) => {
    if (!confirm('Delete this badge?')) return
    const res = await fetch(`/api/admin/badges/${id}`, { method: 'DELETE' })
    if (res.ok) { toast.success('Badge deleted'); loadAll() } else toast.error('Failed')
  }
  const saveReward = async () => {
    if (!editReward?.name) return toast.error('Reward name required')
    const method = editReward.id ? 'PUT' : 'POST'
    const url = editReward.id ? `/api/admin/mystery-rewards/${editReward.id}` : '/api/admin/mystery-rewards'
    const res = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(editReward) })
    if (res.ok) { toast.success(editReward.id ? 'Reward updated' : 'Reward created'); setEditReward(null); loadAll() } else toast.error('Failed')
  }
  const deleteReward = async (id: string) => {
    if (!confirm('Delete this reward?')) return
    const res = await fetch(`/api/admin/mystery-rewards/${id}`, { method: 'DELETE' })
    if (res.ok) { toast.success('Reward deleted'); loadAll() } else toast.error('Failed')
  }

  const pendingApps = applications.filter(a => a.status === 'PENDING').length
  const pendingWds = withdrawals.filter(w => w.status === 'PENDING').length
  const pendingRpts = reports.filter(r => r.status === 'PENDING').length
  const pendingVps = vpsOrders.filter(o => o.status === 'PENDING').length
  const pendingTx = transactions.filter(t => t.status === 'PENDING').length
  const filteredUsers = users.filter(u => !searchUsers || u.username?.toLowerCase().includes(searchUsers.toLowerCase()) || u.email?.toLowerCase().includes(searchUsers.toLowerCase()))
  const filteredItems = items.filter(i => !searchItems || i.title?.toLowerCase().includes(searchItems.toLowerCase()) || i.author?.username?.toLowerCase().includes(searchItems.toLowerCase()))

  const badgeCounts: Partial<Record<Section, number>> = {
    applications: pendingApps, withdrawals: pendingWds, reports: pendingRpts,
    vps: pendingVps, transactions: pendingTx, items: stats.pendingItems,
  }

  if (authStatus === 'loading' || loading) return (
    <div className="min-h-screen bg-[#060611] flex items-center justify-center">
      <div className="text-center">
        <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-purple-600 to-blue-600 flex items-center justify-center mx-auto mb-4 animate-pulse">
          <Shield className="w-6 h-6 text-white" />
        </div>
        <Loader2 className="w-5 h-5 animate-spin text-purple-400 mx-auto mb-2" />
        <p className="text-white/30 text-xs">Loading admin panel...</p>
      </div>
    </div>
  )

  const navClick = (key: Section) => { setActiveSection(key); setSidebarOpen(false) }

  return (
    <div className="min-h-screen bg-[#060611] text-white flex">
      {sidebarOpen && <div className="fixed inset-0 bg-black/60 z-40 lg:hidden" onClick={() => setSidebarOpen(false)} />}

      <aside className={`fixed lg:sticky top-0 left-0 z-50 lg:z-auto h-screen w-[260px] bg-[#0a0a16]/95 backdrop-blur-xl border-r border-white/[0.06] flex flex-col transition-transform duration-300 ${sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}`}>
        <div className="p-5 flex items-center gap-3 border-b border-white/[0.06]">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-purple-600 to-blue-600 flex items-center justify-center flex-shrink-0">
            <Shield className="w-4 h-4 text-white" />
          </div>
          <div className="flex-1 min-w-0">
            <h1 className="text-sm font-bold text-white tracking-tight">Admin Panel</h1>
            <p className="text-[10px] text-white/30 truncate">{session?.user?.email}</p>
          </div>
          <button onClick={() => setSidebarOpen(false)} className="lg:hidden text-white/40 hover:text-white p-1"><X className="w-4 h-4" /></button>
        </div>

        <nav className="flex-1 overflow-y-auto p-3 space-y-1">
          {['Main', 'Management', 'Config', 'Marketing', 'Engagement', 'System'].map(group => (
            <div key={group}>
              <p className="text-[9px] font-semibold uppercase tracking-[0.15em] text-white/20 px-3 pt-4 pb-2">{group}</p>
              {NAV_SECTIONS.filter(s => s.group === group).map(({ key, label, icon: Icon }) => {
                const badge = badgeCounts[key] || 0
                const active = activeSection === key
                return (
                  <button key={key} onClick={() => navClick(key)} className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-[13px] font-medium transition-all duration-200 ${active ? 'bg-gradient-to-r from-purple-600/20 to-blue-600/10 text-white shadow-lg shadow-purple-900/10 border border-purple-500/10' : 'text-white/40 hover:text-white/80 hover:bg-white/[0.04] border border-transparent'}`}>
                    <Icon className={`w-4 h-4 flex-shrink-0 ${active ? 'text-purple-400' : ''}`} />
                    <span className="flex-1 text-left">{label}</span>
                    {badge > 0 && <span className="text-[9px] bg-red-500/20 text-red-400 border border-red-500/20 rounded-full px-1.5 py-0.5 font-semibold min-w-[20px] text-center">{badge}</span>}
                  </button>
                )
              })}
            </div>
          ))}
        </nav>

        <div className="p-4 border-t border-white/[0.06]">
          <div className="flex items-center gap-2 bg-emerald-500/5 border border-emerald-500/10 rounded-xl px-3 py-2">
            <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-[11px] text-emerald-400 font-medium">{stats.activeUsers} online now</span>
          </div>
          <Link href="/" className="flex items-center gap-2 mt-2 text-white/30 hover:text-white/60 text-[11px] px-3 py-2 rounded-xl hover:bg-white/[0.04] transition-colors">
            <ChevronLeft className="w-3 h-3" /> Back to site
          </Link>
        </div>
      </aside>

      <main className="flex-1 min-w-0">
        <header className="sticky top-0 z-30 bg-[#060611]/80 backdrop-blur-xl border-b border-white/[0.06] px-4 lg:px-8 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button onClick={() => setSidebarOpen(true)} className="lg:hidden text-white/40 hover:text-white p-1.5 rounded-lg hover:bg-white/[0.06]"><Menu className="w-5 h-5" /></button>
            <div>
              <h2 className="text-base font-bold text-white capitalize">{activeSection === 'overview' ? 'Dashboard' : NAV_SECTIONS.find(s => s.key === activeSection)?.label}</h2>
              <p className="text-[11px] text-white/30 hidden sm:block">{new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button onClick={loadAll} size="sm" variant="ghost" className="h-8 text-white/30 hover:text-white gap-1.5 text-xs rounded-xl hover:bg-white/[0.06]">
              <RefreshCw className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">Refresh</span>
            </Button>
          </div>
        </header>

        <div className="p-4 lg:p-8 max-w-[1400px]">
          {activeSection === 'overview' && <OverviewSection stats={stats} pendingApps={pendingApps} pendingWds={pendingWds} pendingRpts={pendingRpts} pendingVps={pendingVps} pendingTx={pendingTx} items={items} users={users} setActiveSection={setActiveSection} />}
          {activeSection === 'items' && <ItemsSection items={filteredItems} searchItems={searchItems} setSearchItems={setSearchItems} updateItemStatus={updateItemStatus} />}
          {activeSection === 'users' && <UsersSection users={filteredUsers} searchUsers={searchUsers} setSearchUsers={setSearchUsers} updateUserRole={updateUserRole} toggleUserBan={toggleUserBan} />}
          {activeSection === 'applications' && <ApplicationsSection applications={applications} activeAppNote={activeAppNote} setActiveAppNote={setActiveAppNote} processApplication={processApplication} />}
          {activeSection === 'withdrawals' && <WithdrawalsSection withdrawals={withdrawals} activeWdNote={activeWdNote} setActiveWdNote={setActiveWdNote} processWithdrawal={processWithdrawal} />}
          {activeSection === 'reports' && <ReportsSection reports={reports} processReport={processReport} />}
          {activeSection === 'categories' && <CategoriesSection categories={categories} newCategory={newCategory} setNewCategory={setNewCategory} addCategory={addCategory} deleteCategory={deleteCategory} />}
          {activeSection === 'vps' && <VpsSection vpsOrders={vpsOrders} selectedVps={selectedVps} setSelectedVps={setSelectedVps} vpsServerInfo={vpsServerInfo} setVpsServerInfo={setVpsServerInfo} vpsApproving={vpsApproving} approveVpsOrder={approveVpsOrder} rejectVpsOrder={rejectVpsOrder} />}
          {activeSection === 'transactions' && <TransactionsSection transactions={transactions} approveTx={approveTx} rejectTx={rejectTx} />}
          {activeSection === 'plans' && <PlansSection plans={plans} editPlan={editPlan} setEditPlan={setEditPlan} savePlan={savePlan} deletePlan={deletePlan} />}
          {activeSection === 'memberships' && <MembershipsSection memberships={memberships} editMembership={editMembership} setEditMembership={setEditMembership} saveMembership={saveMembership} deleteMembership={deleteMembership} />}
          {activeSection === 'ads' && <AdsSection ads={ads} editAd={editAd} setEditAd={setEditAd} saveAd={saveAd} deleteAd={deleteAd} toggleAd={toggleAd} />}
          {activeSection === 'coupons' && <CouponsSection coupons={coupons} editCoupon={editCoupon} setEditCoupon={setEditCoupon} saveCoupon={saveCoupon} deleteCoupon={deleteCoupon} toggleCoupon={toggleCoupon} />}
          {activeSection === 'features' && <FeatureTogglesSection features={featureToggles} toggleFeature={toggleFeature} />}
          {activeSection === 'settings' && <SettingsSection announcement={announcement} setAnnouncement={setAnnouncement} sendAnnouncement={sendAnnouncement} siteSettings={siteSettings} setSiteSettings={setSiteSettings} toggleMaintenance={toggleMaintenance} saveSettings={saveSettings} />}
          {activeSection === 'campaigns' && <CampaignsSection campaigns={campaignsList} editCampaign={editCampaign} setEditCampaign={setEditCampaign} saveCampaign={saveCampaign} deleteCampaign={deleteCampaign} />}
          {activeSection === 'badges' && <BadgesSection badges={badgesList} editBadge={editBadge} setEditBadge={setEditBadge} saveBadge={saveBadge} deleteBadge={deleteBadge} />}
          {activeSection === 'referrals' && <ReferralsSection stats={referralStats} />}
          {activeSection === 'leaderboard' && <LeaderboardSection data={leaderboardData} />}
          {activeSection === 'mysteryRewards' && <MysteryRewardsSection rewards={mysteryRewards} logs={rewardLogs} editReward={editReward} setEditReward={setEditReward} saveReward={saveReward} deleteReward={deleteReward} />}
          {activeSection === 'teams' && <TeamsSection teams={teamsList} />}
          {activeSection === 'collaborations' && <CollaborationsSection collaborations={collaborationsList} />}
        </div>
      </main>
    </div>
  )
}

function SectionCard({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  return <div className={`bg-[#0c0c1a]/80 border border-white/[0.06] rounded-2xl ${className}`}>{children}</div>
}

function SectionHeader({ title, description, action }: { title: string; description?: string; action?: React.ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-4 mb-6">
      <div>
        <h3 className="text-lg font-bold text-white">{title}</h3>
        {description && <p className="text-xs text-white/30 mt-0.5">{description}</p>}
      </div>
      {action}
    </div>
  )
}

function EmptyState({ icon: Icon, message }: { icon: any; message: string }) {
  return (
    <div className="text-center py-16">
      <div className="w-12 h-12 rounded-2xl bg-white/[0.03] border border-white/[0.06] flex items-center justify-center mx-auto mb-3">
        <Icon className="w-5 h-5 text-white/20" />
      </div>
      <p className="text-sm text-white/20">{message}</p>
    </div>
  )
}

function OverviewSection({ stats, pendingApps, pendingWds, pendingRpts, pendingVps, pendingTx, items, users, setActiveSection }: any) {
  const statCards = [
    { icon: Users, label: 'Total Users', value: stats.totalUsers?.toLocaleString() || '0', color: 'from-blue-600 to-cyan-600', sub: `${stats.activeUsers || 0} online` },
    { icon: Package, label: 'Total Items', value: stats.totalItems?.toLocaleString() || '0', color: 'from-purple-600 to-violet-600', sub: `${stats.pendingItems || 0} pending` },
    { icon: Download, label: 'Downloads', value: (stats.totalDownloads || 0) >= 1000 ? ((stats.totalDownloads || 0) / 1000).toFixed(1) + 'K' : String(stats.totalDownloads || 0), color: 'from-cyan-600 to-teal-600', sub: 'all time' },
    { icon: DollarSign, label: 'Revenue', value: `$${(stats.totalRevenue || 0).toFixed(0)}`, color: 'from-emerald-600 to-green-600', sub: `${stats.totalOrders || 0} orders` },
  ]

  const pendingActions = [
    { label: 'Seller Applications', count: pendingApps, section: 'applications', icon: UserCheck, color: 'text-blue-400 bg-blue-500/10 border-blue-500/15' },
    { label: 'Withdrawals', count: pendingWds, section: 'withdrawals', icon: CreditCard, color: 'text-amber-400 bg-amber-500/10 border-amber-500/15' },
    { label: 'VPS Orders', count: pendingVps, section: 'vps', icon: Server, color: 'text-purple-400 bg-purple-500/10 border-purple-500/15' },
    { label: 'Transactions', count: pendingTx, section: 'transactions', icon: DollarSign, color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/15' },
    { label: 'Reports', count: pendingRpts, section: 'reports', icon: AlertTriangle, color: 'text-red-400 bg-red-500/10 border-red-500/15' },
  ].filter(a => a.count > 0)

  const recentItems = items.slice(0, 5)
  const recentUsers = users.slice(0, 5)

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-4">
        {statCards.map(({ icon: Icon, label, value, color, sub }) => (
          <SectionCard key={label} className="p-4 lg:p-5">
            <div className="flex items-start justify-between mb-3">
              <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${color} flex items-center justify-center shadow-lg`}>
                <Icon className="w-5 h-5 text-white" />
              </div>
            </div>
            <p className="text-xl lg:text-2xl font-bold text-white tracking-tight">{value}</p>
            <div className="flex items-center justify-between mt-1">
              <p className="text-[11px] text-white/30">{label}</p>
              <p className="text-[10px] text-white/20">{sub}</p>
            </div>
          </SectionCard>
        ))}
      </div>

      {pendingActions.length > 0 && (
        <SectionCard className="p-4 lg:p-5">
          <h4 className="text-sm font-semibold text-white mb-3 flex items-center gap-2">
            <Activity className="w-4 h-4 text-amber-400" /> Pending Actions
          </h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
            {pendingActions.map(({ label, count, section, icon: Icon, color }) => (
              <button key={section} onClick={() => setActiveSection(section)} className={`flex items-center gap-3 p-3 rounded-xl border transition-all hover:scale-[1.02] active:scale-[0.98] ${color}`}>
                <Icon className="w-4 h-4 flex-shrink-0" />
                <span className="text-xs font-medium flex-1 text-left">{label}</span>
                <span className="text-lg font-bold">{count}</span>
              </button>
            ))}
          </div>
        </SectionCard>
      )}

      <div className="grid lg:grid-cols-2 gap-4">
        <SectionCard className="p-4 lg:p-5">
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-sm font-semibold text-white flex items-center gap-2"><Package className="w-4 h-4 text-purple-400" />Recent Items</h4>
            <button onClick={() => setActiveSection('items')} className="text-[10px] text-purple-400 hover:text-purple-300 font-medium">View All</button>
          </div>
          {recentItems.length === 0 ? <p className="text-xs text-white/20 text-center py-6">No items yet</p> : (
            <div className="space-y-2">
              {recentItems.map((item: Item) => (
                <div key={item.id} className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-white/[0.03] transition-colors">
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium text-white/80 truncate">{item.title}</p>
                    <p className="text-[10px] text-white/30">by {item.author?.username} · {item.price === 0 ? 'Free' : `$${item.price}`}</p>
                  </div>
                  <Badge className={`text-[8px] h-4 border ${STATUS_COLORS[item.status] || 'bg-white/5 text-white/40 border-white/10'}`}>{item.status}</Badge>
                </div>
              ))}
            </div>
          )}
        </SectionCard>

        <SectionCard className="p-4 lg:p-5">
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-sm font-semibold text-white flex items-center gap-2"><Users className="w-4 h-4 text-blue-400" />Recent Users</h4>
            <button onClick={() => setActiveSection('users')} className="text-[10px] text-blue-400 hover:text-blue-300 font-medium">View All</button>
          </div>
          {recentUsers.length === 0 ? <p className="text-xs text-white/20 text-center py-6">No users yet</p> : (
            <div className="space-y-2">
              {recentUsers.map((user: User) => (
                <div key={user.id} className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-white/[0.03] transition-colors">
                  <Avatar className="w-7 h-7 rounded-lg flex-shrink-0">
                    <AvatarFallback className="bg-gradient-to-br from-purple-900 to-blue-900 text-white text-[10px] rounded-lg">{user.username?.[0]?.toUpperCase()}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5">
                      <p className="text-xs font-medium text-white/80 truncate">{user.username}</p>
                      {user.isVerified && <CheckCircle className="w-3 h-3 text-blue-400 flex-shrink-0" />}
                    </div>
                    <p className="text-[10px] text-white/30">{user.email}</p>
                  </div>
                  <Badge className="text-[8px] h-4 bg-white/5 text-white/30 border-white/10">{user.role}</Badge>
                </div>
              ))}
            </div>
          )}
        </SectionCard>
      </div>

      <SectionCard className="p-4 lg:p-5">
        <h4 className="text-sm font-semibold text-white mb-4 flex items-center gap-2"><BarChart3 className="w-4 h-4 text-emerald-400" />Feature Status</h4>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2">
          {[
            { name: 'Seller System', ok: true }, { name: 'Buyer/Cart/Checkout', ok: true },
            { name: 'Reviews & Ratings', ok: true }, { name: 'Search & Filter', ok: true },
            { name: 'Secure Downloads', ok: true }, { name: 'Earnings/Wallet', ok: true },
            { name: 'Custom Orders', ok: true }, { name: 'Freebies', ok: true },
            { name: 'Follow System', ok: true }, { name: 'Verified Sellers', ok: true },
            { name: 'Seller Levels', ok: true }, { name: 'Chat System', ok: true },
            { name: 'Notifications', ok: true }, { name: 'Wishlist', ok: true },
            { name: 'Creator Profiles', ok: true }, { name: 'Coupons', ok: true },
            { name: 'Reports', ok: true }, { name: 'VPS Hosting', ok: true },
            { name: 'Memberships', ok: true }, { name: 'Ads/Boost', ok: true },
            { name: 'AI SEO Generator', ok: true }, { name: 'Order Tracking', ok: true },
          ].map(f => (
            <div key={f.name} className={`flex items-center gap-2 px-3 py-2 rounded-lg border text-[11px] ${f.ok ? 'bg-emerald-500/5 border-emerald-500/10 text-emerald-400' : 'bg-red-500/5 border-red-500/10 text-red-400'}`}>
              {f.ok ? <CheckCircle className="w-3 h-3 flex-shrink-0" /> : <XCircle className="w-3 h-3 flex-shrink-0" />}
              <span className="truncate">{f.name}</span>
            </div>
          ))}
        </div>
      </SectionCard>
    </div>
  )
}

function ItemsSection({ items, searchItems, setSearchItems, updateItemStatus }: any) {
  return (
    <div>
      <SectionHeader title="Items Management" description={`${items.length} items total`} />
      <div className="relative max-w-sm mb-4">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/20" />
        <Input value={searchItems} onChange={(e: any) => setSearchItems(e.target.value)} placeholder="Search items..." className="pl-9 h-9 bg-white/[0.04] border-white/[0.08] text-white rounded-xl text-sm" />
      </div>
      <SectionCard className="divide-y divide-white/[0.04]">
        {items.length === 0 ? <EmptyState icon={Package} message="No items found" /> : items.map((item: Item) => (
          <div key={item.id} className="flex items-center gap-3 p-3 lg:p-4 hover:bg-white/[0.02] transition-colors">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-sm font-medium text-white/90 truncate">{item.title}</span>
                <Badge className={`text-[8px] h-4 border ${STATUS_COLORS[item.status] || 'bg-white/5 text-white/40 border-white/10'}`}>{item.status}</Badge>
              </div>
              <p className="text-[11px] text-white/30 mt-0.5">by {item.author?.username} · {item.downloads} downloads · {item.price === 0 ? 'Free' : `$${item.price}`} · {new Date(item.createdAt).toLocaleDateString()}</p>
            </div>
            <div className="flex items-center gap-1.5 flex-shrink-0">
              <Link href={`/items/${item.slug}`}><Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-white/20 hover:text-white rounded-lg"><Eye className="h-3.5 w-3.5" /></Button></Link>
              {item.status === 'PENDING' && <>
                <Button onClick={() => updateItemStatus(item.id, 'APPROVED')} size="sm" className="h-7 text-[10px] bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-400 border-0 rounded-lg px-2.5 gap-1"><Check className="h-3 w-3" /><span className="hidden sm:inline">Approve</span></Button>
                <Button onClick={() => updateItemStatus(item.id, 'REJECTED')} size="sm" className="h-7 text-[10px] bg-red-500/15 hover:bg-red-500/25 text-red-400 border-0 rounded-lg px-2.5 gap-1"><X className="h-3 w-3" /><span className="hidden sm:inline">Reject</span></Button>
              </>}
              {item.status === 'APPROVED' && <Button onClick={() => updateItemStatus(item.id, 'ARCHIVED')} size="sm" className="h-7 text-[10px] bg-white/5 hover:bg-white/10 text-white/40 border-0 rounded-lg px-2.5">Archive</Button>}
            </div>
          </div>
        ))}
      </SectionCard>
    </div>
  )
}

function UsersSection({ users, searchUsers, setSearchUsers, updateUserRole, toggleUserBan }: any) {
  return (
    <div>
      <SectionHeader title="User Management" description={`${users.length} users total`} />
      <div className="relative max-w-sm mb-4">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/20" />
        <Input value={searchUsers} onChange={(e: any) => setSearchUsers(e.target.value)} placeholder="Search users..." className="pl-9 h-9 bg-white/[0.04] border-white/[0.08] text-white rounded-xl text-sm" />
      </div>
      <SectionCard className="divide-y divide-white/[0.04]">
        {users.length === 0 ? <EmptyState icon={Users} message="No users found" /> : users.map((user: User) => (
          <div key={user.id} className="p-3 lg:p-4 hover:bg-white/[0.02] transition-colors">
            <div className="flex items-start gap-3">
              <Avatar className="w-9 h-9 rounded-xl flex-shrink-0">
                <AvatarFallback className="bg-gradient-to-br from-purple-900 to-blue-900 text-white text-xs rounded-xl">{user.username?.[0]?.toUpperCase()}</AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <span className="text-sm font-medium text-white/90">{user.username}</span>
                  {user.isVerified && <CheckCircle className="w-3.5 h-3.5 text-blue-400" />}
                  {user.isBanned && <Badge className="text-[8px] h-4 bg-red-500/10 text-red-400 border-red-500/20">Banned</Badge>}
                  <Badge className="text-[8px] h-4 bg-white/5 text-white/30 border-white/10">{user.role}</Badge>
                </div>
                <p className="text-[11px] text-white/30 mt-0.5 truncate">{user.email} · Wallet: ${user.walletBalance?.toFixed(2) || '0.00'} · Level {user.sellerLevel || 0} · {user._count?.items || 0} items</p>
              </div>
            </div>
            <div className="flex items-center gap-2 mt-2.5 pl-12 flex-wrap">
              <Select value={user.role} onValueChange={(v: string) => updateUserRole(user.id, v)}>
                <SelectTrigger className="h-7 w-28 bg-white/[0.04] border-white/[0.08] text-white rounded-lg text-[10px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-[#0f0f1a] border-white/10">
                  {['USER', 'CREATOR', 'MODERATOR', 'ADMIN'].map(r => <SelectItem key={r} value={r} className="text-white/80 text-xs">{r}</SelectItem>)}
                </SelectContent>
              </Select>
              <Button onClick={() => toggleUserBan(user.id, !user.isBanned)} size="sm" className={`h-7 text-[10px] border-0 rounded-lg px-3 ${user.isBanned ? 'bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-400' : 'bg-red-500/15 hover:bg-red-500/25 text-red-400'}`}>
                {user.isBanned ? 'Unban' : 'Ban'}
              </Button>
              <Link href={`/profile/${user.username}`}><Button size="sm" variant="ghost" className="h-7 text-[10px] text-white/20 hover:text-white/60 rounded-lg px-2.5 gap-1"><Eye className="h-3 w-3" />Profile</Button></Link>
            </div>
          </div>
        ))}
      </SectionCard>
    </div>
  )
}

function ApplicationsSection({ applications, activeAppNote, setActiveAppNote, processApplication }: any) {
  return (
    <div>
      <SectionHeader title="Seller Applications" description={`${applications.filter((a: Application) => a.status === 'PENDING').length} pending review`} />
      <SectionCard className="divide-y divide-white/[0.04]">
        {applications.length === 0 ? <EmptyState icon={UserCheck} message="No seller applications" /> : applications.map((app: Application) => (
          <div key={app.id} className="p-4 hover:bg-white/[0.02] transition-colors">
            <div className="flex items-start gap-3">
              <Avatar className="w-10 h-10 rounded-xl flex-shrink-0">
                {app.user.avatar && <AvatarImage src={app.user.avatar} />}
                <AvatarFallback className="bg-gradient-to-br from-purple-900 to-blue-900 text-white text-sm rounded-xl">{app.user.username?.[0]?.toUpperCase()}</AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-sm font-semibold text-white">{app.displayName || app.user.username}</span>
                  <Badge className={`text-[8px] h-4 border ${STATUS_COLORS[app.status] || ''}`}>{app.status}</Badge>
                </div>
                <p className="text-[11px] text-white/30 mt-0.5">{app.user.email} · Applied {new Date(app.createdAt).toLocaleDateString()}</p>
                <p className="text-xs text-white/50 mt-2 line-clamp-3 leading-relaxed">{app.experience}</p>
                {app.status === 'PENDING' && (
                  <div className="mt-3 flex items-center gap-2 flex-wrap">
                    <Input value={activeAppNote[app.id] || ''} onChange={(e: any) => setActiveAppNote((p: any) => ({ ...p, [app.id]: e.target.value }))} placeholder="Admin note (optional)..." className="flex-1 h-8 bg-white/[0.04] border-white/[0.08] text-white rounded-lg text-xs min-w-[160px]" />
                    <Button onClick={() => processApplication(app.id, 'APPROVED')} size="sm" className="h-8 text-xs bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-400 border-0 rounded-lg gap-1.5"><Check className="h-3.5 w-3.5" />Approve</Button>
                    <Button onClick={() => processApplication(app.id, 'REJECTED')} size="sm" className="h-8 text-xs bg-red-500/15 hover:bg-red-500/25 text-red-400 border-0 rounded-lg gap-1.5"><X className="h-3.5 w-3.5" />Reject</Button>
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </SectionCard>
    </div>
  )
}

function WithdrawalsSection({ withdrawals, activeWdNote, setActiveWdNote, processWithdrawal }: any) {
  return (
    <div>
      <SectionHeader title="Withdrawal Requests" description={`${withdrawals.filter((w: Withdrawal) => w.status === 'PENDING').length} pending`} />
      <SectionCard className="divide-y divide-white/[0.04]">
        {withdrawals.length === 0 ? <EmptyState icon={CreditCard} message="No withdrawal requests" /> : withdrawals.map((wd: Withdrawal) => (
          <div key={wd.id} className="p-4 hover:bg-white/[0.02] transition-colors">
            <div className="flex items-start gap-3">
              <div className={`w-10 h-10 rounded-xl flex-shrink-0 flex items-center justify-center ${wd.status === 'PENDING' ? 'bg-amber-500/10' : wd.status === 'APPROVED' ? 'bg-emerald-500/10' : 'bg-red-500/10'}`}>
                {wd.status === 'PENDING' ? <Clock className="w-4 h-4 text-amber-400" /> : wd.status === 'APPROVED' ? <CheckCircle className="w-4 h-4 text-emerald-400" /> : <XCircle className="w-4 h-4 text-red-400" />}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-sm font-semibold text-white">{wd.user.username}</span>
                  <Badge className={`text-[8px] h-4 border ${STATUS_COLORS[wd.status] || ''}`}>{wd.status}</Badge>
                  <span className="text-sm font-bold text-emerald-400">${wd.amount.toFixed(2)}</span>
                </div>
                <p className="text-[11px] text-white/30 mt-0.5">{wd.user.email} · via <span className="capitalize font-medium text-white/50">{wd.method}</span>: <span className="font-mono">{wd.accountInfo}</span> · {new Date(wd.createdAt).toLocaleDateString()}</p>
                {wd.adminNote && <p className="text-[11px] text-white/40 mt-1 italic">Note: {wd.adminNote}</p>}
                {wd.status === 'PENDING' && (
                  <div className="mt-3 flex items-center gap-2 flex-wrap">
                    <Input value={activeWdNote[wd.id] || ''} onChange={(e: any) => setActiveWdNote((p: any) => ({ ...p, [wd.id]: e.target.value }))} placeholder="Admin note (optional)..." className="flex-1 h-8 bg-white/[0.04] border-white/[0.08] text-white rounded-lg text-xs min-w-[160px]" />
                    <Button onClick={() => processWithdrawal(wd.id, 'APPROVED')} size="sm" className="h-8 text-xs bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-400 border-0 rounded-lg gap-1.5"><Check className="h-3.5 w-3.5" />Approve</Button>
                    <Button onClick={() => processWithdrawal(wd.id, 'REJECTED')} size="sm" className="h-8 text-xs bg-red-500/15 hover:bg-red-500/25 text-red-400 border-0 rounded-lg gap-1.5"><X className="h-3.5 w-3.5" />Reject</Button>
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </SectionCard>
    </div>
  )
}

function ReportsSection({ reports, processReport }: any) {
  return (
    <div>
      <SectionHeader title="Reports & Moderation" description={`${reports.filter((r: Report) => r.status === 'PENDING').length} need review`} />
      <SectionCard className="divide-y divide-white/[0.04]">
        {reports.length === 0 ? <EmptyState icon={AlertTriangle} message="No reports" /> : reports.map((rpt: Report) => (
          <div key={rpt.id} className="p-4 hover:bg-white/[0.02] transition-colors">
            <div className="flex items-start justify-between gap-3 flex-wrap">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0" />
                  <span className="text-sm font-semibold text-white">{rpt.reason}</span>
                  <Badge className={`text-[8px] h-4 border ${STATUS_COLORS[rpt.status] || ''}`}>{rpt.status}</Badge>
                </div>
                <p className="text-[11px] text-white/30 mt-1">
                  by {rpt.reporter?.username}
                  {rpt.reportedUser && ` · against ${rpt.reportedUser.username}`}
                  {rpt.item && <> · item: <Link href={`/items/${rpt.item.slug}`} className="text-purple-400 hover:underline">{rpt.item.title}</Link></>}
                  {' '}· {new Date(rpt.createdAt).toLocaleDateString()}
                </p>
                {rpt.details && <p className="text-[11px] text-white/40 mt-1.5 italic leading-relaxed">"{rpt.details}"</p>}
              </div>
              {rpt.status === 'PENDING' && (
                <div className="flex gap-2 flex-shrink-0">
                  <Button onClick={() => processReport(rpt.id, 'RESOLVED')} size="sm" className="h-7 text-[10px] bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-400 border-0 rounded-lg px-2.5">Resolve</Button>
                  <Button onClick={() => processReport(rpt.id, 'DISMISSED')} size="sm" className="h-7 text-[10px] bg-white/5 hover:bg-white/10 text-white/40 border-0 rounded-lg px-2.5">Dismiss</Button>
                </div>
              )}
            </div>
          </div>
        ))}
      </SectionCard>
    </div>
  )
}

function CategoriesSection({ categories, newCategory, setNewCategory, addCategory, deleteCategory }: any) {
  return (
    <div>
      <SectionHeader title="Categories" description={`${categories.length} categories configured`} />
      <div className="grid lg:grid-cols-3 gap-4">
        <SectionCard className="p-5 lg:col-span-1">
          <h4 className="text-sm font-semibold text-white mb-4 flex items-center gap-2"><Plus className="w-4 h-4 text-purple-400" />Add Category</h4>
          <div className="space-y-3">
            <div>
              <Label className="text-white/40 text-[11px] mb-1.5 block">Name</Label>
              <Input value={newCategory.name} onChange={(e: any) => setNewCategory((p: any) => ({ ...p, name: e.target.value }))} placeholder="e.g. Logos" className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" />
            </div>
            <div>
              <Label className="text-white/40 text-[11px] mb-1.5 block">Description</Label>
              <Textarea value={newCategory.description} onChange={(e: any) => setNewCategory((p: any) => ({ ...p, description: e.target.value }))} placeholder="Short description..." className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl resize-none" rows={2} />
            </div>
            <Button onClick={addCategory} className="w-full bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl text-xs h-9">Add Category</Button>
          </div>
        </SectionCard>
        <SectionCard className="lg:col-span-2 divide-y divide-white/[0.04]">
          {categories.length === 0 ? <EmptyState icon={FolderOpen} message="No categories" /> : categories.map((cat: any) => (
            <div key={cat.id} className="flex items-center justify-between p-3.5 hover:bg-white/[0.02] transition-colors">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-purple-500/10 flex items-center justify-center flex-shrink-0">
                  <FolderOpen className="w-4 h-4 text-purple-400" />
                </div>
                <div>
                  <p className="text-sm font-medium text-white">{cat.name}</p>
                  <p className="text-[10px] text-white/25">{cat.slug} · {cat._count?.items || 0} items</p>
                </div>
              </div>
              <Button onClick={() => deleteCategory(cat.id)} size="sm" variant="ghost" className="h-7 w-7 p-0 text-red-400/30 hover:text-red-400 hover:bg-red-500/10 rounded-lg"><Trash2 className="h-3.5 w-3.5" /></Button>
            </div>
          ))}
        </SectionCard>
      </div>
    </div>
  )
}

function VpsSection({ vpsOrders, selectedVps, setSelectedVps, vpsServerInfo, setVpsServerInfo, vpsApproving, approveVpsOrder, rejectVpsOrder }: any) {
  return (
    <div>
      <SectionHeader title="VPS Orders" description={`${vpsOrders.filter((o: VpsOrder) => o.status === 'PENDING').length} pending`} />
      <SectionCard className="divide-y divide-white/[0.04]">
        {vpsOrders.length === 0 ? <EmptyState icon={Server} message="No VPS orders" /> : vpsOrders.map((order: VpsOrder) => (
          <div key={order.id} className="p-4 hover:bg-white/[0.02] transition-colors">
            <div className="flex items-start gap-3">
              <div className={`w-10 h-10 rounded-xl flex-shrink-0 flex items-center justify-center ${order.status === 'PENDING' ? 'bg-amber-500/10' : order.status === 'APPROVED' ? 'bg-emerald-500/10' : 'bg-red-500/10'}`}>
                <Server className={`w-4 h-4 ${order.status === 'PENDING' ? 'text-amber-400' : order.status === 'APPROVED' ? 'text-emerald-400' : 'text-red-400'}`} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-sm font-medium text-white/90">{order.user?.username || order.userId}</span>
                  <Badge className={`text-[8px] h-4 border ${STATUS_COLORS[order.status] || 'bg-white/5 text-white/40 border-white/10'}`}>{order.status}</Badge>
                  <span className="text-sm font-bold text-emerald-400">${order.amount}</span>
                </div>
                <p className="text-[11px] text-white/30 mt-0.5">Plan: {order.plan?.name || 'N/A'} · {order.paymentMethod} {order.transactionRef && `· Ref: ${order.transactionRef}`} · {new Date(order.createdAt).toLocaleDateString()}</p>
                {order.status === 'APPROVED' && order.serverInfo && (
                  <div className="mt-2">
                    <p className="text-[10px] text-white/30 mb-1">Server Info:</p>
                    <pre className="text-[10px] text-white/50 bg-white/[0.03] rounded-lg p-2 overflow-x-auto border border-white/[0.04]">{typeof order.serverInfo === 'string' ? order.serverInfo : JSON.stringify(order.serverInfo, null, 2)}</pre>
                  </div>
                )}
                {order.status === 'PENDING' && (
                  <div className="flex items-center gap-2 mt-3">
                    <Button onClick={() => { setSelectedVps(order); setVpsServerInfo(order.serverInfo ? JSON.stringify(order.serverInfo, null, 2) : '') }} size="sm" className="h-7 text-[10px] bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-400 border-0 rounded-lg px-3 gap-1"><Check className="h-3 w-3" />Process</Button>
                    <Button onClick={() => rejectVpsOrder(order.id)} size="sm" className="h-7 text-[10px] bg-red-500/15 hover:bg-red-500/25 text-red-400 border-0 rounded-lg px-3 gap-1"><X className="h-3 w-3" />Reject</Button>
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </SectionCard>
      <Dialog open={!!selectedVps} onOpenChange={() => setSelectedVps(null)}>
        <DialogContent className="bg-[#0c0c1a] border-white/[0.08] text-white max-w-md rounded-2xl">
          <DialogHeader>
            <DialogTitle className="text-white text-base">Process VPS Order</DialogTitle>
            <DialogDescription className="text-white/30 text-xs">Fill in server details and approve.</DialogDescription>
          </DialogHeader>
          {selectedVps && (
            <div className="space-y-3">
              <div className="text-xs text-white/50 space-y-1 bg-white/[0.03] rounded-xl p-3 border border-white/[0.06]">
                <p><strong className="text-white/70">User:</strong> {selectedVps.user?.username}</p>
                <p><strong className="text-white/70">Plan:</strong> {selectedVps.plan?.name}</p>
                <p><strong className="text-white/70">Amount:</strong> ${selectedVps.amount}</p>
                <p><strong className="text-white/70">Method:</strong> {selectedVps.paymentMethod}</p>
                {selectedVps.transactionRef && <p><strong className="text-white/70">Ref:</strong> {selectedVps.transactionRef}</p>}
              </div>
              <Textarea className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl font-mono text-xs" rows={6} value={vpsServerInfo} onChange={(e: any) => setVpsServerInfo(e.target.value)} placeholder={'Server info:\nIP: 192.168.1.1\nUsername: admin\nPassword: pass123'} />
              <div className="flex gap-2 justify-end">
                <Button variant="ghost" onClick={() => setSelectedVps(null)} disabled={vpsApproving} className="text-white/40 hover:text-white hover:bg-white/5 rounded-xl text-xs">Cancel</Button>
                <Button onClick={approveVpsOrder} disabled={vpsApproving} className="bg-gradient-to-r from-emerald-600 to-green-600 text-white border-0 rounded-xl gap-1.5 text-xs">
                  {vpsApproving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Check className="h-3.5 w-3.5" />}
                  {vpsApproving ? 'Approving...' : 'Approve'}
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

function TransactionsSection({ transactions, approveTx, rejectTx }: any) {
  return (
    <div>
      <SectionHeader title="Transactions" description={`${transactions.filter((t: Transaction) => t.status === 'PENDING').length} pending review`} />
      <SectionCard className="divide-y divide-white/[0.04]">
        {transactions.length === 0 ? <EmptyState icon={DollarSign} message="No transactions" /> : transactions.map((tx: Transaction) => (
          <div key={tx.id} className="p-4 hover:bg-white/[0.02] transition-colors">
            <div className="flex items-start gap-3">
              <div className={`w-10 h-10 rounded-xl flex-shrink-0 flex items-center justify-center ${tx.status === 'PENDING' ? 'bg-amber-500/10' : tx.status === 'COMPLETED' ? 'bg-emerald-500/10' : 'bg-red-500/10'}`}>
                <DollarSign className={`w-4 h-4 ${tx.status === 'PENDING' ? 'text-amber-400' : tx.status === 'COMPLETED' ? 'text-emerald-400' : 'text-red-400'}`} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-sm font-medium text-white/90">{tx.user?.username || tx.userId}</span>
                  <Badge className={`text-[8px] h-4 border ${tx.status === 'PENDING' ? STATUS_COLORS.PENDING : tx.status === 'COMPLETED' ? STATUS_COLORS.COMPLETED : STATUS_COLORS.REJECTED}`}>{tx.status}</Badge>
                  <span className="text-sm font-bold text-emerald-400">${tx.amount?.toFixed(2)}</span>
                </div>
                <p className="text-[11px] text-white/30 mt-0.5"><span className="capitalize">{tx.method}</span> · Ref: <span className="font-mono">{tx.reference}</span> · {new Date(tx.createdAt).toLocaleDateString()}</p>
              </div>
              {tx.status === 'PENDING' && (
                <div className="flex gap-1.5 flex-shrink-0">
                  <Button onClick={() => approveTx(tx.id)} size="sm" className="h-7 text-[10px] bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-400 border-0 rounded-lg px-2.5 gap-1"><Check className="h-3 w-3" /><span className="hidden sm:inline">Approve</span></Button>
                  <Button onClick={() => rejectTx(tx.id)} size="sm" className="h-7 text-[10px] bg-red-500/15 hover:bg-red-500/25 text-red-400 border-0 rounded-lg px-2.5 gap-1"><X className="h-3 w-3" /><span className="hidden sm:inline">Reject</span></Button>
                </div>
              )}
            </div>
          </div>
        ))}
      </SectionCard>
    </div>
  )
}

function PlansSection({ plans, editPlan, setEditPlan, savePlan, deletePlan }: any) {
  return (
    <div>
      <SectionHeader title="Server Plans" description={`${plans.length} plans configured`}
        action={<Button onClick={() => setEditPlan({ name: '', description: '', price: 0, specs: {}, isActive: true, sortOrder: 0 })} size="sm" className="bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl gap-1.5 text-xs h-8"><Plus className="h-3.5 w-3.5" />Add Plan</Button>} />
      <SectionCard className="divide-y divide-white/[0.04]">
        {plans.length === 0 ? <EmptyState icon={Layers} message="No server plans" /> : plans.map((plan: ServerPlan) => (
          <div key={plan.id} className="p-4 hover:bg-white/[0.02] transition-colors">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-start gap-3 flex-1 min-w-0">
                <div className="w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center flex-shrink-0">
                  <Server className="w-4 h-4 text-blue-400" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-sm font-semibold text-white">{plan.name}</span>
                    <span className="text-sm font-bold text-emerald-400">${plan.price}</span>
                    {!plan.isActive && <Badge className="text-[8px] h-4 bg-red-500/10 text-red-400 border-red-500/20">Inactive</Badge>}
                  </div>
                  <p className="text-[11px] text-white/30 mt-0.5">{plan.description}</p>
                  {plan.specs && typeof plan.specs === 'object' && Object.keys(plan.specs).length > 0 && (
                    <div className="flex gap-1.5 flex-wrap mt-2">
                      {Object.entries(plan.specs).map(([k, v]) => (
                        <Badge key={k} className="text-[8px] bg-white/[0.04] text-white/40 border-white/[0.08]">{k}: {String(v)}</Badge>
                      ))}
                    </div>
                  )}
                </div>
              </div>
              <div className="flex gap-1 flex-shrink-0">
                <Button onClick={() => setEditPlan({ ...plan })} size="sm" variant="ghost" className="h-7 w-7 p-0 text-white/20 hover:text-white rounded-lg"><Edit className="h-3.5 w-3.5" /></Button>
                <Button onClick={() => deletePlan(plan.id)} size="sm" variant="ghost" className="h-7 w-7 p-0 text-red-400/30 hover:text-red-400 hover:bg-red-500/10 rounded-lg"><Trash2 className="h-3.5 w-3.5" /></Button>
              </div>
            </div>
          </div>
        ))}
      </SectionCard>
      <Dialog open={!!editPlan} onOpenChange={() => setEditPlan(null)}>
        <DialogContent className="bg-[#0c0c1a] border-white/[0.08] text-white max-w-md rounded-2xl">
          <DialogHeader><DialogTitle className="text-white text-base">{editPlan?.id ? 'Edit Plan' : 'Add Plan'}</DialogTitle></DialogHeader>
          {editPlan && (
            <div className="space-y-3">
              <div><Label className="text-white/40 text-[11px] mb-1.5 block">Name</Label><Input value={editPlan.name || ''} onChange={(e: any) => setEditPlan((p: any) => ({ ...p!, name: e.target.value }))} className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" /></div>
              <div><Label className="text-white/40 text-[11px] mb-1.5 block">Description</Label><Textarea value={editPlan.description || ''} onChange={(e: any) => setEditPlan((p: any) => ({ ...p!, description: e.target.value }))} className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl resize-none" rows={2} /></div>
              <div><Label className="text-white/40 text-[11px] mb-1.5 block">Price ($)</Label><Input type="number" value={editPlan.price || 0} onChange={(e: any) => setEditPlan((p: any) => ({ ...p!, price: parseFloat(e.target.value) }))} className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" /></div>
              <div className="flex items-center justify-between py-1"><Label className="text-white/40 text-[11px]">Active</Label><Switch checked={editPlan.isActive !== false} onCheckedChange={(v: boolean) => setEditPlan((p: any) => ({ ...p!, isActive: v }))} /></div>
              <div className="flex gap-2 justify-end pt-2">
                <Button variant="ghost" onClick={() => setEditPlan(null)} className="text-white/40 hover:text-white hover:bg-white/5 rounded-xl text-xs">Cancel</Button>
                <Button onClick={savePlan} className="bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl gap-1.5 text-xs"><Save className="h-3.5 w-3.5" />Save</Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

function MembershipsSection({ memberships, editMembership, setEditMembership, saveMembership, deleteMembership }: any) {
  return (
    <div>
      <SectionHeader title="Memberships" description={`${memberships.length} tiers configured`}
        action={<Button onClick={() => setEditMembership({ name: '', roleName: '', description: '', price: 0, color: '#8B5CF6', isActive: true, sortOrder: 0 })} size="sm" className="bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl gap-1.5 text-xs h-8"><Plus className="h-3.5 w-3.5" />Add Membership</Button>} />
      <SectionCard className="divide-y divide-white/[0.04]">
        {memberships.length === 0 ? <EmptyState icon={Crown} message="No memberships configured" /> : memberships.map((mem: MembershipType) => (
          <div key={mem.id} className="p-4 hover:bg-white/[0.02] transition-colors">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-start gap-3 flex-1 min-w-0">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style={{ backgroundColor: (mem.color || '#8B5CF6') + '15' }}>
                  <Crown className="w-4 h-4" style={{ color: mem.color || '#8B5CF6' }} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-sm font-semibold text-white">{mem.name}</span>
                    <Badge className="text-[8px] h-4 bg-white/5 text-white/40 border-white/10">{mem.roleName}</Badge>
                    <span className="text-sm font-bold text-emerald-400">${mem.price}</span>
                    {!mem.isActive && <Badge className="text-[8px] h-4 bg-red-500/10 text-red-400 border-red-500/20">Inactive</Badge>}
                  </div>
                  {mem.description && <p className="text-[11px] text-white/30 mt-0.5">{mem.description}</p>}
                </div>
              </div>
              <div className="flex gap-1 flex-shrink-0">
                <Button onClick={() => setEditMembership({ ...mem })} size="sm" variant="ghost" className="h-7 w-7 p-0 text-white/20 hover:text-white rounded-lg"><Edit className="h-3.5 w-3.5" /></Button>
                <Button onClick={() => deleteMembership(mem.id)} size="sm" variant="ghost" className="h-7 w-7 p-0 text-red-400/30 hover:text-red-400 hover:bg-red-500/10 rounded-lg"><Trash2 className="h-3.5 w-3.5" /></Button>
              </div>
            </div>
          </div>
        ))}
      </SectionCard>
      <Dialog open={!!editMembership} onOpenChange={() => setEditMembership(null)}>
        <DialogContent className="bg-[#0c0c1a] border-white/[0.08] text-white max-w-md rounded-2xl">
          <DialogHeader><DialogTitle className="text-white text-base">{editMembership?.id ? 'Edit Membership' : 'Add Membership'}</DialogTitle></DialogHeader>
          {editMembership && (
            <div className="space-y-3">
              <div><Label className="text-white/40 text-[11px] mb-1.5 block">Name</Label><Input value={editMembership.name || ''} onChange={(e: any) => setEditMembership((p: any) => ({ ...p!, name: e.target.value }))} className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" /></div>
              <div><Label className="text-white/40 text-[11px] mb-1.5 block">Role Name</Label><Input value={editMembership.roleName || ''} onChange={(e: any) => setEditMembership((p: any) => ({ ...p!, roleName: e.target.value }))} placeholder="e.g. PREMIUM, VIP" className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" /></div>
              <div><Label className="text-white/40 text-[11px] mb-1.5 block">Description</Label><Textarea value={editMembership.description || ''} onChange={(e: any) => setEditMembership((p: any) => ({ ...p!, description: e.target.value }))} className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl resize-none" rows={2} /></div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label className="text-white/40 text-[11px] mb-1.5 block">Price ($)</Label><Input type="number" value={editMembership.price || 0} onChange={(e: any) => setEditMembership((p: any) => ({ ...p!, price: parseFloat(e.target.value) }))} className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" /></div>
                <div><Label className="text-white/40 text-[11px] mb-1.5 block">Color</Label><Input type="color" value={editMembership.color || '#8B5CF6'} onChange={(e: any) => setEditMembership((p: any) => ({ ...p!, color: e.target.value }))} className="bg-white/[0.04] border-white/[0.08] h-10 rounded-xl p-1 cursor-pointer" /></div>
              </div>
              <div className="flex items-center justify-between py-1"><Label className="text-white/40 text-[11px]">Active</Label><Switch checked={editMembership.isActive !== false} onCheckedChange={(v: boolean) => setEditMembership((p: any) => ({ ...p!, isActive: v }))} /></div>
              <div className="flex gap-2 justify-end pt-2">
                <Button variant="ghost" onClick={() => setEditMembership(null)} className="text-white/40 hover:text-white hover:bg-white/5 rounded-xl text-xs">Cancel</Button>
                <Button onClick={saveMembership} className="bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl gap-1.5 text-xs"><Save className="h-3.5 w-3.5" />Save</Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

function SettingsSection({ announcement, setAnnouncement, sendAnnouncement, siteSettings, setSiteSettings, toggleMaintenance, saveSettings }: any) {
  const [activeTab, setActiveTab] = useState<'basic' | 'links' | 'content'>('basic')

  return (
    <div>
      <SectionHeader title="Settings & Configuration" description="Manage site settings, announcements, payment, and footer links" />
      
      <div className="mb-4 flex gap-2 border-b border-white/10">
        <button
          onClick={() => setActiveTab('basic')}
          className={`px-4 py-2 text-sm font-medium transition-colors ${
            activeTab === 'basic'
              ? 'text-white border-b-2 border-purple-500'
              : 'text-white/50 hover:text-white'
          }`}
        >
          Basic Settings
        </button>
        <button
          onClick={() => setActiveTab('links')}
          className={`px-4 py-2 text-sm font-medium transition-colors ${
            activeTab === 'links'
              ? 'text-white border-b-2 border-purple-500'
              : 'text-white/50 hover:text-white'
          }`}
        >
          Footer Links
        </button>
        <button
          onClick={() => setActiveTab('content')}
          className={`px-4 py-2 text-sm font-medium transition-colors ${
            activeTab === 'content'
              ? 'text-white border-b-2 border-purple-500'
              : 'text-white/50 hover:text-white'
          }`}
        >
          Policies & Content
        </button>
      </div>

      {activeTab === 'basic' && (
        <div className="grid lg:grid-cols-2 gap-4">
          <div className="space-y-4">
            <SectionCard className="p-5">
              <h4 className="text-sm font-semibold text-white mb-4 flex items-center gap-2"><Bell className="w-4 h-4 text-purple-400" />Send Announcement</h4>
              <Textarea value={announcement} onChange={(e: any) => setAnnouncement(e.target.value)} placeholder="Broadcast a message to all users..." className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl resize-none mb-3" rows={3} />
              <Button onClick={sendAnnouncement} className="w-full bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl gap-2 text-xs h-9"><Send className="h-3.5 w-3.5" />Send to All Users</Button>
            </SectionCard>

            <SectionCard className="p-5">
              <h4 className="text-sm font-semibold text-white mb-4 flex items-center gap-2"><CreditCard className="w-4 h-4 text-emerald-400" />Payment Config</h4>
              <div className="space-y-3">
                <div>
                  <Label className="text-white/40 text-[11px] mb-1.5 block">bKash Number</Label>
                  <Input value={siteSettings.bkashNumber} onChange={(e: any) => setSiteSettings((p: any) => ({ ...p, bkashNumber: e.target.value }))} placeholder="01XXXXXXXXX" className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" />
                </div>
                <div>
                  <Label className="text-white/40 text-[11px] mb-1.5 block">Nagad Number</Label>
                  <Input value={siteSettings.nagadNumber} onChange={(e: any) => setSiteSettings((p: any) => ({ ...p, nagadNumber: e.target.value }))} placeholder="01XXXXXXXXX" className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" />
                </div>
                <Button onClick={saveSettings} className="w-full bg-gradient-to-r from-emerald-600 to-teal-600 text-white border-0 rounded-xl gap-2 text-xs h-9 mt-3"><Save className="h-3.5 w-3.5" />Save Payment Info</Button>
              </div>
            </SectionCard>
          </div>

          <div className="space-y-4">
            <SectionCard className="p-5">
              <h4 className="text-sm font-semibold text-white mb-4 flex items-center gap-2"><Settings className="w-4 h-4 text-blue-400" />Site Settings</h4>
              <div className="space-y-3">
                <div>
                  <Label className="text-white/40 text-[11px] mb-1.5 block">Site Name</Label>
                  <Input value={siteSettings.siteName} onChange={(e: any) => setSiteSettings((p: any) => ({ ...p, siteName: e.target.value }))} className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" />
                </div>
                <div>
                  <Label className="text-white/40 text-[11px] mb-1.5 block">OpenAI API Key</Label>
                  <Input type="password" value={siteSettings.openAiApiKey || ''} onChange={(e: any) => setSiteSettings((p: any) => ({ ...p, openAiApiKey: e.target.value }))} placeholder="Enter OpenAI API key" className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" />
                  <p className="text-[11px] text-white/50 mt-1">Configure the AI key here so /api/ai/chat works from the admin panel.</p>
                </div>
                <div className="flex items-center justify-between py-2.5 border-t border-white/[0.04]">
                  <div>
                    <p className="text-xs font-medium text-white flex items-center gap-2">
                      <Wrench className="w-3.5 h-3.5 text-amber-400" />
                      Maintenance Mode
                    </p>
                    <p className="text-[10px] text-white/25 mt-0.5">Block non-admin access to the site</p>
                  </div>
                  <Switch checked={siteSettings.maintenance} onCheckedChange={(v: boolean) => toggleMaintenance(v)} />
                </div>
                {siteSettings.maintenance && (
                  <div className="flex items-center gap-2 bg-amber-500/10 border border-amber-500/20 rounded-xl px-3 py-2 mt-2">
                    <AlertTriangle className="w-3.5 h-3.5 text-amber-400 flex-shrink-0" />
                    <p className="text-[10px] text-amber-400">Site is in maintenance mode. Only admins can access.</p>
                  </div>
                )}
                <Button onClick={saveSettings} className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white border-0 rounded-xl gap-2 text-xs h-9 mt-3"><Save className="h-3.5 w-3.5" />Save Site Settings</Button>
              </div>
            </SectionCard>

            <SectionCard className="p-5">
              <h4 className="text-sm font-semibold text-white mb-4 flex items-center gap-2"><Database className="w-4 h-4 text-amber-400" />Quick Links</h4>
              <div className="space-y-1.5">
                {[
                  ['/', 'Back to Store', Globe],
                  ['/dashboard', 'Seller Dashboard', LayoutDashboard],
                  ['/orders', 'All Orders', ShoppingCart],
                  ['/vps', 'VPS Management', Server],
                  ['/admin/app-submissions', 'App Submissions', FileText],
                ].map(([href, label, Icon]: any) => (
                  <Link key={href} href={href}>
                    <div className="flex items-center justify-between text-xs text-white/40 hover:text-white py-2.5 px-3 rounded-xl hover:bg-white/[0.04] transition-all cursor-pointer group">
                      <span className="flex items-center gap-2.5"><Icon className="w-4 h-4" />{label}</span>
                      <ChevronRight className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                  </Link>
                ))}
              </div>
            </SectionCard>
          </div>
        </div>
      )}

      {activeTab === 'links' && (
        <div className="grid md:grid-cols-2 gap-4">
          {[
            { key: 'discordUrl', label: 'Discord', placeholder: 'https://discord.gg/...' },
            { key: 'githubUrl', label: 'GitHub', placeholder: 'https://github.com/...' },
            { key: 'twitterUrl', label: 'Twitter/X', placeholder: 'https://twitter.com/...' },
            { key: 'statusPageUrl', label: 'Status Page', placeholder: 'https://status.example.com' },
            { key: 'contactUsUrl', label: 'Contact Us', placeholder: 'https://example.com/contact' },
            { key: 'helpCenterUrl', label: 'Help Center', placeholder: 'https://help.example.com' },
            { key: 'documentationUrl', label: 'Documentation', placeholder: 'https://docs.example.com' },
            { key: 'privacyUrl', label: 'Privacy Policy', placeholder: 'https://example.com/privacy' },
            { key: 'dmcaUrl', label: 'DMCA', placeholder: 'https://example.com/dmca' },
          ].map(({ key, label, placeholder }) => (
            <SectionCard key={key} className="p-4">
              <Label className="text-white/40 text-[11px] mb-1.5 block">{label}</Label>
             <Input
                value={(siteSettings as any)[key] || ''}
                onChange={(e: any) => setSiteSettings((p: any) => ({ ...p, [key]: e.target.value }))}
                placeholder={placeholder}
                className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl text-xs"
              />
            </SectionCard>
          ))}
          <div className="md:col-span-2">
            <Button onClick={saveSettings} className="w-full bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl gap-2 text-xs h-9"><Save className="h-3.5 w-3.5" />Save Footer Links</Button>
          </div>
        </div>
      )}

      {activeTab === 'content' && (
        <div className="grid md:grid-cols-2 gap-4">
          <SectionCard className="p-5 md:col-span-2">
            <Label className="text-white/40 text-[11px] mb-1.5 block">Privacy Policy</Label>
            <Textarea
              value={siteSettings.privacyPolicy || ''}
              onChange={(e: any) => setSiteSettings((p: any) => ({ ...p, privacyPolicy: e.target.value }))}
              placeholder="Enter your privacy policy content..."
              className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl resize-none"
              rows={4}
            />
          </SectionCard>

          <SectionCard className="p-5 md:col-span-2">
            <Label className="text-white/40 text-[11px] mb-1.5 block">Terms of Service</Label>
            <Textarea
              value={siteSettings.termsOfService || ''}
              onChange={(e: any) => setSiteSettings((p: any) => ({ ...p, termsOfService: e.target.value }))}
              placeholder="Enter your terms of service content..."
              className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl resize-none"
              rows={4}
            />
          </SectionCard>

          <SectionCard className="p-5 md:col-span-2">
            <Label className="text-white/40 text-[11px] mb-1.5 block">Guidelines</Label>
            <Textarea
              value={siteSettings.guidelines || ''}
              onChange={(e: any) => setSiteSettings((p: any) => ({ ...p, guidelines: e.target.value }))}
              placeholder="Enter your community guidelines..."
              className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl resize-none"
              rows={4}
            />
          </SectionCard>

          <div className="md:col-span-2">
            <Button onClick={saveSettings} className="w-full bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl gap-2 text-xs h-9"><Save className="h-3.5 w-3.5" />Save Policies & Content</Button>
          </div>
        </div>
      )}
    </div>
  )
}

function AdsSection({ ads, editAd, setEditAd, saveAd, deleteAd, toggleAd }: any) {
  const positions = ['homepage', 'browse', 'sidebar', 'footer', 'item-detail']
  return (
    <div>
      <SectionHeader title="Advertisements" description={`${ads.length} ads configured · ${ads.filter((a: AdItem) => a.isActive).length} active`}
        action={<Button onClick={() => setEditAd({ title: '', description: '', imageUrl: '', linkUrl: '', position: 'homepage', isActive: true, sortOrder: 0 })} size="sm" className="bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl gap-1.5 text-xs h-8"><Plus className="h-3.5 w-3.5" />Create Ad</Button>} />

      {ads.length === 0 ? (
        <SectionCard><EmptyState icon={Megaphone} message="No advertisements yet" /></SectionCard>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2">
          {ads.map((ad: AdItem) => (
            <SectionCard key={ad.id} className="p-4">
              <div className="flex items-start justify-between gap-2 mb-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-sm font-semibold text-white truncate">{ad.title}</span>
                    <Badge className={`text-[8px] h-4 border ${ad.isActive ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' : 'bg-zinc-500/10 text-zinc-400 border-zinc-500/20'}`}>{ad.isActive ? 'Active' : 'Inactive'}</Badge>
                    <Badge className="text-[8px] h-4 bg-purple-500/10 text-purple-400 border-purple-500/20 capitalize">{ad.position}</Badge>
                  </div>
                  {ad.description && <p className="text-[11px] text-white/30 mt-1 line-clamp-2">{ad.description}</p>}
                </div>
                <div className="flex gap-1 flex-shrink-0">
                  <Button onClick={() => toggleAd(ad.id, !ad.isActive)} size="sm" variant="ghost" className="h-7 w-7 p-0 text-white/20 hover:text-white rounded-lg">
                    {ad.isActive ? <ToggleRight className="h-3.5 w-3.5 text-emerald-400" /> : <ToggleLeft className="h-3.5 w-3.5" />}
                  </Button>
                  <Button onClick={() => setEditAd({ ...ad })} size="sm" variant="ghost" className="h-7 w-7 p-0 text-white/20 hover:text-white rounded-lg"><Edit className="h-3.5 w-3.5" /></Button>
                  <Button onClick={() => deleteAd(ad.id)} size="sm" variant="ghost" className="h-7 w-7 p-0 text-red-400/30 hover:text-red-400 hover:bg-red-500/10 rounded-lg"><Trash2 className="h-3.5 w-3.5" /></Button>
                </div>
              </div>
              {ad.imageUrl && (
                <div className="w-full h-24 rounded-xl bg-white/[0.04] border border-white/[0.06] overflow-hidden mb-3">
                  <img src={ad.imageUrl} alt={ad.title} className="w-full h-full object-cover" />
                </div>
              )}
              <div className="flex items-center gap-3 text-[10px] text-white/25">
                {ad.linkUrl && <span className="flex items-center gap-1"><Link2 className="w-3 h-3" />Has link</span>}
                <span className="flex items-center gap-1"><MousePointerClick className="w-3 h-3" />{ad.clicks} clicks</span>
                <span className="flex items-center gap-1"><Eye className="w-3 h-3" />{ad.impressions} views</span>
              </div>
            </SectionCard>
          ))}
        </div>
      )}

      <Dialog open={!!editAd} onOpenChange={() => setEditAd(null)}>
        <DialogContent className="bg-[#0c0c1a] border-white/[0.08] text-white max-w-md rounded-2xl">
          <DialogHeader><DialogTitle className="text-white text-base">{editAd?.id ? 'Edit Ad' : 'Create Ad'}</DialogTitle></DialogHeader>
          {editAd && (
            <div className="space-y-3 max-h-[60vh] overflow-y-auto pr-1">
              <div><Label className="text-white/40 text-[11px] mb-1.5 block">Title *</Label><Input value={editAd.title || ''} onChange={(e: any) => setEditAd((p: any) => ({ ...p!, title: e.target.value }))} className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" /></div>
              <div><Label className="text-white/40 text-[11px] mb-1.5 block">Description</Label><Textarea value={editAd.description || ''} onChange={(e: any) => setEditAd((p: any) => ({ ...p!, description: e.target.value }))} className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl resize-none" rows={2} /></div>
              <div><Label className="text-white/40 text-[11px] mb-1.5 block">Image URL</Label><Input value={editAd.imageUrl || ''} onChange={(e: any) => setEditAd((p: any) => ({ ...p!, imageUrl: e.target.value }))} placeholder="https://..." className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" /></div>
              <div><Label className="text-white/40 text-[11px] mb-1.5 block">Link URL</Label><Input value={editAd.linkUrl || ''} onChange={(e: any) => setEditAd((p: any) => ({ ...p!, linkUrl: e.target.value }))} placeholder="https://..." className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" /></div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-white/40 text-[11px] mb-1.5 block">Position</Label>
                  <Select value={editAd.position || 'homepage'} onValueChange={(v: string) => setEditAd((p: any) => ({ ...p!, position: v }))}>
                    <SelectTrigger className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl h-10"><SelectValue /></SelectTrigger>
                    <SelectContent className="bg-[#0c0c1a] border-white/[0.08]">
                      {positions.map(p => <SelectItem key={p} value={p} className="text-white capitalize">{p}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div><Label className="text-white/40 text-[11px] mb-1.5 block">Sort Order</Label><Input type="number" value={editAd.sortOrder || 0} onChange={(e: any) => setEditAd((p: any) => ({ ...p!, sortOrder: parseInt(e.target.value) || 0 }))} className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" /></div>
              </div>
              <div className="flex items-center justify-between py-1"><Label className="text-white/40 text-[11px]">Active</Label><Switch checked={editAd.isActive !== false} onCheckedChange={(v: boolean) => setEditAd((p: any) => ({ ...p!, isActive: v }))} /></div>
              <div className="flex gap-2 justify-end pt-2">
                <Button variant="ghost" onClick={() => setEditAd(null)} className="text-white/40 hover:text-white hover:bg-white/5 rounded-xl text-xs">Cancel</Button>
                <Button onClick={saveAd} className="bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl gap-1.5 text-xs"><Save className="h-3.5 w-3.5" />Save</Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

function CouponsSection({ coupons, editCoupon, setEditCoupon, saveCoupon, deleteCoupon, toggleCoupon }: any) {
  return (
    <div>
      <SectionHeader title="Coupons" description={`${coupons.length} coupons · ${coupons.filter((c: CouponItem) => c.isActive).length} active`}
        action={<Button onClick={() => setEditCoupon({ code: '', description: '', discountType: 'PERCENTAGE', discountValue: 10, minOrderAmount: null, maxUsage: null, expiresAt: null, isActive: true })} size="sm" className="bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl gap-1.5 text-xs h-8"><Plus className="h-3.5 w-3.5" />Create Coupon</Button>} />

      <SectionCard className="divide-y divide-white/[0.04]">
        {coupons.length === 0 ? <EmptyState icon={Ticket} message="No coupons created" /> : coupons.map((coupon: CouponItem) => {
          const isExpired = coupon.expiresAt && new Date(coupon.expiresAt) < new Date()
          const usageLeft = coupon.maxUsage ? coupon.maxUsage - coupon.usageCount : null
          return (
            <div key={coupon.id} className="p-4 hover:bg-white/[0.02] transition-colors">
              <div className="flex items-start gap-3">
                <div className={`w-10 h-10 rounded-xl flex-shrink-0 flex items-center justify-center ${coupon.isActive && !isExpired ? 'bg-emerald-500/10' : 'bg-zinc-500/10'}`}>
                  <Ticket className={`w-4 h-4 ${coupon.isActive && !isExpired ? 'text-emerald-400' : 'text-zinc-400'}`} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-sm font-mono font-bold text-white bg-white/[0.06] px-2 py-0.5 rounded-lg">{coupon.code}</span>
                    <Badge className="text-[8px] h-4 bg-purple-500/10 text-purple-400 border-purple-500/20">
                      {coupon.discountType === 'PERCENTAGE' ? `${coupon.discountValue}% OFF` : `$${coupon.discountValue} OFF`}
                    </Badge>
                    {!coupon.isActive && <Badge className="text-[8px] h-4 bg-zinc-500/10 text-zinc-400 border-zinc-500/20">Disabled</Badge>}
                    {isExpired && <Badge className="text-[8px] h-4 bg-red-500/10 text-red-400 border-red-500/20">Expired</Badge>}
                  </div>
                  {coupon.description && <p className="text-[11px] text-white/30 mt-0.5">{coupon.description}</p>}
                  <div className="flex items-center gap-3 mt-1.5 text-[10px] text-white/25">
                    <span>Used: {coupon._count?.usages || coupon.usageCount || 0}{coupon.maxUsage ? `/${coupon.maxUsage}` : ''}</span>
                    {coupon.minOrderAmount && <span>Min: ${coupon.minOrderAmount}</span>}
                    {coupon.expiresAt && <span>Expires: {new Date(coupon.expiresAt).toLocaleDateString()}</span>}
                    {coupon.createdBy && <span>By: {coupon.createdBy.username}</span>}
                  </div>
                </div>
                <div className="flex gap-1 flex-shrink-0">
                  <Button onClick={() => toggleCoupon(coupon.id, !coupon.isActive)} size="sm" variant="ghost" className="h-7 w-7 p-0 text-white/20 hover:text-white rounded-lg">
                    {coupon.isActive ? <ToggleRight className="h-3.5 w-3.5 text-emerald-400" /> : <ToggleLeft className="h-3.5 w-3.5" />}
                  </Button>
                  <Button onClick={() => deleteCoupon(coupon.id)} size="sm" variant="ghost" className="h-7 w-7 p-0 text-red-400/30 hover:text-red-400 hover:bg-red-500/10 rounded-lg"><Trash2 className="h-3.5 w-3.5" /></Button>
                </div>
              </div>
            </div>
          )
        })}
      </SectionCard>

      <Dialog open={!!editCoupon} onOpenChange={() => setEditCoupon(null)}>
        <DialogContent className="bg-[#0c0c1a] border-white/[0.08] text-white max-w-md rounded-2xl">
          <DialogHeader><DialogTitle className="text-white text-base">Create Coupon</DialogTitle></DialogHeader>
          {editCoupon && (
            <div className="space-y-3">
              <div><Label className="text-white/40 text-[11px] mb-1.5 block">Coupon Code *</Label><Input value={editCoupon.code || ''} onChange={(e: any) => setEditCoupon((p: any) => ({ ...p!, code: e.target.value.toUpperCase() }))} placeholder="SUMMER2024" className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl font-mono uppercase" /></div>
              <div><Label className="text-white/40 text-[11px] mb-1.5 block">Description</Label><Input value={editCoupon.description || ''} onChange={(e: any) => setEditCoupon((p: any) => ({ ...p!, description: e.target.value }))} placeholder="Summer sale discount" className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" /></div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-white/40 text-[11px] mb-1.5 block">Discount Type</Label>
                  <Select value={editCoupon.discountType || 'PERCENTAGE'} onValueChange={(v: string) => setEditCoupon((p: any) => ({ ...p!, discountType: v }))}>
                    <SelectTrigger className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl h-10"><SelectValue /></SelectTrigger>
                    <SelectContent className="bg-[#0c0c1a] border-white/[0.08]">
                      <SelectItem value="PERCENTAGE" className="text-white">Percentage (%)</SelectItem>
                      <SelectItem value="FIXED" className="text-white">Fixed Amount ($)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div><Label className="text-white/40 text-[11px] mb-1.5 block">Value *</Label><Input type="number" value={editCoupon.discountValue || ''} onChange={(e: any) => setEditCoupon((p: any) => ({ ...p!, discountValue: parseFloat(e.target.value) || 0 }))} placeholder={editCoupon.discountType === 'PERCENTAGE' ? '10' : '5.00'} className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" /></div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label className="text-white/40 text-[11px] mb-1.5 block">Min Order ($)</Label><Input type="number" value={editCoupon.minOrderAmount || ''} onChange={(e: any) => setEditCoupon((p: any) => ({ ...p!, minOrderAmount: parseFloat(e.target.value) || null }))} placeholder="Optional" className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" /></div>
                <div><Label className="text-white/40 text-[11px] mb-1.5 block">Max Uses</Label><Input type="number" value={editCoupon.maxUsage || ''} onChange={(e: any) => setEditCoupon((p: any) => ({ ...p!, maxUsage: parseInt(e.target.value) || null }))} placeholder="Unlimited" className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" /></div>
              </div>
              <div><Label className="text-white/40 text-[11px] mb-1.5 block">Expiry Date</Label><Input type="date" value={editCoupon.expiresAt ? new Date(editCoupon.expiresAt).toISOString().split('T')[0] : ''} onChange={(e: any) => setEditCoupon((p: any) => ({ ...p!, expiresAt: e.target.value || null }))} className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" /></div>
              <div className="flex gap-2 justify-end pt-2">
                <Button variant="ghost" onClick={() => setEditCoupon(null)} className="text-white/40 hover:text-white hover:bg-white/5 rounded-xl text-xs">Cancel</Button>
                <Button onClick={saveCoupon} className="bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl gap-1.5 text-xs"><Save className="h-3.5 w-3.5" />Create</Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

function FeatureTogglesSection({ features, toggleFeature }: any) {
  const categories = [...new Set(features.map((f: FeatureToggleItem) => f.category))] as string[]
  const catLabels: Record<string, { label: string; icon: any; color: string }> = {
    core: { label: 'Core Features', icon: Zap, color: 'text-blue-400' },
    payments: { label: 'Payments & Wallet', icon: CreditCard, color: 'text-emerald-400' },
    social: { label: 'Social & Communication', icon: MessageSquare, color: 'text-purple-400' },
    marketplace: { label: 'Marketplace', icon: ShoppingCart, color: 'text-cyan-400' },
    seller: { label: 'Seller System', icon: UserCheck, color: 'text-amber-400' },
    services: { label: 'Services', icon: Server, color: 'text-pink-400' },
    marketing: { label: 'Marketing', icon: Megaphone, color: 'text-orange-400' },
    moderation: { label: 'Moderation', icon: Shield, color: 'text-red-400' },
    general: { label: 'General', icon: Settings, color: 'text-white/40' },
  }

  const enabledCount = features.filter((f: FeatureToggleItem) => f.isEnabled).length
  const totalCount = features.length

  return (
    <div>
      <SectionHeader title="Feature Toggles" description={`${enabledCount}/${totalCount} features enabled · Turn features on/off instantly`} />
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
        <SectionCard className="p-3 text-center"><p className="text-2xl font-bold text-emerald-400">{enabledCount}</p><p className="text-[10px] text-white/30">Enabled</p></SectionCard>
        <SectionCard className="p-3 text-center"><p className="text-2xl font-bold text-red-400">{totalCount - enabledCount}</p><p className="text-[10px] text-white/30">Disabled</p></SectionCard>
        <SectionCard className="p-3 text-center"><p className="text-2xl font-bold text-purple-400">{categories.length}</p><p className="text-[10px] text-white/30">Categories</p></SectionCard>
        <SectionCard className="p-3 text-center"><p className="text-2xl font-bold text-blue-400">{totalCount}</p><p className="text-[10px] text-white/30">Total</p></SectionCard>
      </div>
      <div className="space-y-4">
        {categories.map((cat: string) => {
          const catInfo = catLabels[cat] || catLabels.general
          const CatIcon = catInfo.icon
          const catFeatures = features.filter((f: FeatureToggleItem) => f.category === cat)
          return (
            <SectionCard key={cat} className="overflow-hidden">
              <div className="px-4 py-3 border-b border-white/[0.04] flex items-center gap-2.5">
                <CatIcon className={`w-4 h-4 ${catInfo.color}`} />
                <span className="text-xs font-semibold text-white">{catInfo.label}</span>
                <span className="text-[10px] text-white/20 ml-auto">{catFeatures.filter((f: FeatureToggleItem) => f.isEnabled).length}/{catFeatures.length}</span>
              </div>
              <div className="divide-y divide-white/[0.04]">
                {catFeatures.map((feature: FeatureToggleItem) => (
                  <div key={feature.id} className="flex items-center justify-between px-4 py-3 hover:bg-white/[0.02] transition-colors">
                    <div className="flex-1 min-w-0 mr-4">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-medium text-white">{feature.featureName}</span>
                        {!feature.isEnabled && <Badge className="text-[8px] h-4 bg-red-500/10 text-red-400 border-red-500/20">OFF</Badge>}
                      </div>
                      {feature.description && <p className="text-[10px] text-white/25 mt-0.5">{feature.description}</p>}
                    </div>
                    <Switch checked={feature.isEnabled} onCheckedChange={(v: boolean) => toggleFeature(feature.id, v)} />
                  </div>
                ))}
              </div>
            </SectionCard>
          )
        })}
      </div>
    </div>
  )
}

function CampaignsSection({ campaigns, editCampaign, setEditCampaign, saveCampaign, deleteCampaign }: any) {
  const now = new Date()
  const activeCampaigns = campaigns.filter((c: any) => c.isActive && new Date(c.endDate) > now)
  return (
    <div>
      <SectionHeader title="Campaigns" description={`${activeCampaigns.length} active campaigns · Run seasonal sales and promotions`} />
      <div className="flex justify-end mb-4">
        <Button onClick={() => setEditCampaign({ name: '', description: '', discountPercent: 10, startDate: new Date().toISOString().split('T')[0], endDate: '', bannerText: '', isActive: true })} className="bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl gap-1.5 text-xs"><Plus className="h-3.5 w-3.5" />Create Campaign</Button>
      </div>
      <div className="grid gap-3">
        {campaigns.length === 0 && <SectionCard className="p-8 text-center"><CalendarDays className="w-8 h-8 text-white/10 mx-auto mb-2" /><p className="text-white/30 text-sm">No campaigns yet</p></SectionCard>}
        {campaigns.map((c: any) => {
          const isExpired = new Date(c.endDate) < now
          return (
            <SectionCard key={c.id} className="p-4">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <CalendarDays className="w-4 h-4 text-purple-400" />
                  <span className="text-sm font-semibold text-white">{c.name}</span>
                  <Badge className={`text-[9px] h-4 ${c.isActive && !isExpired ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' : 'bg-zinc-500/10 text-zinc-400 border-zinc-500/20'}`}>{isExpired ? 'Expired' : c.isActive ? 'Active' : 'Inactive'}</Badge>
                </div>
                <div className="flex gap-1">
                  <Button variant="ghost" size="sm" onClick={() => setEditCampaign({ ...c, startDate: new Date(c.startDate).toISOString().split('T')[0], endDate: new Date(c.endDate).toISOString().split('T')[0] })} className="h-7 w-7 p-0 text-white/30 hover:text-white"><Edit className="h-3 w-3" /></Button>
                  <Button variant="ghost" size="sm" onClick={() => deleteCampaign(c.id)} className="h-7 w-7 p-0 text-white/30 hover:text-red-400"><Trash2 className="h-3 w-3" /></Button>
                </div>
              </div>
              {c.description && <p className="text-xs text-white/40 mb-2">{c.description}</p>}
              <div className="flex gap-3 text-[10px] text-white/30">
                <span className="flex items-center gap-1"><Tag className="w-3 h-3" />{c.discountPercent}% off</span>
                <span>{new Date(c.startDate).toLocaleDateString()} — {new Date(c.endDate).toLocaleDateString()}</span>
                {c.bannerText && <span className="text-purple-400/60">{c.bannerText}</span>}
              </div>
            </SectionCard>
          )
        })}
      </div>
      <Dialog open={!!editCampaign} onOpenChange={() => setEditCampaign(null)}>
        <DialogContent className="bg-[#0c0c1a] border-white/[0.08] text-white max-w-md">
          <DialogHeader><DialogTitle className="text-white text-base">{editCampaign?.id ? 'Edit Campaign' : 'Create Campaign'}</DialogTitle><DialogDescription className="text-white/30 text-xs">Set up a promotional campaign</DialogDescription></DialogHeader>
          {editCampaign && (
            <div className="space-y-3">
              <div><Label className="text-white/40 text-[11px] mb-1.5 block">Name *</Label><Input value={editCampaign.name || ''} onChange={(e: any) => setEditCampaign((p: any) => ({ ...p, name: e.target.value }))} placeholder="Black Friday Sale" className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" /></div>
              <div><Label className="text-white/40 text-[11px] mb-1.5 block">Description</Label><Textarea value={editCampaign.description || ''} onChange={(e: any) => setEditCampaign((p: any) => ({ ...p, description: e.target.value }))} className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl min-h-[60px]" /></div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label className="text-white/40 text-[11px] mb-1.5 block">Discount %</Label><Input type="number" value={editCampaign.discountPercent || ''} onChange={(e: any) => setEditCampaign((p: any) => ({ ...p, discountPercent: parseFloat(e.target.value) || 0 }))} className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" /></div>
                <div><Label className="text-white/40 text-[11px] mb-1.5 block">Banner Text</Label><Input value={editCampaign.bannerText || ''} onChange={(e: any) => setEditCampaign((p: any) => ({ ...p, bannerText: e.target.value }))} placeholder="🔥 50% OFF" className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" /></div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label className="text-white/40 text-[11px] mb-1.5 block">Start Date *</Label><Input type="date" value={editCampaign.startDate || ''} onChange={(e: any) => setEditCampaign((p: any) => ({ ...p, startDate: e.target.value }))} className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" /></div>
                <div><Label className="text-white/40 text-[11px] mb-1.5 block">End Date *</Label><Input type="date" value={editCampaign.endDate || ''} onChange={(e: any) => setEditCampaign((p: any) => ({ ...p, endDate: e.target.value }))} className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" /></div>
              </div>
              <div className="flex items-center gap-2"><Switch checked={editCampaign.isActive ?? true} onCheckedChange={(v: boolean) => setEditCampaign((p: any) => ({ ...p, isActive: v }))} /><Label className="text-white/40 text-xs">Active</Label></div>
              <div className="flex gap-2 justify-end pt-2">
                <Button variant="ghost" onClick={() => setEditCampaign(null)} className="text-white/40 hover:text-white hover:bg-white/5 rounded-xl text-xs">Cancel</Button>
                <Button onClick={saveCampaign} className="bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl gap-1.5 text-xs"><Save className="h-3.5 w-3.5" />{editCampaign.id ? 'Update' : 'Create'}</Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

function BadgesSection({ badges, editBadge, setEditBadge, saveBadge, deleteBadge }: any) {
  return (
    <div>
      <SectionHeader title="Badges" description={`${badges.length} badges · Create and manage achievement badges`} />
      <div className="flex justify-end mb-4">
        <Button onClick={() => setEditBadge({ name: '', description: '', icon: '⭐', color: '#8B5CF6', isAutomatic: false, isActive: true })} className="bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl gap-1.5 text-xs"><Plus className="h-3.5 w-3.5" />Create Badge</Button>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {badges.length === 0 && <SectionCard className="p-8 text-center col-span-full"><Award className="w-8 h-8 text-white/10 mx-auto mb-2" /><p className="text-white/30 text-sm">No badges yet</p></SectionCard>}
        {badges.map((b: any) => (
          <SectionCard key={b.id} className="p-4">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center text-xl" style={{ backgroundColor: b.color + '20', color: b.color }}>{b.icon || '⭐'}</div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-white truncate">{b.name}</p>
                <div className="flex gap-1">
                  {b.isAutomatic && <Badge className="text-[8px] h-4 bg-blue-500/10 text-blue-400 border-blue-500/20">Auto</Badge>}
                  <Badge className={`text-[8px] h-4 ${b.isActive ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' : 'bg-red-500/10 text-red-400 border-red-500/20'}`}>{b.isActive ? 'Active' : 'Inactive'}</Badge>
                </div>
              </div>
              <div className="flex gap-1">
                <Button variant="ghost" size="sm" onClick={() => setEditBadge({ ...b })} className="h-7 w-7 p-0 text-white/30 hover:text-white"><Edit className="h-3 w-3" /></Button>
                <Button variant="ghost" size="sm" onClick={() => deleteBadge(b.id)} className="h-7 w-7 p-0 text-white/30 hover:text-red-400"><Trash2 className="h-3 w-3" /></Button>
              </div>
            </div>
            {b.description && <p className="text-[10px] text-white/30">{b.description}</p>}
            {b.criteria && <p className="text-[10px] text-purple-400/60 mt-1">Criteria: {b.criteria}</p>}
          </SectionCard>
        ))}
      </div>
      <Dialog open={!!editBadge} onOpenChange={() => setEditBadge(null)}>
        <DialogContent className="bg-[#0c0c1a] border-white/[0.08] text-white max-w-md">
          <DialogHeader><DialogTitle className="text-white text-base">{editBadge?.id ? 'Edit Badge' : 'Create Badge'}</DialogTitle><DialogDescription className="text-white/30 text-xs">Manage achievement badges</DialogDescription></DialogHeader>
          {editBadge && (
            <div className="space-y-3">
              <div><Label className="text-white/40 text-[11px] mb-1.5 block">Name *</Label><Input value={editBadge.name || ''} onChange={(e: any) => setEditBadge((p: any) => ({ ...p, name: e.target.value }))} placeholder="Top Seller" className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" /></div>
              <div><Label className="text-white/40 text-[11px] mb-1.5 block">Description</Label><Input value={editBadge.description || ''} onChange={(e: any) => setEditBadge((p: any) => ({ ...p, description: e.target.value }))} className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" /></div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label className="text-white/40 text-[11px] mb-1.5 block">Icon (emoji)</Label><Input value={editBadge.icon || ''} onChange={(e: any) => setEditBadge((p: any) => ({ ...p, icon: e.target.value }))} placeholder="⭐" className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" /></div>
                <div><Label className="text-white/40 text-[11px] mb-1.5 block">Color</Label><Input type="color" value={editBadge.color || '#8B5CF6'} onChange={(e: any) => setEditBadge((p: any) => ({ ...p, color: e.target.value }))} className="bg-white/[0.04] border-white/[0.08] rounded-xl h-10 w-full" /></div>
              </div>
              <div><Label className="text-white/40 text-[11px] mb-1.5 block">Criteria</Label><Input value={editBadge.criteria || ''} onChange={(e: any) => setEditBadge((p: any) => ({ ...p, criteria: e.target.value }))} placeholder="Sell 100 items" className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" /></div>
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2"><Switch checked={editBadge.isAutomatic ?? false} onCheckedChange={(v: boolean) => setEditBadge((p: any) => ({ ...p, isAutomatic: v }))} /><Label className="text-white/40 text-xs">Auto-assign</Label></div>
                <div className="flex items-center gap-2"><Switch checked={editBadge.isActive ?? true} onCheckedChange={(v: boolean) => setEditBadge((p: any) => ({ ...p, isActive: v }))} /><Label className="text-white/40 text-xs">Active</Label></div>
              </div>
              <div className="flex gap-2 justify-end pt-2">
                <Button variant="ghost" onClick={() => setEditBadge(null)} className="text-white/40 hover:text-white hover:bg-white/5 rounded-xl text-xs">Cancel</Button>
                <Button onClick={saveBadge} className="bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl gap-1.5 text-xs"><Save className="h-3.5 w-3.5" />{editBadge.id ? 'Update' : 'Create'}</Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

function ReferralsSection({ stats }: any) {
  return (
    <div>
      <SectionHeader title="Referrals" description="Track referral program performance and top referrers" />
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-6">
        <SectionCard className="p-4 text-center"><Share2 className="w-5 h-5 text-purple-400 mx-auto mb-1" /><p className="text-2xl font-bold text-white">{stats.totalReferrals || 0}</p><p className="text-[10px] text-white/30">Total Referrals</p></SectionCard>
        <SectionCard className="p-4 text-center"><DollarSign className="w-5 h-5 text-emerald-400 mx-auto mb-1" /><p className="text-2xl font-bold text-white">${(stats.totalEarnings || 0).toFixed(2)}</p><p className="text-[10px] text-white/30">Total Earnings Paid</p></SectionCard>
        <SectionCard className="p-4 text-center"><Users className="w-5 h-5 text-blue-400 mx-auto mb-1" /><p className="text-2xl font-bold text-white">{(stats.topReferrers || []).length}</p><p className="text-[10px] text-white/30">Active Referrers</p></SectionCard>
      </div>
      <div className="grid lg:grid-cols-2 gap-4">
        <div>
          <h3 className="text-xs font-semibold text-white/60 mb-3 flex items-center gap-2"><Trophy className="w-3.5 h-3.5" />Top Referrers</h3>
          <SectionCard className="divide-y divide-white/[0.04]">
            {(stats.topReferrers || []).length === 0 && <div className="p-6 text-center text-white/20 text-xs">No referrers yet</div>}
            {(stats.topReferrers || []).map((r: any, i: number) => (
              <div key={r.id} className="flex items-center gap-3 px-4 py-3">
                <span className="text-xs font-bold text-white/20 w-5">#{i + 1}</span>
                <Avatar className="h-7 w-7"><AvatarImage src={r.avatar} /><AvatarFallback className="bg-purple-600/20 text-purple-400 text-[10px]">{r.username?.[0]?.toUpperCase()}</AvatarFallback></Avatar>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium text-white truncate">{r.username}</p>
                  <p className="text-[10px] text-white/30">{r._count?.referrals || 0} referrals · Code: {r.referralCode}</p>
                </div>
                <span className="text-xs font-semibold text-emerald-400">${(r.referralEarnings || 0).toFixed(2)}</span>
              </div>
            ))}
          </SectionCard>
        </div>
        <div>
          <h3 className="text-xs font-semibold text-white/60 mb-3 flex items-center gap-2"><Clock className="w-3.5 h-3.5" />Recent Referrals</h3>
          <SectionCard className="divide-y divide-white/[0.04]">
            {(stats.recentReferrals || []).length === 0 && <div className="p-6 text-center text-white/20 text-xs">No referrals yet</div>}
            {(stats.recentReferrals || []).map((r: any) => (
              <div key={r.id} className="flex items-center gap-3 px-4 py-3">
                <Avatar className="h-7 w-7"><AvatarImage src={r.avatar} /><AvatarFallback className="bg-blue-600/20 text-blue-400 text-[10px]">{r.username?.[0]?.toUpperCase()}</AvatarFallback></Avatar>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium text-white truncate">{r.username}</p>
                  <p className="text-[10px] text-white/30">Referred by {r.referredBy?.username || 'unknown'}</p>
                </div>
                <span className="text-[10px] text-white/20">{new Date(r.createdAt).toLocaleDateString()}</span>
              </div>
            ))}
          </SectionCard>
        </div>
      </div>
    </div>
  )
}

function LeaderboardSection({ data }: any) {
  return (
    <div>
      <SectionHeader title="Leaderboard" description="Top sellers, buyers, and items by performance" />
      <div className="grid lg:grid-cols-3 gap-4">
        <div>
          <h3 className="text-xs font-semibold text-white/60 mb-3 flex items-center gap-2"><Trophy className="w-3.5 h-3.5 text-amber-400" />Top Sellers</h3>
          <SectionCard className="divide-y divide-white/[0.04]">
            {(data.topSellers || []).length === 0 && <div className="p-6 text-center text-white/20 text-xs">No data</div>}
            {(data.topSellers || []).map((s: any, i: number) => (
              <div key={s.id} className="flex items-center gap-3 px-4 py-3">
                <span className={`text-xs font-bold w-5 ${i === 0 ? 'text-amber-400' : i === 1 ? 'text-zinc-300' : i === 2 ? 'text-amber-700' : 'text-white/20'}`}>#{i + 1}</span>
                <Avatar className="h-7 w-7"><AvatarImage src={s.avatar} /><AvatarFallback className="bg-amber-600/20 text-amber-400 text-[10px]">{s.username?.[0]?.toUpperCase()}</AvatarFallback></Avatar>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium text-white truncate">{s.username}</p>
                  <p className="text-[10px] text-white/30">{s._count?.items || 0} items</p>
                </div>
                <span className="text-xs font-semibold text-emerald-400">{s.totalSales} sales</span>
              </div>
            ))}
          </SectionCard>
        </div>
        <div>
          <h3 className="text-xs font-semibold text-white/60 mb-3 flex items-center gap-2"><Download className="w-3.5 h-3.5 text-blue-400" />Top Buyers</h3>
          <SectionCard className="divide-y divide-white/[0.04]">
            {(data.topBuyers || []).length === 0 && <div className="p-6 text-center text-white/20 text-xs">No data</div>}
            {(data.topBuyers || []).map((b: any, i: number) => (
              <div key={b.id} className="flex items-center gap-3 px-4 py-3">
                <span className={`text-xs font-bold w-5 ${i < 3 ? 'text-blue-400' : 'text-white/20'}`}>#{i + 1}</span>
                <Avatar className="h-7 w-7"><AvatarImage src={b.avatar} /><AvatarFallback className="bg-blue-600/20 text-blue-400 text-[10px]">{b.username?.[0]?.toUpperCase()}</AvatarFallback></Avatar>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium text-white truncate">{b.username}</p>
                </div>
                <span className="text-xs text-white/40">{b._count?.downloadRecords || 0} downloads</span>
              </div>
            ))}
          </SectionCard>
        </div>
        <div>
          <h3 className="text-xs font-semibold text-white/60 mb-3 flex items-center gap-2"><Star className="w-3.5 h-3.5 text-purple-400" />Top Items</h3>
          <SectionCard className="divide-y divide-white/[0.04]">
            {(data.topItems || []).length === 0 && <div className="p-6 text-center text-white/20 text-xs">No data</div>}
            {(data.topItems || []).map((item: any, i: number) => (
              <div key={item.id} className="flex items-center gap-3 px-4 py-3">
                <span className={`text-xs font-bold w-5 ${i < 3 ? 'text-purple-400' : 'text-white/20'}`}>#{i + 1}</span>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium text-white truncate">{item.title}</p>
                  <p className="text-[10px] text-white/30">by {item.author?.username} · {item.downloads} DLs · {item.views} views</p>
                </div>
                <span className="text-xs font-semibold text-emerald-400">{item.price > 0 ? `$${item.price}` : 'Free'}</span>
              </div>
            ))}
          </SectionCard>
        </div>
      </div>
    </div>
  )
}

function MysteryRewardsSection({ rewards, logs, editReward, setEditReward, saveReward, deleteReward }: any) {
  return (
    <div>
      <SectionHeader title="Mystery Rewards" description={`${rewards.length} reward types · Random rewards after purchases`} />
      <div className="flex justify-end mb-4">
        <Button onClick={() => setEditReward({ name: '', type: 'COINS', value: 1, probability: 0.1, isActive: true })} className="bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl gap-1.5 text-xs"><Plus className="h-3.5 w-3.5" />Add Reward</Button>
      </div>
      <div className="grid gap-3 mb-6">
        {rewards.length === 0 && <SectionCard className="p-8 text-center"><Gift className="w-8 h-8 text-white/10 mx-auto mb-2" /><p className="text-white/30 text-sm">No rewards configured</p></SectionCard>}
        {rewards.map((r: any) => (
          <SectionCard key={r.id} className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500/20 to-purple-500/20 flex items-center justify-center"><Gift className="w-5 h-5 text-amber-400" /></div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-white">{r.name}</p>
                <div className="flex gap-2 text-[10px] text-white/30">
                  <span>Type: {r.type}</span>
                  <span>Value: {r.type === 'COINS' ? `$${r.value}` : `${r.value}%`}</span>
                  <span>Chance: {(r.probability * 100).toFixed(0)}%</span>
                </div>
              </div>
              <Badge className={`text-[9px] h-4 ${r.isActive ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' : 'bg-red-500/10 text-red-400 border-red-500/20'}`}>{r.isActive ? 'Active' : 'Off'}</Badge>
              <Button variant="ghost" size="sm" onClick={() => setEditReward({ ...r })} className="h-7 w-7 p-0 text-white/30 hover:text-white"><Edit className="h-3 w-3" /></Button>
              <Button variant="ghost" size="sm" onClick={() => deleteReward(r.id)} className="h-7 w-7 p-0 text-white/30 hover:text-red-400"><Trash2 className="h-3 w-3" /></Button>
            </div>
          </SectionCard>
        ))}
      </div>
      {logs.length > 0 && (
        <div>
          <h3 className="text-xs font-semibold text-white/60 mb-3">Recent Reward Logs</h3>
          <SectionCard className="divide-y divide-white/[0.04]">
            {logs.map((l: any) => (
              <div key={l.id} className="flex items-center gap-3 px-4 py-2.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <div className="flex-1"><p className="text-xs text-white/60">User won {l.type === 'COINS' ? `$${l.value}` : `${l.value}% discount`}</p></div>
                <span className="text-[10px] text-white/20">{new Date(l.createdAt).toLocaleDateString()}</span>
              </div>
            ))}
          </SectionCard>
        </div>
      )}
      <Dialog open={!!editReward} onOpenChange={() => setEditReward(null)}>
        <DialogContent className="bg-[#0c0c1a] border-white/[0.08] text-white max-w-md">
          <DialogHeader><DialogTitle className="text-white text-base">{editReward?.id ? 'Edit Reward' : 'Add Reward'}</DialogTitle><DialogDescription className="text-white/30 text-xs">Configure mystery reward</DialogDescription></DialogHeader>
          {editReward && (
            <div className="space-y-3">
              <div><Label className="text-white/40 text-[11px] mb-1.5 block">Name *</Label><Input value={editReward.name || ''} onChange={(e: any) => setEditReward((p: any) => ({ ...p, name: e.target.value }))} placeholder="Lucky Coins" className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" /></div>
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <Label className="text-white/40 text-[11px] mb-1.5 block">Type</Label>
                  <Select value={editReward.type || 'COINS'} onValueChange={(v: string) => setEditReward((p: any) => ({ ...p, type: v }))}>
                    <SelectTrigger className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl h-10"><SelectValue /></SelectTrigger>
                    <SelectContent className="bg-[#0c0c1a] border-white/[0.08]">
                      <SelectItem value="COINS" className="text-white">Coins</SelectItem>
                      <SelectItem value="DISCOUNT" className="text-white">Discount %</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div><Label className="text-white/40 text-[11px] mb-1.5 block">Value</Label><Input type="number" step="0.01" value={editReward.value || ''} onChange={(e: any) => setEditReward((p: any) => ({ ...p, value: parseFloat(e.target.value) || 0 }))} className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" /></div>
                <div><Label className="text-white/40 text-[11px] mb-1.5 block">Chance (0-1)</Label><Input type="number" step="0.01" min="0" max="1" value={editReward.probability || ''} onChange={(e: any) => setEditReward((p: any) => ({ ...p, probability: parseFloat(e.target.value) || 0 }))} className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" /></div>
              </div>
              <div className="flex items-center gap-2"><Switch checked={editReward.isActive ?? true} onCheckedChange={(v: boolean) => setEditReward((p: any) => ({ ...p, isActive: v }))} /><Label className="text-white/40 text-xs">Active</Label></div>
              <div className="flex gap-2 justify-end pt-2">
                <Button variant="ghost" onClick={() => setEditReward(null)} className="text-white/40 hover:text-white hover:bg-white/5 rounded-xl text-xs">Cancel</Button>
                <Button onClick={saveReward} className="bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl gap-1.5 text-xs"><Save className="h-3.5 w-3.5" />{editReward.id ? 'Update' : 'Create'}</Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

function TeamsSection({ teams }: any) {
  return (
    <div>
      <SectionHeader title="Teams" description={`${teams.length} teams · Manage seller team accounts`} />
      <div className="grid gap-3">
        {teams.length === 0 && <SectionCard className="p-8 text-center"><Users2 className="w-8 h-8 text-white/10 mx-auto mb-2" /><p className="text-white/30 text-sm">No teams created yet</p></SectionCard>}
        {teams.map((t: any) => (
          <SectionCard key={t.id} className="p-4">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500/20 to-purple-500/20 flex items-center justify-center"><Users2 className="w-5 h-5 text-blue-400" /></div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-white">{t.name}</p>
                <p className="text-[10px] text-white/30">Owner: {t.owner?.username || 'Unknown'} · {t.members?.length || 0} members</p>
              </div>
              <span className="text-[10px] text-white/20">{new Date(t.createdAt).toLocaleDateString()}</span>
            </div>
            {t.description && <p className="text-xs text-white/40 mb-2">{t.description}</p>}
            <div className="flex flex-wrap gap-2">
              {(t.members || []).map((m: any) => (
                <div key={m.id} className="flex items-center gap-1.5 bg-white/[0.03] rounded-lg px-2 py-1">
                  <Avatar className="h-5 w-5"><AvatarImage src={m.user?.avatar} /><AvatarFallback className="bg-purple-600/20 text-purple-400 text-[8px]">{m.user?.username?.[0]?.toUpperCase()}</AvatarFallback></Avatar>
                  <span className="text-[10px] text-white/60">{m.user?.username}</span>
                  <Badge className="text-[7px] h-3.5 bg-white/[0.04] text-white/30 border-white/[0.06]">{m.role}</Badge>
                </div>
              ))}
            </div>
          </SectionCard>
        ))}
      </div>
    </div>
  )
}

function CollaborationsSection({ collaborations }: any) {
  return (
    <div>
      <SectionHeader title="Collaborations" description={`${collaborations.length} collaborations · Track item revenue sharing`} />
      <SectionCard className="overflow-hidden">
        {collaborations.length === 0 && <div className="p-8 text-center"><Handshake className="w-8 h-8 text-white/10 mx-auto mb-2" /><p className="text-white/30 text-sm">No collaborations yet</p></div>}
        <div className="divide-y divide-white/[0.04]">
          {collaborations.map((c: any) => (
            <div key={c.id} className="flex items-center gap-3 px-4 py-3 hover:bg-white/[0.02] transition-colors">
              <Handshake className="w-4 h-4 text-purple-400 flex-shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-xs font-medium text-white truncate">{c.item?.title || 'Unknown Item'}</p>
                <p className="text-[10px] text-white/30">Collaborator: {c.user?.username || 'Unknown'} · Revenue share: {c.revenueShare}%</p>
              </div>
              <Badge className={`text-[9px] h-4 ${c.status === 'APPROVED' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' : c.status === 'PENDING' ? 'bg-amber-500/10 text-amber-400 border-amber-500/20' : 'bg-red-500/10 text-red-400 border-red-500/20'}`}>{c.status}</Badge>
              <span className="text-[10px] text-white/20">{new Date(c.createdAt).toLocaleDateString()}</span>
            </div>
          ))}
        </div>
      </SectionCard>
    </div>
  )
}
