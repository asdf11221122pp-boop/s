'use client'

import { useEffect, useState } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { ArrowLeft, Check, X, RefreshCw } from 'lucide-react'
import { toast } from 'sonner'

interface AppSubmission {
  id: string
  name: string
  slug: string
  description: string
  shortDesc?: string | null
  category?: string | null
  screenshotUrls?: string[] | null
  logoUrl?: string | null
  downloadUrl?: string | null
  repoUrl?: string | null
  isApproved: boolean
  createdAt: string
  author: { username: string }
}

export default function AdminAppSubmissionsPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [submissions, setSubmissions] = useState<AppSubmission[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/auth/signin')
    }
    if (status === 'authenticated') {
      loadSubmissions()
    }
  }, [status, router])

  const loadSubmissions = async () => {
    setLoading(true)
    try {
      const res = await fetch('/api/admin/app-submissions')
      if (res.ok) {
        const data = await res.json()
        setSubmissions(Array.isArray(data.appSubmissions) ? data.appSubmissions : [])
      } else {
        const err = await res.json().catch(() => ({}))
        toast.error(err.error || 'Failed to load submissions')
      }
    } catch (error) {
      console.error(error)
      toast.error('Failed to load submissions')
    } finally {
      setLoading(false)
    }
  }

  const updateApproval = async (id: string, approve: boolean) => {
    try {
      const res = await fetch('/api/admin/app-submissions', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, approve })
      })
      if (res.ok) {
        toast.success(`App ${approve ? 'approved' : 'rejected'}`)
        loadSubmissions()
      } else {
        const err = await res.json().catch(() => ({}))
        toast.error(err.error || 'Failed to update submission')
      }
    } catch (error) {
      console.error(error)
      toast.error('Failed to update submission')
    }
  }

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white">
      <div className="container mx-auto px-4 py-10">
        <div className="mb-8 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div>
            <Link href="/admin" className="inline-flex items-center gap-2 text-white/60 hover:text-white">
              <ArrowLeft className="w-4 h-4" /> Back to Admin
            </Link>
            <h1 className="mt-4 text-4xl font-bold">App Submissions</h1>
            <p className="mt-2 text-white/50 max-w-2xl">Review and approve or reject submitted apps before they appear in the public apps store.</p>
          </div>
          <Button variant="outline" onClick={loadSubmissions} className="text-white/80 border-white/10">
            <RefreshCw className="w-4 h-4 mr-2" /> Refresh
          </Button>
        </div>

        <div className="overflow-x-auto rounded-3xl border border-white/10 bg-white/5 p-4">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>App</TableHead>
                <TableHead>Author</TableHead>
                <TableHead>Category</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {submissions.map((app) => (
                <TableRow key={app.id}>
                  <TableCell className="font-medium">{app.name}</TableCell>
                  <TableCell>{app.author.username}</TableCell>
                  <TableCell>{app.category || 'Unspecified'}</TableCell>
                  <TableCell>
                    <Badge className={app.isApproved ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' : 'bg-amber-500/10 text-amber-400 border-amber-500/20'}>
                      {app.isApproved ? 'Approved' : 'Pending'}
                    </Badge>
                  </TableCell>
                  <TableCell className="space-x-2">
                    {!app.isApproved && (
                      <>
                        <Button size="sm" variant="outline" onClick={() => updateApproval(app.id, true)}>
                          <Check className="w-4 h-4" />
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => updateApproval(app.id, false)}>
                          <X className="w-4 h-4" />
                        </Button>
                      </>
                    )}
                    <Link href={`/apps/${app.slug}`} className="inline-flex items-center text-blue-300 hover:text-blue-100 text-sm">View</Link>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          {!loading && submissions.length === 0 && (
            <div className="py-12 text-center text-white/50">No app submissions found.</div>
          )}
        </div>
      </div>
    </div>
  )
}
