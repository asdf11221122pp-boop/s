'use client'

import { useEffect, useRef, useState } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { toast } from 'sonner'
import Link from 'next/link'
import { ArrowLeft, Upload, FileVideo, Music, Image as ImageIcon, Youtube } from 'lucide-react'

export default function WatchSubmitPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [title, setTitle] = useState('')
  const [caption, setCaption] = useState('')
  const [tags, setTags] = useState('')
  const [type, setType] = useState('VIDEO')
  const [youtubeUrl, setYoutubeUrl] = useState('')
  const [file, setFile] = useState<File | null>(null)
  const [thumbnail, setThumbnail] = useState<File | null>(null)
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/auth/signin')
    }
  }, [status, router])

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = event.target.files?.[0] || null
    setFile(selectedFile)
  }

  const handleThumbnailChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = event.target.files?.[0] || null
    setThumbnail(selectedFile)
  }

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault()

    if (!title.trim()) {
      toast.error('Title is required')
      return
    }

    if (!caption.trim()) {
      toast.error('Caption is required')
      return
    }

    if (!file && !youtubeUrl.trim()) {
      toast.error('Upload a file or provide a YouTube link')
      return
    }

    setLoading(true)

    try {
      const formData = new FormData()
      formData.append('title', title)
      formData.append('caption', caption)
      formData.append('type', type)
      formData.append('tags', tags)
      if (youtubeUrl.trim()) formData.append('youtubeUrl', youtubeUrl.trim())
      if (file) formData.append('file', file)
      if (thumbnail) formData.append('thumbnail', thumbnail)

      const response = await fetch('/api/watch/posts', {
        method: 'POST',
        body: formData
      })

      const result = await response.json()
      if (!response.ok) {
        toast.error(result.error || 'Failed to submit media')
      } else {
        toast.success('Media submitted successfully!')
        router.push('/watch')
      }
    } catch (error) {
      console.error(error)
      toast.error('Upload failed. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white">
      <Navbar />
      <main className="container mx-auto px-4 py-10">
        <div className="mb-8 flex items-center justify-between gap-4">
          <div>
            <Link href="/watch" className="inline-flex items-center gap-2 text-white/60 hover:text-white">
              <ArrowLeft className="w-4 h-4" /> Back to Watch
            </Link>
            <h1 className="mt-4 text-4xl font-bold">Share Your Media</h1>
            <p className="mt-2 text-white/50 max-w-2xl">Upload a video, audio track, or photo post for the community. You can also share a YouTube video directly.</p>
          </div>
          <div className="rounded-3xl border border-white/10 bg-white/5 p-4">
            <p className="text-sm text-white/50">Want a quick demo? Add your media and submit it to the watch feed.</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} encType="multipart/form-data" className="space-y-8 rounded-3xl border border-white/10 bg-white/5 p-8">
          <div className="grid gap-6 lg:grid-cols-2">
            <div>
              <Label htmlFor="title">Title</Label>
              <Input id="title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Enter a catchy title" className="mt-2 bg-[#10121b] border-white/10 text-white" />
            </div>
            <div>
              <Label htmlFor="type">Media Type</Label>
              <Select value={type} onValueChange={(value) => setType(value)}>
                <SelectTrigger id="type" className="mt-2 bg-[#10121b] border-white/10 text-white">
                  <SelectValue placeholder="Select media type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="VIDEO">Video</SelectItem>
                  <SelectItem value="AUDIO">Audio</SelectItem>
                  <SelectItem value="PHOTO">Photo</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label htmlFor="caption">Caption</Label>
            <Textarea id="caption" value={caption} onChange={(e) => setCaption(e.target.value)} placeholder="Write a description for your media" className="mt-2 bg-[#10121b] border-white/10 text-white" rows={5} />
          </div>

          <div className="grid gap-6 lg:grid-cols-2">
            <div>
              <Label htmlFor="tags">Tags</Label>
              <Input id="tags" value={tags} onChange={(e) => setTags(e.target.value)} placeholder="e.g. gaming, tutorial, music" className="mt-2 bg-[#10121b] border-white/10 text-white" />
            </div>
            <div>
              <Label htmlFor="youtubeUrl">YouTube Link (optional)</Label>
              <Input id="youtubeUrl" value={youtubeUrl} onChange={(e) => setYoutubeUrl(e.target.value)} placeholder="https://youtu.be/abc123" className="mt-2 bg-[#10121b] border-white/10 text-white" />
            </div>
          </div>

          <div className="grid gap-6 lg:grid-cols-2">
            <div>
              <Label htmlFor="file">Upload Media File</Label>
              <Input ref={fileInputRef} id="file" type="file" accept="video/*,audio/*,image/*" onChange={handleFileChange} className="mt-2 bg-[#10121b] border-white/10 text-white" />
              <p className="mt-2 text-xs text-white/50">Supported files: mp4, webm, mp3, wav, jpg, png, gif.</p>
              {file ? <p className="mt-2 text-sm text-white/60">Selected file: {file.name}</p> : null}
            </div>
            <div>
              <Label htmlFor="thumbnail">Thumbnail / Cover Image</Label>
              <Input id="thumbnail" type="file" accept="image/*" onChange={handleThumbnailChange} className="mt-2 bg-[#10121b] border-white/10 text-white" />
              {thumbnail ? <p className="mt-2 text-sm text-white/60">Selected thumbnail: {thumbnail.name}</p> : null}
            </div>
          </div>

          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <p className="text-sm text-white/50">Your upload will appear in the Watch feed instantly.</p>
            <Button type="submit" className="bg-gradient-to-r from-purple-600 to-blue-600" disabled={loading}>
              {loading ? 'Submitting...' : 'Submit Media'}
            </Button>
          </div>
        </form>
      </main>
      <Footer />
    </div>
  )
}
