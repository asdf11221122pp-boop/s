'use client'

import { useEffect, useMemo, useState } from 'react'
import Link from 'next/link'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Play, Image, Music, Link2, ArrowRight, Video } from 'lucide-react'

export const dynamic = 'force-dynamic'

interface WatchPost {
  id: string
  title: string
  caption: string
  type: 'VIDEO' | 'AUDIO' | 'PHOTO' | string
  assetUrl: string
  thumbnailUrl?: string | null
  youtubeVideoId?: string | null
  tags: string[]
  source?: string
  author: { username: string }
  createdAt: string
}

interface YoutubeVideo {
  videoId: string
  title: string
  thumbnail: string
  link: string
  published: string
}

const FILTERS = [
  { label: 'All', value: 'ALL' },
  { label: 'Videos', value: 'VIDEO' },
  { label: 'Audio', value: 'AUDIO' },
  { label: 'Photos', value: 'PHOTO' }
]

export default function WatchPage() {
  const [posts, setPosts] = useState<WatchPost[]>([])
  const [youtubeVideo, setYoutubeVideo] = useState<YoutubeVideo | null>(null)
  const [loading, setLoading] = useState(true)
  const [activeFilter, setActiveFilter] = useState('ALL')

  useEffect(() => {
    const loadFeed = async () => {
      setLoading(true)
      try {
        const [postsRes, ytRes] = await Promise.all([
          fetch('/api/watch/posts?limit=30'),
          fetch('/api/watch/youtube')
        ])
        if (postsRes.ok) {
          const data = await postsRes.json()
          setPosts(Array.isArray(data.posts) ? data.posts : [])
        }
        if (ytRes.ok) {
          const data = await ytRes.json()
          setYoutubeVideo(data.video || null)
        }
      } catch (error) {
        console.error('Failed to load watch feed', error)
      } finally {
        setLoading(false)
      }
    }
    loadFeed()
  }, [])

  const filteredPosts = useMemo(() => {
    if (activeFilter === 'ALL') return posts
    return posts.filter((post) => post.type === activeFilter)
  }, [posts, activeFilter])

  const featuredPost = useMemo(() => {
    return posts.find((post) => post.source === 'youtube' && post.type === 'VIDEO') || posts[0] || null
  }, [posts])

  const renderPreview = (post: WatchPost) => {
    if (post.type === 'VIDEO') {
      if (post.youtubeVideoId) {
        return (
          <div className="relative overflow-hidden rounded-2xl bg-black">
            <iframe
              className="w-full aspect-video"
              src={`https://www.youtube.com/embed/${post.youtubeVideoId}`}
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
              title={post.title}
            />
          </div>
        )
      }

      if (post.assetUrl) {
        return (
          <video controls className="w-full rounded-2xl bg-black">
            <source src={post.assetUrl} />
            Your browser does not support the video tag.
          </video>
        )
      }
    }

    if (post.type === 'AUDIO' && post.assetUrl) {
      return (
        <div className="rounded-2xl bg-slate-950 p-4">
          <audio controls className="w-full">
            <source src={post.assetUrl} />
            Your browser does not support the audio element.
          </audio>
        </div>
      )
    }

    return (
      <div className="rounded-2xl overflow-hidden bg-slate-950">
        <img
          src={post.thumbnailUrl || post.assetUrl || '/placeholder-item.png'}
          alt={post.title}
          className="w-full h-60 object-cover"
        />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white">
      <Navbar />
      <main className="container mx-auto px-4 py-10">
        <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
          <div>
            <h1 className="text-4xl font-bold">Watch</h1>
            <p className="mt-2 text-white/60 max-w-2xl">Watch videos, listen to audio, browse photo posts, and share your own creator media in one place.</p>
          </div>
          <div className="flex flex-col sm:flex-row gap-3">
            <Link href="/watch/submit">
              <Button className="bg-gradient-to-r from-purple-600 to-blue-600 text-white">Upload Media</Button>
            </Link>
            <Link href="/ai">
              <Button variant="outline" className="text-white/80 border-white/10">AI Chat</Button>
            </Link>
          </div>
        </div>

        {youtubeVideo ? (
          <section className="mt-10 rounded-3xl border border-white/10 bg-white/5 p-6">
            <div className="flex flex-col md:flex-row gap-6 items-start">
              <div className="w-full md:w-1/2 rounded-3xl overflow-hidden bg-black">
                <iframe
                  className="w-full aspect-video"
                  src={`https://www.youtube.com/embed/${youtubeVideo.videoId}`}
                  title={youtubeVideo.title}
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                />
              </div>
              <div className="space-y-3">
                <div className="inline-flex items-center gap-2 rounded-full bg-purple-500/10 px-3 py-1 text-sm text-purple-300">
                  <Play className="h-4 w-4" /> Latest channel video
                </div>
                <h2 className="text-2xl font-semibold">{youtubeVideo.title}</h2>
                <p className="text-sm text-white/50">Published on {new Date(youtubeVideo.published).toLocaleDateString()}</p>
                <Link href={youtubeVideo.link} className="inline-flex items-center gap-2 text-sm text-blue-300 hover:text-blue-100">
                  Watch on YouTube <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
            </div>
          </section>
        ) : null}

        <section className="mt-10">
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between mb-6">
            <div>
              <p className="text-sm uppercase tracking-[0.3em] text-white/40">Community feed</p>
              <h2 className="text-3xl font-semibold">Latest creator media</h2>
            </div>
            <div className="flex flex-wrap gap-2">
              {FILTERS.map((filter) => (
                <button
                  key={filter.value}
                  type="button"
                  onClick={() => setActiveFilter(filter.value)}
                  className={`rounded-full border px-4 py-2 text-sm transition ${activeFilter === filter.value ? 'border-purple-400 bg-purple-500/10 text-white' : 'border-white/10 text-white/60 hover:border-white/30 hover:text-white'}`}
                >
                  {filter.label}
                </button>
              ))}
            </div>
          </div>

          <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
            {filteredPosts.map((post) => (
              <article key={post.id} className="rounded-3xl border border-white/10 bg-slate-950 overflow-hidden shadow-lg shadow-black/20">
                {renderPreview(post)}
                <div className="p-5 space-y-4">
                  <div className="flex items-center justify-between gap-3">
                    <div className="inline-flex items-center gap-2 rounded-full bg-white/5 px-3 py-1 text-xs uppercase tracking-[0.2em] text-white/60">
                      {post.type === 'PHOTO' ? <Image className="w-3.5 h-3.5" /> : post.type === 'AUDIO' ? <Music className="w-3.5 h-3.5" /> : <Video className="w-3.5 h-3.5" />} {post.type.toLowerCase()}
                    </div>
                    <span className="text-xs text-white/40">{new Date(post.createdAt).toLocaleDateString()}</span>
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold leading-tight">{post.title}</h3>
                    <p className="mt-2 text-sm text-white/60 line-clamp-3">{post.caption}</p>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {post.tags?.map((tag) => (
                      <Badge key={`${post.id}-${tag}`} className="bg-white/5 text-white/70">#{tag}</Badge>
                    ))}
                  </div>
                  <div className="flex items-center justify-between gap-4 text-sm text-white/50">
                    <span>By {post.author.username}</span>
                    {post.source === 'youtube' ? (
                      <Link href={post.assetUrl} className="inline-flex items-center gap-1 text-blue-300 hover:text-blue-100">
                        <Link2 className="w-4 h-4" /> YouTube
                      </Link>
                    ) : null}
                  </div>
                </div>
              </article>
            ))}
          </div>

          {!loading && filteredPosts.length === 0 ? (
            <div className="mt-8 rounded-3xl border border-dashed border-white/10 bg-white/5 p-8 text-center text-white/60">
              No media posts yet. Be the first creator to share a video, song or photo.
            </div>
          ) : null}
        </section>
      </main>
      <Footer />
    </div>
  )
}
