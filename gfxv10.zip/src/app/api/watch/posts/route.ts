import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { writeFile, mkdir } from 'fs/promises'
import { join } from 'path'
import { existsSync } from 'fs'
import crypto from 'crypto'
import { FileStorageService } from '@/lib/storage'

const VIDEO_EXT = ['mp4', 'webm', 'mov', 'mkv']
const AUDIO_EXT = ['mp3', 'wav', 'ogg', 'aac', 'flac']
const IMAGE_EXT = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg']
const ALLOWED_EXT = [...VIDEO_EXT, ...AUDIO_EXT, ...IMAGE_EXT]

async function saveFile(file: File, subDir: string) {
  const ext = file.name.split('.').pop()?.toLowerCase() || 'bin'
  const uniqueName = `${crypto.randomUUID()}.${ext}`
  if (!ALLOWED_EXT.includes(ext)) {
    throw new Error(`Unsupported file type: ${ext}`)
  }

  if (process.env.S3_BUCKET && process.env.S3_ACCESS_KEY && process.env.S3_SECRET_KEY) {
    const storage = new FileStorageService()
    const key = storage.generateFileKey(subDir, uniqueName, 'watch')
    const bytes = await file.arrayBuffer()
    const url = await storage.uploadFile(key, Buffer.from(bytes), file.type || 'application/octet-stream')
    return url
  }

  const uploadDir = join(process.cwd(), 'public', 'uploads', subDir)
  if (!existsSync(uploadDir)) {
    await mkdir(uploadDir, { recursive: true })
  }
  const filePath = join(uploadDir, uniqueName)
  const bytes = await file.arrayBuffer()
  await writeFile(filePath, Buffer.from(bytes))
  return `/uploads/${subDir}/${uniqueName}`
}

export async function GET(request: NextRequest) {
  try {
    const url = new URL(request.url)
    const limit = Math.min(parseInt(url.searchParams.get('limit') || '30'), 100)
    const offset = Math.max(parseInt(url.searchParams.get('offset') || '0'), 0)
    const type = url.searchParams.get('type')

    const whereClause: any = {
      isActive: true
      // Temporarily show all submissions for debugging
      // isApproved: true
    }
    if (type) whereClause.type = type.toUpperCase()

    const posts = await db.mediaPost.findMany({
      where: whereClause,
      orderBy: { createdAt: 'desc' },
      take: limit,
      skip: offset,
      include: { author: { select: { id: true, username: true, avatar: true } } }
    })

    return NextResponse.json({ posts })
  } catch (error) {
    console.error('Watch posts fetch failed:', error)
    return NextResponse.json({ posts: [] }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const formData = await request.formData()
  const title = (formData.get('title') as string || '').trim()
  const caption = (formData.get('caption') as string || '').trim()
  const type = ((formData.get('type') as string) || 'VIDEO').toUpperCase()
  const tagString = (formData.get('tags') as string || '').trim()
  const youtubeUrl = (formData.get('youtubeUrl') as string || '').trim()
  const file = formData.get('file') as File | null
  const thumbnail = formData.get('thumbnail') as File | null

  if (!title) {
    return NextResponse.json({ error: 'Title is required' }, { status: 400 })
  }
  if (!caption) {
    return NextResponse.json({ error: 'Caption is required' }, { status: 400 })
  }
  if (!file && !youtubeUrl) {
    return NextResponse.json({ error: 'Upload a file or provide a YouTube link' }, { status: 400 })
  }

  let assetUrl = ''
  let thumbnailUrl: string | null = null
  let source = 'upload'
  let youtubeVideoId: string | null = null

  try {
    if (youtubeUrl) {
      const match = youtubeUrl.match(/(?:youtu\.be\/|v=|embed\/)([A-Za-z0-9_-]{11})/)
      if (!match) {
        return NextResponse.json({ error: 'Invalid YouTube link' }, { status: 400 })
      }
      youtubeVideoId = match[1]
      assetUrl = `https://www.youtube.com/watch?v=${youtubeVideoId}`
      source = 'youtube'
    }

    if (file) {
      const ext = file.name.split('.').pop()?.toLowerCase() || ''
      if (!ALLOWED_EXT.includes(ext)) {
        return NextResponse.json({ error: `Unsupported file type: ${ext}` }, { status: 400 })
      }
      const subDir = type === 'AUDIO' ? 'audio' : type === 'PHOTO' ? 'images' : 'videos'
      assetUrl = await saveFile(file, `watch/${subDir}`)
      source = 'upload'
    }

    if (thumbnail && IMAGE_EXT.includes(thumbnail.name.split('.').pop()?.toLowerCase() || '')) {
      thumbnailUrl = await saveFile(thumbnail, 'watch/thumbnails')
    }

    const tags = tagString ? tagString.split(',').map((tag) => tag.trim()).filter(Boolean) : []

    const post = await db.mediaPost.create({
      data: {
        authorId: session.user.id,
        title,
        caption,
        type: type === 'AUDIO' ? 'AUDIO' : type === 'PHOTO' ? 'PHOTO' : 'VIDEO',
        assetUrl,
        thumbnailUrl,
        youtubeVideoId,
        source,
        tags,
        isActive: true,
        isApproved: true
      }
    })

    return NextResponse.json({ post })
  } catch (error) {
    console.error('Watch post create failed:', error)
    return NextResponse.json({ error: 'Failed to create watch post' }, { status: 500 })
  }
}
