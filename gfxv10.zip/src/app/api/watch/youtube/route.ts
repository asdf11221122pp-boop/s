import { NextRequest, NextResponse } from 'next/server'

export async function GET(request: NextRequest) {
  const channelId = process.env.YOUTUBE_CHANNEL_ID
  if (!channelId) {
    return NextResponse.json({ video: null })
  }

  try {
    const response = await fetch(`https://www.youtube.com/feeds/videos.xml?channel_id=${channelId}`)
    if (!response.ok) {
      return NextResponse.json({ video: null })
    }

    const xml = await response.text()
    const entryMatch = xml.match(/<entry>[\s\S]*?<yt:videoId>(.*?)<\/yt:videoId>[\s\S]*?<title>(.*?)<\/title>[\s\S]*?<media:thumbnail url="(.*?)"/i)
    if (!entryMatch) {
      return NextResponse.json({ video: null })
    }

    const videoId = entryMatch[1]
    const title = entryMatch[2]
    const thumbnail = entryMatch[3]
    const link = `https://www.youtube.com/watch?v=${videoId}`

    const publishedMatch = xml.match(/<published>(.*?)<\/published>/i)
    const published = publishedMatch?.[1] || new Date().toISOString()

    return NextResponse.json({ video: { videoId, title, thumbnail, link, published } })
  } catch (error) {
    console.error('YouTube feed fetch failed:', error)
    return NextResponse.json({ video: null })
  }
}
