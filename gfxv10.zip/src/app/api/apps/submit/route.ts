import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { writeFile, mkdir } from 'fs/promises'
import { join } from 'path'
import { existsSync } from 'fs'
import crypto from 'crypto'
import { FileStorageService } from '@/lib/storage'

const IMAGE_EXT = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg']
const APP_EXT = ['zip', 'rar', '7z', 'exe', 'dmg', 'deb', 'rpm', 'apk', 'ipa', 'appimage']

async function saveFile(file: File, subDir: string) {
  const ext = file.name.split('.').pop()?.toLowerCase() || 'bin'
  const uniqueName = `${crypto.randomUUID()}.${ext}`
  if (!IMAGE_EXT.concat(APP_EXT).includes(ext)) {
    throw new Error(`Unsupported file type: ${ext}`)
  }

  if (process.env.S3_BUCKET && process.env.S3_ACCESS_KEY && process.env.S3_SECRET_KEY) {
    const storage = new FileStorageService()
    const key = storage.generateFileKey(subDir, uniqueName, 'apps')
    const bytes = await file.arrayBuffer()
    const url = await storage.uploadFile(key, Buffer.from(bytes), file.type || 'application/octet-stream')
    return url
  }

  const uploadDir = join(process.cwd(), 'public', 'uploads', subDir)
  if (!existsSync(uploadDir)) {
    await mkdir(uploadDir, { recursive: true })
  }
  const filePath = join(uploadDir, uniqueName)
  const bytes = await file.arrayBuffer()
  await writeFile(filePath, Buffer.from(bytes))
  return `/uploads/${subDir}/${uniqueName}`
}

export async function POST(request: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const formData = await request.formData()
  const name = (formData.get('name') as string || '').trim()
  const description = (formData.get('description') as string || '').trim()
  const shortDesc = (formData.get('shortDesc') as string || '').trim()
  const category = (formData.get('category') as string || '').trim()
  const slug = (formData.get('slug') as string || '').trim().replace(/[^a-z0-9-]/gi, '-').toLowerCase() || name.toLowerCase().replace(/[^a-z0-9-]/gi, '-').replace(/--+/g, '-')
  const tagsString = (formData.get('tags') as string || '').trim()
  const tags = tagsString ? tagsString.split(',').map((tag) => tag.trim()).filter(Boolean) : []
  const repoUrl = (formData.get('repoUrl') as string || '').trim() || null
  const downloadUrl = (formData.get('downloadUrl') as string || '').trim() || null
  const logoUrl = (formData.get('logoUrl') as string || '').trim() || null
  const screenshotUrlsString = (formData.get('screenshotUrls') as string || '').trim()
  const screenshotUrls = screenshotUrlsString ? screenshotUrlsString.split(',').map((url) => url.trim()).filter(Boolean) : []
  const logoFile = formData.get('logoFile') as File | null
  const screenshotFiles = formData.getAll('screenshotFiles') as File[]
  const appFile = formData.get('appFile') as File | null

  if (!name) {
    return NextResponse.json({ error: 'App name is required' }, { status: 400 })
  }
  if (!description) {
    return NextResponse.json({ error: 'Description is required' }, { status: 400 })
  }
  if (!downloadUrl && !appFile) {
    return NextResponse.json({ error: 'Provide a download URL or upload an app file' }, { status: 400 })
  }

  let finalLogoUrl = logoUrl
  let finalScreenshotUrls = [...screenshotUrls]
  let finalDownloadUrl = downloadUrl

  try {
    if (logoFile) {
      finalLogoUrl = await saveFile(logoFile, 'apps/logos')
    }

    for (const file of screenshotFiles) {
      const url = await saveFile(file, 'apps/screenshots')
      finalScreenshotUrls.push(url)
    }

    if (appFile) {
      finalDownloadUrl = await saveFile(appFile, 'apps/files')
    }

    const existingSlug = await db.appSubmission.findUnique({ where: { slug } })
    if (existingSlug) {
      return NextResponse.json({ error: 'This app slug is already in use' }, { status: 400 })
    }

    const app = await db.appSubmission.create({
      data: {
        authorId: session.user.id,
        name,
        slug,
        description,
        shortDesc,
        category: category || null,
        tags,
        logoUrl: finalLogoUrl || null,
        screenshotUrls: finalScreenshotUrls.length > 0 ? finalScreenshotUrls : null,
        repoUrl,
        downloadUrl: finalDownloadUrl || null,
        isActive: true,
        isApproved: true
      }
    })

    return NextResponse.json({ app })
  } catch (error) {
    console.error('App submit failed:', error)
    return NextResponse.json({ error: 'Failed to submit app' }, { status: 500 })
  }
}
