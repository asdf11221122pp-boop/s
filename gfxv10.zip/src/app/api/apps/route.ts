import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const url = new URL(request.url)
    const limit = Math.min(parseInt(url.searchParams.get('limit') || '30'), 100)
    const offset = Math.max(parseInt(url.searchParams.get('offset') || '0'), 0)
    const category = url.searchParams.get('category')
    const search = url.searchParams.get('search')

    const whereClause: any = {
      isActive: true
      // Temporarily show all submissions for debugging
      // isApproved: true
    }

    if (category) {
      whereClause.category = { contains: category, mode: 'insensitive' }
    }
    if (search) {
      whereClause.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { shortDesc: { contains: search, mode: 'insensitive' } },
        { description: { contains: search, mode: 'insensitive' } }
      ]
    }

    const apps = await db.appSubmission.findMany({
      where: whereClause,
      orderBy: { createdAt: 'desc' },
      take: limit,
      skip: offset,
      include: { author: { select: { id: true, username: true, avatar: true } } }
    })

    return NextResponse.json({ apps })
  } catch (error) {
    console.error('Apps fetch failed:', error)
    return NextResponse.json({ apps: [] }, { status: 500 })
  }
}
