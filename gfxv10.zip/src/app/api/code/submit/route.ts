import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { writeFile, mkdir } from 'fs/promises'
import { join } from 'path'
import { existsSync } from 'fs'
import crypto from 'crypto'
import { FileStorageService } from '@/lib/storage'

const IMAGE_EXT = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg']
const CODE_EXT = ['zip', 'rar', '7z', 'tar.gz', 'tar', 'gz']

async function saveFile(file: File, subDir: string) {
  const ext = file.name.split('.').pop()?.toLowerCase() || 'bin'
  const uniqueName = `${crypto.randomUUID()}.${ext}`
  if (!IMAGE_EXT.concat(CODE_EXT).includes(ext)) {
    throw new Error(`Unsupported file type: ${ext}`)
  }

  if (process.env.S3_BUCKET && process.env.S3_ACCESS_KEY && process.env.S3_SECRET_KEY) {
    const storage = new FileStorageService()
    const key = storage.generateFileKey(subDir, uniqueName, 'code')
    const bytes = await file.arrayBuffer()
    const url = await storage.uploadFile(key, Buffer.from(bytes), file.type || 'application/octet-stream')
    return url
  }

  const uploadDir = join(process.cwd(), 'public', 'uploads', subDir)
  if (!existsSync(uploadDir)) {
    await mkdir(uploadDir, { recursive: true })
  }
  const filePath = join(uploadDir, uniqueName)
  const bytes = await file.arrayBuffer()
  await writeFile(filePath, Buffer.from(bytes))
  return `/uploads/${subDir}/${uniqueName}`
}

export async function POST(request: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const formData = await request.formData()
  const title = (formData.get('title') as string || '').trim()
  const slug = (formData.get('slug') as string || '').trim().replace(/[^a-z0-9-]/gi, '-').toLowerCase() || title.toLowerCase().replace(/[^a-z0-9-]/gi, '-').replace(/--+/g, '-')
  const description = (formData.get('description') as string || '').trim()
  const projectType = (formData.get('projectType') as string || 'FULLSTACK').trim()
  const tagsString = (formData.get('tags') as string || '').trim()
  const tags = tagsString ? tagsString.split(',').map((tag) => tag.trim()).filter(Boolean) : []
  const repoUrl = (formData.get('repoUrl') as string || '').trim() || null
  const downloadUrl = (formData.get('downloadUrl') as string || '').trim() || null
  const screenshotUrlsString = (formData.get('screenshotUrls') as string || '').trim()
  const screenshotUrls = screenshotUrlsString ? screenshotUrlsString.split(',').map((url) => url.trim()).filter(Boolean) : []
  const screenshotFiles = formData.getAll('screenshotFiles') as File[]
  const codeFile = formData.get('codeFile') as File | null

  if (!title) {
    return NextResponse.json({ error: 'Project title is required' }, { status: 400 })
  }
  if (!description) {
    return NextResponse.json({ error: 'Description is required' }, { status: 400 })
  }
  if (!downloadUrl && !codeFile) {
    return NextResponse.json({ error: 'Provide a download URL or upload a code file' }, { status: 400 })
  }

  let finalScreenshotUrls = [...screenshotUrls]
  let finalDownloadUrl = downloadUrl

  try {
    for (const file of screenshotFiles) {
      const url = await saveFile(file, 'code/screenshots')
      finalScreenshotUrls.push(url)
    }

    if (codeFile) {
      finalDownloadUrl = await saveFile(codeFile, 'code/files')
    }

    const existingSlug = await db.codeProject.findUnique({ where: { slug } })
    if (existingSlug) {
      return NextResponse.json({ error: 'This project slug is already in use' }, { status: 400 })
    }

    const project = await db.codeProject.create({
      data: {
        authorId: session.user.id,
        title,
        slug,
        description,
        projectType: projectType || 'FULLSTACK',
        tags,
        repoUrl,
        downloadUrl: finalDownloadUrl || null,
        screenshotUrls: finalScreenshotUrls.length > 0 ? finalScreenshotUrls : null,
        isActive: true,
        isApproved: true
      }
    })

    return NextResponse.json({ project })
  } catch (error) {
    console.error('Code submit failed:', error)
    return NextResponse.json({ error: 'Failed to submit project' }, { status: 500 })
  }
}
