import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const url = new URL(request.url)
    const limit = Math.min(parseInt(url.searchParams.get('limit') || '30'), 100)
    const offset = Math.max(parseInt(url.searchParams.get('offset') || '0'), 0)
    const search = url.searchParams.get('search')

    const whereClause: any = {
      isActive: true
      // Temporarily show all submissions for debugging
      // isApproved: true
    }

    if (search) {
      whereClause.OR = [
        { title: { contains: search, mode: 'insensitive' } },
        { description: { contains: search, mode: 'insensitive' } },
        { projectType: { contains: search, mode: 'insensitive' } }
      ]
    }

    const projects = await db.codeProject.findMany({
      where: whereClause,
      orderBy: { createdAt: 'desc' },
      take: limit,
      skip: offset,
      include: { author: { select: { id: true, username: true, avatar: true } } }
    })

    return NextResponse.json({ projects })
  } catch (error) {
    console.error('Code fetch failed:', error)
    return NextResponse.json({ projects: [] }, { status: 500 })
  }
}
