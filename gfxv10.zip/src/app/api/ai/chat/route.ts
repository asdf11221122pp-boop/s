import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export async function POST(request: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const { message } = await request.json()
  if (!message || typeof message !== 'string') {
    return NextResponse.json({ error: 'Message required' }, { status: 400 })
  }

  let openAiKey = process.env.OPENAI_API_KEY
  if (!openAiKey) {
    const settings = await db.siteSettings.findFirst()
    const themeConfig = settings?.themeConfig || {}
    openAiKey = typeof themeConfig === 'object' ? themeConfig.openAiApiKey : undefined
  }

  if (!openAiKey) {
    const fallback = `I received your message: "${message}". Right now the OpenAI API key is not configured, so this is a placeholder reply. Please set OPENAI_API_KEY in your environment or configure one in the admin settings.`
    return NextResponse.json({ reply: fallback })
  }

  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${openAiKey}`
      },
      body: JSON.stringify({
        model: 'gpt-3.5-turbo',
        messages: [
          { role: 'system', content: 'You are a helpful assistant for a creator marketplace website.' },
          { role: 'user', content: message }
        ],
        temperature: 0.8,
        max_tokens: 512
      })
    })

    if (!response.ok) {
      const errorBody = await response.text()
      console.error('OpenAI response error:', errorBody)
      return NextResponse.json({ error: 'AI service error' }, { status: 500 })
    }

    const data = await response.json()
    const reply = data?.choices?.[0]?.message?.content || 'No response available.'
    return NextResponse.json({ reply })
  } catch (error) {
    console.error('AI chat failed:', error)
    return NextResponse.json({ error: 'AI request failed' }, { status: 500 })
  }
}
