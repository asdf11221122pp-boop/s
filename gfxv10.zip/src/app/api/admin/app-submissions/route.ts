import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

function isAdmin(role?: string) {
  return ['ADMIN', 'SUPER_ADMIN'].includes(role || '')
}

export async function GET(request: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id || !isAdmin(session.user.role)) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  }

  const appSubmissions = await db.appSubmission.findMany({
    orderBy: { createdAt: 'desc' },
    include: { author: { select: { id: true, username: true, avatar: true } } }
  })

  return NextResponse.json({ appSubmissions })
}

export async function PATCH(request: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id || !isAdmin(session.user.role)) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  }

  const { id, approve } = await request.json()
  if (!id || typeof approve !== 'boolean') {
    return NextResponse.json({ error: 'Invalid request' }, { status: 400 })
  }

  const appSubmission = await db.appSubmission.update({
    where: { id },
    data: {
      isApproved: approve
    }
  })

  return NextResponse.json({ appSubmission })
}
