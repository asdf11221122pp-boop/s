import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export async function GET() {
  try {
    // Get or create default settings
    let settings = await db.siteSettings.findFirst()
    
    if (!settings) {
      // Create default settings if none exist
      settings = await db.siteSettings.create({
        data: {
          siteName: 'GfxStore'
        }
      })
    }

    let openAiApiKey = ''
    if (settings.themeConfig) {
      let themeConfig: any = {}
      if (typeof settings.themeConfig === 'object') {
        themeConfig = settings.themeConfig
      } else {
        try {
          themeConfig = JSON.parse(settings.themeConfig as string)
        } catch {
          themeConfig = {}
        }
      }
      openAiApiKey = themeConfig?.openAiApiKey || ''
    }

    return NextResponse.json({ ...settings, openAiApiKey })
  } catch (error) {
    console.error('Error fetching settings:', error)
    return NextResponse.json({ 
      siteName: 'GfxStore',
      nagadNumber: '',
      bkashNumber: '',
      announcement: ''
    }, { status: 200 })
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }
    if (!['ADMIN', 'SUPER_ADMIN'].includes(session.user.role || '')) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
    }

    const body = await request.json()
    const {
      nagadNumber, bkashNumber, siteName, announcement,
      privacyUrl, helpCenterUrl, documentationUrl, contactUsUrl,
      statusPageUrl, discordUrl, githubUrl, twitterUrl,
      privacyPolicy, termsOfService, guidelines, dmcaUrl
    } = body

    let settings = await db.siteSettings.findFirst()

    const updateData: any = {}
    if (nagadNumber !== undefined) updateData.nagadNumber = nagadNumber?.trim() || ''
    if (bkashNumber !== undefined) updateData.bkashNumber = bkashNumber?.trim() || ''
    if (siteName !== undefined) updateData.siteName = siteName?.trim() || 'GfxStore'
    if (announcement !== undefined) updateData.announcement = announcement?.trim() || ''
    if (privacyUrl !== undefined) updateData.privacyUrl = privacyUrl?.trim() || ''
    if (helpCenterUrl !== undefined) updateData.helpCenterUrl = helpCenterUrl?.trim() || ''
    if (documentationUrl !== undefined) updateData.documentationUrl = documentationUrl?.trim() || ''
    if (contactUsUrl !== undefined) updateData.contactUsUrl = contactUsUrl?.trim() || ''
    if (statusPageUrl !== undefined) updateData.statusPageUrl = statusPageUrl?.trim() || ''
    if (discordUrl !== undefined) updateData.discordUrl = discordUrl?.trim() || ''
    if (githubUrl !== undefined) updateData.githubUrl = githubUrl?.trim() || ''
    if (twitterUrl !== undefined) updateData.twitterUrl = twitterUrl?.trim() || ''
    if (privacyPolicy !== undefined) updateData.privacyPolicy = privacyPolicy?.trim() || ''
    if (termsOfService !== undefined) updateData.termsOfService = termsOfService?.trim() || ''
    if (guidelines !== undefined) updateData.guidelines = guidelines?.trim() || ''
    if (dmcaUrl !== undefined) updateData.dmcaUrl = dmcaUrl?.trim() || ''

    if (!settings) {
      settings = await db.siteSettings.create({
        data: {
          nagadNumber: nagadNumber?.trim() || '',
          bkashNumber: bkashNumber?.trim() || '',
          siteName: siteName?.trim() || 'GfxStore',
          announcement: announcement?.trim() || '',
          privacyUrl: privacyUrl?.trim() || '',
          helpCenterUrl: helpCenterUrl?.trim() || '',
          documentationUrl: documentationUrl?.trim() || '',
          contactUsUrl: contactUsUrl?.trim() || '',
          statusPageUrl: statusPageUrl?.trim() || '',
          discordUrl: discordUrl?.trim() || '',
          githubUrl: githubUrl?.trim() || '',
          twitterUrl: twitterUrl?.trim() || '',
          privacyPolicy: privacyPolicy?.trim() || '',
          termsOfService: termsOfService?.trim() || '',
          guidelines: guidelines?.trim() || '',
          dmcaUrl: dmcaUrl?.trim() || '',
          themeConfig: {
            openAiApiKey: openAiApiKey?.trim() || ''
          }
        }
      })
      return NextResponse.json({ success: true, data: settings })
    }

    if (openAiApiKey !== undefined) {
      const existingThemeConfig = typeof settings.themeConfig === 'object' ? settings.themeConfig : (settings.themeConfig ? JSON.parse(settings.themeConfig as string) : {})
      updateData.themeConfig = {
        ...existingThemeConfig,
        openAiApiKey: openAiApiKey?.trim() || ''
      }
    }

    const updated = await db.siteSettings.update({
      where: { id: settings.id },
      data: updateData
    })

    return NextResponse.json({ success: true, data: updated })
  } catch (error) {
    console.error('Error updating settings:', error)
    return NextResponse.json({ error: 'Failed to save settings. Please try again.' }, { status: 500 })
  }
}
