'use client'

import { useEffect, useState } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { toast } from 'sonner'
import { MessageSquare, Send, Sparkles } from 'lucide-react'

export const dynamic = 'force-dynamic'

interface ChatMessage {
  id: string
  role: 'user' | 'assistant'
  text: string
}

export default function AIPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/auth/signin')
    }
  }, [status, router])

  const sendMessage = async () => {
    if (!input.trim()) return
    const nextMessage: ChatMessage = { id: `${Date.now()}`, role: 'user', text: input.trim() }
    setMessages((prev) => [...prev, nextMessage])
    setInput('')
    setLoading(true)

    try {
      const response = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: nextMessage.text })
      })
      const data = await response.json()
      if (!response.ok) {
        toast.error(data.error || 'AI request failed')
      } else {
        setMessages((prev) => [...prev, { id: `${Date.now()}-ai`, role: 'assistant', text: data.reply || 'No response.' }])
      }
    } catch (error) {
      console.error('AI chat failed', error)
      toast.error('AI chat failed')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white">
      <Navbar />
      <main className="container mx-auto px-4 py-10">
        <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
          <div>
            <h1 className="text-4xl font-bold">AI Assistant</h1>
            <p className="mt-2 text-white/60 max-w-2xl">Chat with the AI assistant to ask for help, content ideas, or get quick answers directly from the website.</p>
          </div>
          <div className="inline-flex items-center gap-2 rounded-full bg-white/5 px-4 py-2 text-sm text-white/60">
            <Sparkles className="h-4 w-4" /> AI-powered conversations
          </div>
        </div>

        <div className="mt-10 rounded-3xl border border-white/10 bg-slate-950 p-6">
          <div className="space-y-4">
            {messages.length === 0 ? (
              <div className="rounded-3xl border border-dashed border-white/10 bg-white/5 p-8 text-center text-white/50">
                Start the conversation by asking a question or requesting help with your app, media, or code post.
              </div>
            ) : (
              <div className="space-y-4">
                {messages.map((message) => (
                  <div key={message.id} className={`rounded-3xl p-4 ${message.role === 'assistant' ? 'bg-white/5 text-white/90' : 'bg-purple-500/10 text-white/90'}`}>
                    <div className="flex items-center gap-2 mb-2 text-sm uppercase tracking-[0.2em] text-white/50">
                      <MessageSquare className="h-4 w-4" /> {message.role === 'assistant' ? 'AI' : 'You'}
                    </div>
                    <p className="whitespace-pre-wrap text-sm leading-6">{message.text}</p>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="mt-6 grid gap-4 lg:grid-cols-[1fr_auto]">
            <Textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              rows={4}
              placeholder="Type your question or request here..."
              className="bg-[#10121b] border-white/10 text-white"
            />
            <Button onClick={sendMessage} disabled={loading || !input.trim()} className="h-full bg-gradient-to-r from-purple-600 to-blue-600">
              {loading ? 'Thinking...' : 'Send'}
            </Button>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
