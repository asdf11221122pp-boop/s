#!/bin/bash
GFX_PATH="$(cd "$(dirname "$0")/.." && pwd)/node_modules/.prisma/client"
PNPM_PATH=$(node -e "
  const Module = require('module');
  let found = '';
  const orig = Module._resolveFilename;
  Module._resolveFilename = function(req, parent, ...a) {
    const res = orig.call(this, req, parent, ...a);
    if (req === '.prisma/client/default' && res.includes('pnpm')) found = res.replace('/default.js','');
    return res;
  };
  try { require('@prisma/client'); } catch {}
  console.log(found);
" 2>/dev/null)

if [ -n "$PNPM_PATH" ] && [ -d "$PNPM_PATH" ]; then
  cp -rf "$GFX_PATH/"* "$PNPM_PATH/"
  echo "Prisma client synced to: $PNPM_PATH"
else
  echo "Prisma client generated (no pnpm sync needed)"
fi
