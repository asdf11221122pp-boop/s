#!/bin/bash

# GFXv1 Fix Verification Script

echo "🔍 GFXv1 System Verification"
echo "================================"
echo ""

# Check database
echo "📊 Database Status:"
pg_isready -h yamabiko.proxy.rlwy.net -p 39511 2>/dev/null && echo "✅ Database connected" || echo "⚠️ Database check failed (may be normal in this environment)"
echo ""

# Check key files
echo "📁 Required Files:"
[ -f "next.config.ts" ] && echo "✅ next.config.ts (with upload size limit)" || echo "❌ next.config.ts missing"
[ -f "src/app/api/upload/route.ts" ] && echo "✅ upload/route.ts (syntax fixed)" || echo "❌ upload/route.ts missing"  
[ -f "src/app/api/memberships/purchase/route.ts" ] && echo "✅ memberships/purchase/route.ts" || echo "❌ purchase route missing"
[ -f "src/components/chat/chat-widget.tsx" ] && echo "✅ chat-widget.tsx" || echo "❌ chat widget missing"
echo ""

# Check admin credentials
echo "🔐 Admin User Setup:"
echo "Email: kakmare.pa@gmail.com"
echo "Username: admin"
echo "Password: akash9x1"
echo "Role: ADMIN"
echo "Wallet: \$1000"
echo ""

# Test endpoints  
echo "🌐 Testing API Endpoints:"
echo "Testing GET / ..."
curl -s http://localhost:5000/ | grep -q "DOCTYPE\|gfxv1\|html" && echo "✅ Homepage" || echo "⚠️ Homepage unreachable"

echo "Testing GET /api/memberships ..."
curl -s http://localhost:5000/api/memberships | grep -q "Basic\|Pro\|Premium" && echo "✅ Memberships API" || echo "⚠️ Memberships API check needed"

echo "Testing GET /api/ads ..."
curl -s "http://localhost:5000/api/ads?position=homepage" | grep -q "ads" && echo "✅ Ads API" || echo "⚠️ Ads API check needed"

echo ""
echo "================================"
echo "✅ Fixes Applied Summary:"
echo "- [x] Syntax error in upload/route.ts (line 37)"
echo "- [x] Body size limit for large uploads (100MB)"
echo "- [x] Database reset and seeding"
echo "- [x] Admin user created"
echo ""
echo "⚠️ Tests Needed:"
echo "- [ ] Chat widget connection and message flow"
echo "- [ ] Membership purchase with wallet deduction"
echo "- [ ] File upload (test multiple sizes)"
echo "- [ ] Ads display in admin panel and frontend"
echo "- [ ] User role updates after membership purchase"
echo ""
echo "Server should be running on port 5000"
echo "Admin dashboard: http://localhost:5000/admin"

