# GfxStore - Minecraft Content Marketplace

## Overview

GfxStore is a comprehensive marketplace platform for Minecraft content, similar to Modrinth. Users can upload, download, and manage various types of Minecraft content including plugins, mods, texture packs, maps, shaders, server setups, and Bedrock Edition files. The platform features a role-based access control system, real-time chat, notifications, and comprehensive analytics.

## Recent Changes (March 20, 2026) — Phase 3

### Phase 3: UI Overhaul, APIs, Security & Seller Tools
- **Item Detail Page**: Complete dark neon redesign — tabbed layout (Description/Versions/Reviews), interactive star rating, screenshot gallery with prev/next navigation, secure download via signed tokens, Add to Cart + Download buttons, Author card with seller level badge, real-time stats sidebar
- **Reviews System**: Full CRUD at `/api/reviews` — rating breakdown chart, per-rating counts, submit form in item page, reviews list with avatars and timestamps
- **Withdraw System**: `/api/seller/withdraw` POST (create requests) + GET (history); `/api/admin/withdraw` GET (all requests) + PATCH (approve/reject with admin note + wallet credit); Wallet page with full UI
- **Secure Downloads**: `/api/download/generate-token` (30-min expiry tokens) + `/api/download/secure` (validates token, serves file); item detail page uses signed tokens
- **Admin Items PATCH**: `/api/admin/items/[slug]/route.ts` — resolve by ID or slug, PATCH status/featured/isBoosted, send notification to author; DELETE
- **Admin Reports Fix**: Fixed `reported` → `reportedUser` field name in reports API and admin panel
- **Profile API**: `/api/profile` GET (own profile with stats) + PATCH (bio, socialLinks, avatar, coverImage, username with uniqueness check)
- **Admin User Updates**: Extended admin users PATCH to support `isBanned`, `isVerified`, `walletBalance` fields
- **Dashboard Fix**: Fixed orders fetch to use `?type=seller` instead of `?role=seller`
- **Browse Page**: Dark neon full redesign — grid+list view, search, category/price/sort filters, pagination
- **Wallet Page**: Dark neon redesign with withdraw flow + history
- **Admin Panel**: Full dark neon redesign — items moderation, users management, seller applications, withdrawals, reports, categories, settings
- **Profile Pages**: Own profile with edit form, stats, items grid; public `/profile/[username]` page
- **Dashboard**: Seller stats, orders management with status updates, item list with analytics
- **Seller Level Automation**: Auto-credits seller (95%) on order delivery, auto-updates level (Lv1–5), sends level-up notification
- **Seller Levels**: Lv1=0, Lv2=5, Lv3=20, Lv4=50, Lv5=100 total sales

## Recent Changes (March 20, 2026) — Phase 2

### Phase 2: Seller/Order/Advanced Features
- **Order System**: Full `/api/orders` CRUD — buy items with wallet balance, 90% seller commission, coupon support, status lifecycle (PENDING → IN_PROGRESS → DELIVERED)
- **Custom Orders Marketplace**: `/custom-orders` page + `/api/custom-orders` + `/api/custom-orders/[id]/bids` — post requests, receive bids, select winners
- **Coupon System**: Admin creates coupons at `/api/coupons`, users validate at `/api/coupons/validate`, full cart integration with coupon input, discount display
- **Report System**: `/api/report` POST/GET/PATCH — report items or users with reasons, admin review system with status updates
- **Seller Application**: `/seller/apply` page + `/api/seller/apply` — apply to become verified seller, status tracking (PENDING/APPROVED/REJECTED)
- **AI SEO Generator**: `/api/ai/seo` — smart template-based SEO content generation; integrated into Upload page with "AI Generate" button
- **Database Schema Phase 2**: Added Order, CustomOrder, CustomOrderBid, Coupon, CouponUsage, Report, SellerApplication models; new enum values (ORDER_PLACED, ORDER_ACCEPTED, etc.); seller fields on User (isVerified, sellerLevel, totalSales); boost fields on Item (isBoosted, boostExpiresAt, reportCount)
- **Freebies Page**: `/freebies` — browse all free items with search, category filter, download stats
- **Orders Page**: `/orders` — purchase history & sales management with status update buttons
- **Categories Page**: `/categories` — grid of all categories linking to filtered browse
- **Creators Page**: `/creators` — directory of all platform creators with search and level badges
- **Report Button**: `ReportButton` component added to item pages with reason selection modal
- **Cart with Coupons**: Cart page fully upgraded — coupon validation, discount display, real order placement via API, success flow
- **Navbar**: Added "Freebies" and "Custom Orders" nav links; "My Orders" in user dropdown

## Recent Changes (March 20, 2026) — Phase 1

### Major UI/UX Overhaul & New Features
- **Fixed Friend Request System**: Added "Sent" tab showing pending sent requests with cancel button; received tab with accept/reject; proper polling for real-time updates
- **New `FriendRequestList` component**: Inline version for the Messages page (separate from navbar dropdown panel)
- **Professional Dark Neon UI**: Redesigned auth pages (Sign In / Sign Up), home page, and navbar with `bg-[#0a0a0f]` dark theme and purple/blue gradient accents
- **Navbar**: Complete rewrite with search bar, wishlist/cart icons with badges, friend request dropdown panel, wallet balance, theme toggle, admin badge, mobile menu
- **Home Page**: New hero with animated background, stat cards, redesigned featured items grid, category cards, features section, VPS pricing cards, CTA section
- **Wishlist Feature**: `/wishlist` page + `/api/wishlist` POST/GET/DELETE endpoint (toggle, fetch, remove)
- **Cart Feature**: `/cart` page + `/api/cart` POST/GET/DELETE endpoint (add, fetch, remove, clear)
- **Follow System**: `/api/follow` endpoint (follow/unfollow users, get follower/following counts)
- **Database Schema**: Added `Wishlist`, `CartItem`, `Follow` models to Prisma schema + pushed to DB + regenerated client
- **User Search**: Redesigned with dark theme, better avatar display, online status, sonner toasts
- **Messages Page**: Redesigned with dark theme, Navbar included, cleaner tab layout
- **Admin credentials**: email=`kakmare.pa@gmail.com`, password=`akash9x1`

## Recent Changes (Nov 30, 2025)

- Fixed TypeScript type errors with NextAuth session types
- Implemented secure real-time Socket.io server for chat and notifications
- Added authenticated WebSocket connections using NextAuth JWT tokens
- Fixed upload system with file type/size validation and transactional handling
- Configured application to run on port 5000 with integrated Socket.io
- Seeded database with content categories
- Enhanced homepage with dynamic stats, featured items section, and improved UI
- Expanded admin dashboard with user management, item moderation, analytics, and settings
- Fixed profile page with avatar upload, bio editing, and social links
- Fixed dashboard page with user stats and item management
- Created public stats API endpoint for homepage statistics
- Added admin user with credentials (admin@gfxstore.com / admin123)
- Fixed session handling to prevent redirect loops on protected pages

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Tooling**
- Next.js 15 with App Router for server-side rendering and routing
- TypeScript 5 for type safety across the codebase
- React 18 with server and client components pattern

**UI Layer**
- Tailwind CSS 4 for utility-first styling with custom theme configuration
- shadcn/ui component library built on Radix UI primitives
- Dark/light theme support via next-themes
- Responsive design with mobile-first approach

**State Management**
- NextAuth.js sessions for authentication state
- React Context API for notifications and chat state
- TanStack Query for server state management and caching

**Routing Structure**
- `/` - Landing page with hero section and feature highlights
- `/browse` - Content discovery with filtering and search
- `/upload` - Content upload interface for creators
- `/profile` - User profile management
- `/dashboard` - Personal analytics and content management
- `/admin` - Administrative controls and moderation
- `/analytics` - Platform-wide analytics dashboard

### Backend Architecture

**API Layer**
- Next.js API Routes for serverless functions
- RESTful endpoints organized by domain (items, users, auth, admin)
- Custom WebSocket server for real-time features

**Authentication & Authorization**
- NextAuth.js v4 with JWT strategy
- Credentials provider with bcryptjs password hashing
- Role-based access control (User, Creator, Moderator, Admin, Super Admin)
- Session management with secure cookies

**Data Access Pattern**
- Prisma ORM as the database abstraction layer
- Repository pattern for data access
- Connection pooling for optimized database connections
- Direct URL for migrations, pooled URL for queries

**Real-time Services**
- Socket.IO server integrated with Next.js custom server
- Separate chat service running on dedicated port
- WebSocket connections for chat, notifications, and live updates
- User presence tracking and typing indicators

### Database Architecture

**ORM & Schema**
- Prisma as the database toolkit
- PostgreSQL via Supabase for production database
- 15+ interconnected tables modeling the domain

**Key Entities**
- Users: Authentication, profiles, roles, and permissions
- Items: Content with versioning, metadata, and status tracking
- Categories/Subcategories: Hierarchical organization of content
- Reviews/Ratings: User feedback and scoring system
- Downloads: Tracking and analytics for content distribution
- Files: Version control with S3 references
- Screenshots: Image galleries for items
- ChatMessages/Notifications: Real-time communication

**Relationships**
- One-to-many: Users to Items, Items to Files
- Many-to-many: Items to Tags (via join table)
- Hierarchical: Categories to Subcategories

### File Storage System

**Storage Provider**
- Filebase (S3-compatible) as primary storage backend
- IPFS integration for decentralized content addressing
- AWS SDK v3 for S3 operations

**Upload Strategy**
- Presigned URLs for secure client-side uploads
- Chunked upload support for large files
- File validation and virus scanning hooks
- Automatic thumbnail generation for images

**File Types Supported**
- Server files: .jar (plugins/mods)
- Resource packs: .zip
- World files: .zip, .mcworld
- Bedrock addons: .mcpack, .mcaddon
- Screenshots: .jpg, .png, .webp

**Download Mechanism**
- Presigned download URLs with expiration
- Download count tracking
- Bandwidth optimization via CDN-ready architecture

### External Dependencies

**Database**
- Supabase PostgreSQL (managed PostgreSQL service)
- Connection pooling via PgBouncer
- Direct connection for schema migrations

**File Storage**
- Filebase S3-compatible object storage
- IPFS gateway for decentralized access
- Regional endpoints for performance

**Authentication**
- NextAuth.js for OAuth and credentials flows
- JWT tokens for stateless sessions
- Secure session management

**Real-time Communication**
- Socket.IO for WebSocket connections
- Custom server implementation (server.ts)
- Separate microservice for chat (mini-services/chat-service)

**Third-party Libraries**
- React Hook Form with Zod for form validation
- Framer Motion for animations (if used)
- MDX Editor for rich text content
- Radix UI for accessible component primitives

**Development Tools**
- ESLint for code quality
- TypeScript compiler for type checking
- Prisma CLI for database operations
- tsx for TypeScript execution in development