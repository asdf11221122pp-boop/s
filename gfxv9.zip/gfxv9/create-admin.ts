import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'

const prisma = new PrismaClient()

async function createAdmin() {
  try {
    const hashedPassword = await bcrypt.hash('akash9x1', 10)
    
    const admin = await prisma.user.upsert({
      where: { email: 'kakmare.pa@gmail.com' },
      update: { 
        password: hashedPassword,
        role: 'ADMIN'
      },
      create: {
        email: 'kakmare.pa@gmail.com',
        username: 'kakmare_admin',
        password: hashedPassword,
        role: 'ADMIN',
        isActive: true
      }
    })
    
    console.log('✅ Admin user created/updated successfully!')
    console.log('📧 Email:', admin.email)
    console.log('👤 Username:', admin.username)
    console.log('🔐 Role:', admin.role)
  } catch (error) {
    console.error('❌ Error:', error)
  } finally {
    await prisma.$disconnect()
  }
}

createAdmin()
