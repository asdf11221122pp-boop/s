'use client'

import { Wrench, Clock } from 'lucide-react'

export default function MaintenancePage() {
  return (
    <div className="min-h-screen bg-[#060611] flex items-center justify-center p-4">
      <div className="text-center max-w-md">
        <div className="w-20 h-20 rounded-3xl bg-gradient-to-br from-amber-500/20 to-orange-500/20 border border-amber-500/20 flex items-center justify-center mx-auto mb-6">
          <Wrench className="w-10 h-10 text-amber-400" />
        </div>
        <h1 className="text-3xl font-bold text-white mb-3">Under Maintenance</h1>
        <p className="text-white/40 text-sm mb-6 leading-relaxed">
          We&apos;re currently performing scheduled maintenance to improve your experience. Please check back shortly.
        </p>
        <div className="inline-flex items-center gap-2 bg-white/[0.04] border border-white/[0.08] rounded-xl px-4 py-2.5">
          <Clock className="w-4 h-4 text-amber-400" />
          <span className="text-xs text-white/50">We&apos;ll be back soon</span>
        </div>
      </div>
    </div>
  )
}
