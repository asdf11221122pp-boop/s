import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Providers } from "@/components/providers";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "GfxStore - Minecraft Content Marketplace",
  description: "Discover and download the best Minecraft plugins, mods, texture packs, and more. Join the community of creators and players.",
  keywords: ["Minecraft", "plugins", "mods", "texture packs", "shaders", "maps", "marketplace"],
  authors: [{ name: "GfxStore Team" }],
  icons: {
    icon: "/favicon.ico",
  },
  openGraph: {
    title: "GfxStore - Minecraft Content Marketplace",
    description: "Discover and download the best Minecraft content",
    url: "https://gfxstore.com",
    siteName: "GfxStore",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "GfxStore - Minecraft Content Marketplace",
    description: "Discover and download the best Minecraft content",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link rel="icon" href="/favicon.ico" />
      </head>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <Providers>
          {children}
        </Providers>
      </body>
    </html>
  );
}
