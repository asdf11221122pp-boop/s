'use client'

import { useState, useEffect, useCallback } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { Suspense } from 'react'
import Link from 'next/link'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import {
  Search, Download, Star, Eye, Package, Filter, X, Grid3X3, List,
  TrendingUp, Loader2, SlidersHorizontal, ChevronDown, Heart, ShoppingCart, Zap
} from 'lucide-react'
import { useSession } from 'next-auth/react'
import { toast } from 'sonner'

interface Item {
  id: string; title: string; slug: string; shortDesc: string
  downloads: number; likes: number; views: number; price: number
  featured: boolean; status: string; logo?: string; accessType: string
  author: { id: string; username: string; avatar?: string; isVerified: boolean }
  category: { name: string; slug: string }
  _count: { reviews: number }
}

const SORT_OPTIONS = [
  { value: 'createdAt', label: 'Newest First' },
  { value: 'downloads', label: 'Most Downloaded' },
  { value: 'likes', label: 'Most Liked' },
  { value: 'views', label: 'Most Viewed' },
  { value: 'price_asc', label: 'Price: Low to High' },
  { value: 'price_desc', label: 'Price: High to Low' },
]

function ItemCard({ item, view }: { item: Item; view: 'grid' | 'list' }) {
  const { data: session } = useSession()
  const [addingCart, setAddingCart] = useState(false)

  const addToCart = async (e: React.MouseEvent) => {
    e.preventDefault()
    if (!session) { toast.error('Sign in to add to cart'); return }
    setAddingCart(true)
    try {
      const res = await fetch('/api/cart', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ itemId: item.id }) })
      const data = await res.json()
      if (res.ok) toast.success('Added to cart!')
      else toast.error(data.error || 'Failed')
    } catch { toast.error('Failed') } finally { setAddingCart(false) }
  }

  if (view === 'list') {
    return (
      <Link href={`/items/${item.slug}`}>
        <div className="group flex items-center gap-4 bg-white/[0.03] hover:bg-white/[0.06] border border-white/8 hover:border-purple-500/20 rounded-2xl p-4 transition-all duration-200">
          <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-purple-500/20 to-blue-500/10 border border-white/10 flex items-center justify-center flex-shrink-0 overflow-hidden">
            {item.logo ? <img src={item.logo} alt={item.title} className="w-full h-full object-cover" /> : <Package className="w-6 h-6 text-white/30" />}
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-3 flex-wrap">
              <div className="min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="font-semibold text-white text-sm group-hover:text-purple-300 transition-colors truncate">{item.title}</h3>
                  {item.featured && <Badge className="h-4 text-[9px] bg-yellow-500/20 text-yellow-400 border-yellow-500/30">Featured</Badge>}
                  <Badge className="h-4 text-[9px] bg-white/5 text-white/40 border-white/10">{item.category.name}</Badge>
                </div>
                <p className="text-xs text-white/40 mt-0.5 line-clamp-1">by {item.author.username} {item.author.isVerified && '✓'} · {item.shortDesc}</p>
              </div>
              <div className="flex items-center gap-3 flex-shrink-0">
                <div className="flex items-center gap-3 text-xs text-white/30">
                  <span className="flex items-center gap-1"><Download className="h-3 w-3" />{item.downloads >= 1000 ? (item.downloads / 1000).toFixed(1) + 'K' : item.downloads}</span>
                  <span className="flex items-center gap-1"><Star className="h-3 w-3 text-yellow-400" />{item._count.reviews}</span>
                </div>
                <span className={`font-bold text-sm ${item.accessType === 'FREE' ? 'text-green-400' : item.accessType === 'ROLE' ? 'text-purple-400' : 'text-white'}`}>
                  {item.accessType === 'FREE' ? 'Free' : item.accessType === 'ROLE' ? '🔒 Membership' : item.price > 0 ? `$${item.price.toFixed(2)}` : 'Free'}
                </span>
                <Button size="sm" onClick={addToCart} disabled={addingCart} className="h-8 text-xs bg-purple-500/20 hover:bg-purple-500/40 text-purple-400 border-0 rounded-lg px-3">
                  {addingCart ? <Loader2 className="h-3 w-3 animate-spin" /> : <ShoppingCart className="h-3 w-3" />}
                </Button>
              </div>
            </div>
          </div>
        </div>
      </Link>
    )
  }

  return (
    <Link href={`/items/${item.slug}`}>
      <div className="group bg-white/[0.03] hover:bg-white/[0.06] border border-white/8 hover:border-purple-500/20 rounded-2xl overflow-hidden transition-all duration-200 flex flex-col h-full">
        <div className="h-32 bg-gradient-to-br from-purple-900/20 via-blue-900/10 to-slate-900/20 flex items-center justify-center relative overflow-hidden border-b border-white/5">
          {item.logo ? (
            <img src={item.logo} alt={item.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
          ) : (
            <Package className="w-10 h-10 text-white/10" />
          )}
          <div className="absolute top-2 right-2 flex gap-1.5">
            {item.featured && <Badge className="h-5 text-[9px] bg-yellow-500/30 text-yellow-300 border-yellow-500/30 backdrop-blur-sm"><Zap className="w-2.5 h-2.5 mr-0.5" />Featured</Badge>}
            <Badge className={`h-5 text-[9px] backdrop-blur-sm ${item.accessType === 'FREE' ? 'bg-green-500/30 text-green-300 border-green-500/30' : item.accessType === 'ROLE' ? 'bg-purple-500/30 text-purple-300 border-purple-500/30' : 'bg-white/10 text-white/60 border-white/10'}`}>
              {item.accessType === 'FREE' ? 'Free' : item.accessType === 'ROLE' ? '🔒 Membership' : item.price > 0 ? `$${item.price.toFixed(2)}` : 'Free'}
            </Badge>
          </div>
        </div>
        <div className="p-4 flex-1 flex flex-col">
          <Badge className="self-start mb-2 h-4 text-[9px] bg-white/5 text-white/40 border-white/10">{item.category.name}</Badge>
          <h3 className="font-semibold text-white text-sm line-clamp-1 group-hover:text-purple-300 transition-colors mb-1">{item.title}</h3>
          <p className="text-xs text-white/40 line-clamp-2 flex-1 mb-3">{item.shortDesc}</p>
          <div className="flex items-center justify-between mt-auto">
            <div className="flex items-center gap-2 text-xs text-white/30">
              <span className="flex items-center gap-1"><Download className="h-3 w-3" />{item.downloads >= 1000 ? (item.downloads / 1000).toFixed(1) + 'K' : item.downloads}</span>
              <span className="flex items-center gap-1"><Star className="h-3 w-3 text-yellow-400 fill-yellow-400/30" />{item._count.reviews}</span>
            </div>
            <span className="text-xs text-white/40">by {item.author.username}</span>
          </div>
        </div>
      </div>
    </Link>
  )
}

function BrowseContent() {
  const { data: session } = useSession()
  const router = useRouter()
  const searchParams = useSearchParams()
  const [items, setItems] = useState<Item[]>([])
  const [categories, setCategories] = useState<any[]>([])
  const [search, setSearch] = useState(searchParams.get('q') || '')
  const [category, setCategory] = useState(searchParams.get('category') || 'all')
  const [sortBy, setSortBy] = useState('createdAt')
  const [accessType, setAccessType] = useState('all')
  const [loading, setLoading] = useState(true)
  const [view, setView] = useState<'grid' | 'list'>('grid')
  const [total, setTotal] = useState(0)
  const [showFilters, setShowFilters] = useState(false)

  useEffect(() => {
    fetchCategories()
  }, [])

  useEffect(() => {
    const timer = setTimeout(() => fetchItems(), 300)
    return () => clearTimeout(timer)
  }, [search, category, sortBy, accessType])

  const fetchCategories = async () => {
    try {
      const res = await fetch('/api/categories')
      if (res.ok) {
        const data = await res.json()
        setCategories(Array.isArray(data) ? data : data.categories || [])
      }
    } catch {}
  }

  const fetchItems = async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams({ status: 'APPROVED', limit: '48' })
      if (search) params.set('search', search)
      if (category && category !== 'all') params.set('category', category)
      if (accessType !== 'all') params.set('accessType', accessType)
      if (sortBy === 'price_asc') { params.set('sortBy', 'price'); params.set('order', 'asc') }
      else if (sortBy === 'price_desc') { params.set('sortBy', 'price'); params.set('order', 'desc') }
      else params.set('sortBy', sortBy)

      const res = await fetch(`/api/items?${params}`)
      if (res.ok) {
        const data = await res.json()
        setItems(data.items || [])
        setTotal(data.total || data.items?.length || 0)
      }
    } catch {} finally { setLoading(false) }
  }

  const clearFilters = () => { setSearch(''); setCategory('all'); setSortBy('createdAt'); setAccessType('all') }
  const hasFilters = search || category !== 'all' || sortBy !== 'createdAt' || accessType !== 'all'

  return (
    <div className="min-h-screen bg-[#0a0a0f]">
      <Navbar />

      {/* Header */}
      <div className="border-b border-white/5 bg-[#0f0f1a]/50 backdrop-blur-sm sticky top-[57px] z-30">
        <div className="container mx-auto px-4 py-3 max-w-7xl">
          <div className="flex items-center gap-3 flex-wrap">
            {/* Search */}
            <div className="relative flex-1 min-w-[180px]">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/30" />
              <Input
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="Search content..."
                className="pl-9 h-9 bg-white/5 border-white/10 text-white placeholder:text-white/30 rounded-xl text-sm focus:border-purple-500/50"
              />
              {search && <button onClick={() => setSearch('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-white/30 hover:text-white/70"><X className="h-3.5 w-3.5" /></button>}
            </div>

            {/* Category */}
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger className="w-36 h-9 bg-white/5 border-white/10 text-white rounded-xl text-sm">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent className="bg-[#0f0f1a] border-white/10">
                <SelectItem value="all" className="text-white/80">All Categories</SelectItem>
                {categories.map(c => <SelectItem key={c.id} value={c.slug} className="text-white/80">{c.name}</SelectItem>)}
              </SelectContent>
            </Select>

            {/* Access Type */}
            <Select value={accessType} onValueChange={setAccessType}>
              <SelectTrigger className="w-28 h-9 bg-white/5 border-white/10 text-white rounded-xl text-sm">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-[#0f0f1a] border-white/10">
                <SelectItem value="all" className="text-white/80">All</SelectItem>
                <SelectItem value="FREE" className="text-white/80">Free</SelectItem>
                <SelectItem value="PAID" className="text-white/80">Paid</SelectItem>
              </SelectContent>
            </Select>

            {/* Sort */}
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-44 h-9 bg-white/5 border-white/10 text-white rounded-xl text-sm">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-[#0f0f1a] border-white/10">
                {SORT_OPTIONS.map(o => <SelectItem key={o.value} value={o.value} className="text-white/80">{o.label}</SelectItem>)}
              </SelectContent>
            </Select>

            {hasFilters && (
              <Button onClick={clearFilters} size="sm" variant="ghost" className="h-9 text-xs text-white/50 hover:text-white hover:bg-white/5 rounded-xl gap-1.5 flex-shrink-0">
                <X className="h-3.5 w-3.5" />Clear
              </Button>
            )}

            <div className="flex items-center gap-1 ml-auto flex-shrink-0">
              <Button size="sm" variant="ghost" onClick={() => setView('grid')} className={`h-9 w-9 p-0 rounded-xl ${view === 'grid' ? 'bg-purple-500/20 text-purple-400' : 'text-white/30 hover:text-white/60'}`}><Grid3X3 className="h-4 w-4" /></Button>
              <Button size="sm" variant="ghost" onClick={() => setView('list')} className={`h-9 w-9 p-0 rounded-xl ${view === 'list' ? 'bg-purple-500/20 text-purple-400' : 'text-white/30 hover:text-white/60'}`}><List className="h-4 w-4" /></Button>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8 max-w-7xl">
        {/* Results header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <p className="text-white/60 text-sm">
              {loading ? 'Searching...' : <><span className="text-white font-semibold">{items.length}</span> results{search ? ` for "${search}"` : ''}</>}
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            {categories.slice(0, 5).map(c => (
              <button key={c.id} onClick={() => setCategory(c.slug === category ? 'all' : c.slug)}
                className={`text-xs px-3 py-1.5 rounded-lg border transition-all ${c.slug === category ? 'bg-purple-500/20 text-purple-300 border-purple-500/30' : 'bg-white/5 text-white/40 border-white/10 hover:border-white/20 hover:text-white/60'}`}>
                {c.name}
              </button>
            ))}
          </div>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-24">
            <div className="text-center">
              <Loader2 className="w-8 h-8 animate-spin text-purple-400 mx-auto mb-3" />
              <p className="text-white/30 text-sm">Loading content...</p>
            </div>
          </div>
        ) : items.length === 0 ? (
          <div className="text-center py-24">
            <Package className="w-16 h-16 mx-auto text-white/10 mb-4" />
            <h3 className="text-white text-lg font-semibold mb-2">No items found</h3>
            <p className="text-white/40 text-sm mb-6">Try adjusting your search or filters</p>
            <Button onClick={clearFilters} className="bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl">Clear Filters</Button>
          </div>
        ) : (
          <div className={view === 'grid' ? 'grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4' : 'space-y-3'}>
            {items.map(item => <ItemCard key={item.id} item={item} view={view} />)}
          </div>
        )}
      </div>

      <Footer />
    </div>
  )
}

export default function BrowsePage() {
  return <Suspense fallback={<div className="min-h-screen bg-[#0a0a0f] flex items-center justify-center"><Loader2 className="w-8 h-8 animate-spin text-purple-400" /></div>}><BrowseContent /></Suspense>
}
