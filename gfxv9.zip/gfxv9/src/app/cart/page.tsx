'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { ShoppingCart, Package, Trash2, Loader2, Wallet, CreditCard, Tag, X, CheckCircle, ArrowRight } from 'lucide-react'
import { toast } from 'sonner'

interface CartItemData {
  id: string; quantity: number
  item: { id: string; title: string; slug: string; logo?: string; price: number; accessType: string; author: { username: string } }
}

export default function CartPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [cart, setCart] = useState<CartItemData[]>([])
  const [total, setTotal] = useState(0)
  const [loading, setLoading] = useState(true)
  const [removing, setRemoving] = useState<string | null>(null)
  const [checkingOut, setCheckingOut] = useState(false)
  const [couponCode, setCouponCode] = useState('')
  const [validatingCoupon, setValidatingCoupon] = useState(false)
  const [couponResult, setCouponResult] = useState<{ valid: boolean; discountAmount: number; finalAmount: number; coupon: { code: string; discountValue: number; discountType: string } } | null>(null)
  const [checkoutSuccess, setCheckoutSuccess] = useState(false)

  useEffect(() => {
    if (status === 'unauthenticated') router.push('/auth/signin')
    if (status === 'authenticated') fetchCart()
  }, [status])

  const fetchCart = async () => {
    try {
      const res = await fetch('/api/cart')
      if (res.ok) { const data = await res.json(); setCart(data.cart || []); setTotal(data.total || 0) }
    } catch {} finally { setLoading(false) }
  }

  const removeItem = async (itemId: string) => {
    setRemoving(itemId)
    try {
      const res = await fetch('/api/cart', { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ itemId }) })
      if (res.ok) {
        const removed = cart.find(c => c.item.id === itemId)
        setCart(prev => prev.filter(c => c.item.id !== itemId))
        if (removed) setTotal(prev => prev - removed.item.price * removed.quantity)
        setCouponResult(null)
        toast.success('Removed from cart')
      }
    } catch { toast.error('Failed to remove') } finally { setRemoving(null) }
  }

  const clearCart = async () => {
    try {
      await fetch('/api/cart', { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({}) })
      setCart([]); setTotal(0); setCouponResult(null); toast.success('Cart cleared')
    } catch { toast.error('Failed to clear cart') }
  }

  const validateCoupon = async () => {
    if (!couponCode.trim()) { toast.error('Enter a coupon code'); return }
    setValidatingCoupon(true)
    try {
      const res = await fetch('/api/coupons/validate', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code: couponCode.trim(), orderAmount: total })
      })
      const data = await res.json()
      if (res.ok && data.valid) {
        setCouponResult(data)
        toast.success(`Coupon applied! You save $${data.discountAmount.toFixed(2)}`)
      } else {
        toast.error(data.error || 'Invalid coupon')
        setCouponResult(null)
      }
    } catch { toast.error('Failed to validate coupon') } finally { setValidatingCoupon(false) }
  }

  const removeCoupon = () => { setCouponResult(null); setCouponCode('') }

  const handleCheckout = async () => {
    if (cart.length === 0) return
    setCheckingOut(true)
    try {
      const results = await Promise.all(
        cart.map(c => fetch('/api/orders', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ itemId: c.item.id, couponCode: couponResult ? couponCode : undefined })
        }))
      )
      const allOk = results.every(r => r.ok)
      if (allOk) {
        // Clear cart
        await fetch('/api/cart', { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({}) })
        setCheckoutSuccess(true)
        toast.success('Order placed successfully!')
      } else {
        const failedData = await results.find(r => !r.ok)?.json()
        // If wallet balance is insufficient, send user to payment page.
        if (failedData?.error === 'Insufficient wallet balance') {
          router.push('/payment')
          toast.error('Wallet balance is low. Please add funds to continue.')
          return
        }
        toast.error(failedData?.error || 'Checkout failed for some items')
      }
    } catch { toast.error('Checkout failed') } finally { setCheckingOut(false) }
  }

  const finalTotal = couponResult ? couponResult.finalAmount : total

  if (checkoutSuccess) {
    return (
      <div className="min-h-screen bg-[#0a0a0f]">
        <Navbar />
        <div className="container mx-auto px-4 py-20 max-w-lg text-center">
          <div className="w-20 h-20 rounded-full bg-green-500/20 flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="w-10 h-10 text-green-400" />
          </div>
          <h1 className="text-2xl font-bold text-white mb-2">Order Placed!</h1>
          <p className="text-white/50 mb-8">Your purchase is complete. Check your orders for download links.</p>
          <div className="flex flex-col gap-3 max-w-xs mx-auto">
            <Link href="/orders"><Button className="w-full bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl h-11 gap-2">View Orders <ArrowRight className="w-4 h-4" /></Button></Link>
            <Link href="/browse"><Button variant="ghost" className="w-full text-white/50 hover:bg-white/5 rounded-xl h-11">Continue Browsing</Button></Link>
          </div>
        </div>
        <Footer />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-[#0a0a0f]">
      <Navbar />
      <div className="container mx-auto px-4 py-12 max-w-5xl">
        <div className="flex items-center justify-between mb-8">
          <div>
            <div className="flex items-center gap-2 mb-1"><ShoppingCart className="h-5 w-5 text-blue-400" /><span className="text-sm font-medium text-blue-400 uppercase tracking-wider">Shopping</span></div>
            <h1 className="text-3xl font-bold text-white">My Cart</h1>
            <p className="text-white/40 mt-1">{cart.length} item{cart.length !== 1 ? 's' : ''}</p>
          </div>
          {cart.length > 0 && (
            <Button variant="ghost" onClick={clearCart} className="text-red-400 hover:text-red-300 hover:bg-red-500/10 gap-2 text-sm rounded-xl">
              <Trash2 className="h-4 w-4" />Clear Cart
            </Button>
          )}
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-20"><Loader2 className="w-8 h-8 animate-spin text-purple-400" /></div>
        ) : cart.length === 0 ? (
          <div className="text-center py-20">
            <ShoppingCart className="w-16 h-16 mx-auto text-white/10 mb-4" />
            <h2 className="text-xl font-semibold text-white mb-2">Your cart is empty</h2>
            <p className="text-white/40 mb-6">Add items to your cart to purchase them</p>
            <Link href="/browse"><Button className="bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl"><Package className="mr-2 h-4 w-4" />Browse Content</Button></Link>
          </div>
        ) : (
          <div className="grid lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-3">
              {cart.map(c => (
                <div key={c.id} className="bg-white/[0.03] border border-white/8 rounded-2xl p-4 flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500/20 to-blue-500/20 border border-white/10 flex items-center justify-center flex-shrink-0 overflow-hidden">
                    {c.item.logo ? <img src={c.item.logo} alt={c.item.title} className="w-full h-full object-cover" /> : <Package className="w-5 h-5 text-white/30" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <Link href={`/items/${c.item.slug}`} className="font-semibold text-white text-sm line-clamp-1 hover:text-purple-300 transition-colors">{c.item.title}</Link>
                    <p className="text-xs text-white/40">by {c.item.author?.username}</p>
                    {c.item.accessType === 'FREE' && <Badge className="mt-1 bg-green-500/10 text-green-400 border-green-500/20 text-[9px]">FREE</Badge>}
                  </div>
                  <div className="flex items-center gap-3 flex-shrink-0">
                    <span className="text-green-400 font-bold">{c.item.price === 0 ? 'Free' : `$${c.item.price.toFixed(2)}`}</span>
                    <Button size="sm" variant="ghost" onClick={() => removeItem(c.item.id)} disabled={removing === c.item.id} className="h-8 w-8 text-red-400 hover:bg-red-500/10 rounded-lg p-0">
                      {removing === c.item.id ? <Loader2 className="h-3 w-3 animate-spin" /> : <Trash2 className="h-3 w-3" />}
                    </Button>
                  </div>
                </div>
              ))}
            </div>

            <div className="lg:col-span-1">
              <div className="bg-white/[0.03] border border-white/8 rounded-2xl p-6 sticky top-20 space-y-5">
                <h2 className="text-lg font-semibold text-white">Order Summary</h2>

                {/* Coupon */}
                {couponResult ? (
                  <div className="flex items-center justify-between bg-green-500/10 border border-green-500/20 rounded-xl px-3 py-2">
                    <div className="flex items-center gap-2">
                      <Tag className="h-3.5 w-3.5 text-green-400" />
                      <span className="text-green-400 font-mono text-sm font-semibold">{couponResult.coupon.code}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-green-400 text-sm">-${couponResult.discountAmount.toFixed(2)}</span>
                      <button onClick={removeCoupon} className="text-white/30 hover:text-white/70"><X className="h-3.5 w-3.5" /></button>
                    </div>
                  </div>
                ) : (
                  <div className="flex gap-2">
                    <Input
                      value={couponCode}
                      onChange={e => setCouponCode(e.target.value.toUpperCase())}
                      onKeyDown={e => e.key === 'Enter' && validateCoupon()}
                      placeholder="Coupon code"
                      className="h-9 bg-white/5 border-white/10 text-white placeholder:text-white/30 rounded-xl text-sm font-mono"
                    />
                    <Button onClick={validateCoupon} disabled={validatingCoupon} size="sm" className="h-9 bg-purple-500/20 hover:bg-purple-500/40 text-purple-400 border-0 rounded-xl px-3 flex-shrink-0">
                      {validatingCoupon ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Tag className="h-3.5 w-3.5" />}
                    </Button>
                  </div>
                )}

                <div className="space-y-2 border-t border-white/10 pt-4">
                  <div className="flex justify-between text-sm text-white/60"><span>Subtotal</span><span>${total.toFixed(2)}</span></div>
                  {couponResult && (
                    <div className="flex justify-between text-sm text-green-400"><span>Discount</span><span>-${couponResult.discountAmount.toFixed(2)}</span></div>
                  )}
                  <div className="flex justify-between font-bold text-white border-t border-white/10 pt-2">
                    <span>Total</span>
                    <span className="text-green-400 text-lg">${finalTotal.toFixed(2)}</span>
                  </div>
                </div>

                <Button onClick={handleCheckout} disabled={checkingOut || cart.length === 0} className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 text-white border-0 rounded-xl shadow-lg shadow-purple-500/25 h-11">
                  {checkingOut ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <CreditCard className="w-4 h-4 mr-2" />}
                  {checkingOut ? 'Processing...' : 'Place Order'}
                </Button>
                <div className="flex items-center gap-2 text-xs text-white/30 justify-center">
                  <Wallet className="h-3.5 w-3.5" />Powered by GfxStore Wallet
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
      <Footer />
    </div>
  )
}
