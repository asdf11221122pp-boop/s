'use client'

import { useEffect, useState, useCallback } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Loader2, Users2, Plus, Trash2, UserPlus, Crown, Shield, LogOut, X, Check, Bell, Settings, UserMinus, ChevronDown } from 'lucide-react'
import { toast } from 'sonner'

type Member = { id: string; role: string; user: { id: string; username: string; avatar?: string; isVerified?: boolean } }
type Team = {
  id: string; name: string; description?: string; avatar?: string; ownerId: string
  owner?: { id: string; username: string; avatar?: string }
  members?: Member[]
  invites?: Array<{ id: string; invitee: { id: string; username: string; avatar?: string }; inviter: { id: string; username: string } }>
}
type PendingInvite = {
  id: string; status: string
  team: { id: string; name: string; description?: string; owner: { id: string; username: string; avatar?: string }; members: { userId: string }[] }
  inviter: { id: string; username: string; avatar?: string }
}

const ROLE_COLORS: Record<string, string> = {
  OWNER: 'bg-yellow-500/15 text-yellow-300 border-yellow-500/20',
  MODERATOR: 'bg-blue-500/15 text-blue-300 border-blue-500/20',
  MEMBER: 'bg-white/5 text-white/50 border-white/10'
}

export default function TeamsPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [ownedTeams, setOwnedTeams] = useState<Team[]>([])
  const [memberTeams, setMemberTeams] = useState<Team[]>([])
  const [pendingInvites, setPendingInvites] = useState<PendingInvite[]>([])
  const [selectedTeam, setSelectedTeam] = useState<Team | null>(null)
  const [inviteUsername, setInviteUsername] = useState('')
  const [loading, setLoading] = useState(true)
  const [creating, setCreating] = useState(false)
  const [inviting, setInviting] = useState(false)
  const [showCreateForm, setShowCreateForm] = useState(false)
  const [editingTeam, setEditingTeam] = useState(false)
  const [formData, setFormData] = useState({ name: '', description: '' })
  const [editForm, setEditForm] = useState({ name: '', description: '' })
  const [processingInvite, setProcessingInvite] = useState<string | null>(null)
  const [tab, setTab] = useState<'mine' | 'joined' | 'invites'>('mine')

  useEffect(() => {
    if (status === 'unauthenticated') router.push('/auth/signin')
  }, [status, router])

  const loadAll = useCallback(async () => {
    if (status !== 'authenticated') return
    setLoading(true)
    try {
      const [teamsRes, invitesRes] = await Promise.all([
        fetch('/api/teams'),
        fetch('/api/teams/invites')
      ])
      if (teamsRes.ok) {
        const data = await teamsRes.json()
        setOwnedTeams(data.ownedTeams || [])
        setMemberTeams((data.memberTeams || []).map((m: any) => m.team || m))
      }
      if (invitesRes.ok) {
        const data = await invitesRes.json()
        setPendingInvites(data.invites || [])
      }
    } catch { toast.error('Failed to load teams') }
    finally { setLoading(false) }
  }, [status])

  useEffect(() => { loadAll() }, [loadAll])

  const loadTeamDetail = async (teamId: string) => {
    const res = await fetch(`/api/teams/${teamId}`)
    if (res.ok) {
      const data = await res.json()
      setSelectedTeam(data.team)
      setEditForm({ name: data.team.name, description: data.team.description || '' })
    }
  }

  const createTeam = async () => {
    if (!formData.name.trim()) { toast.error('Team name required'); return }
    setCreating(true)
    try {
      const res = await fetch('/api/teams', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: formData.name, description: formData.description })
      })
      if (res.ok) {
        const data = await res.json()
        setOwnedTeams(prev => [data.team, ...prev])
        setFormData({ name: '', description: '' })
        setShowCreateForm(false)
        toast.success('Team created!')
        await loadTeamDetail(data.team.id)
        setTab('mine')
      } else {
        const err = await res.json().catch(() => ({}))
        toast.error(err.error || 'Failed to create team')
      }
    } catch { toast.error('Failed to create team') }
    finally { setCreating(false) }
  }

  const sendInvite = async () => {
    if (!selectedTeam || !inviteUsername.trim()) { toast.error('Enter a username'); return }
    setInviting(true)
    try {
      const res = await fetch(`/api/teams/${selectedTeam.id}/invite`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: inviteUsername.trim() })
      })
      const data = await res.json()
      if (res.ok) {
        toast.success(data.message || 'Invite sent!')
        setInviteUsername('')
        await loadTeamDetail(selectedTeam.id)
      } else {
        toast.error(data.error || 'Failed to send invite')
      }
    } catch { toast.error('Failed to send invite') }
    finally { setInviting(false) }
  }

  const handleInvite = async (inviteId: string, action: 'accept' | 'reject') => {
    setProcessingInvite(inviteId)
    try {
      const res = await fetch('/api/teams/invites', {
        method: 'PATCH', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ inviteId, action })
      })
      const data = await res.json()
      if (res.ok) {
        toast.success(data.message)
        await loadAll()
      } else {
        toast.error(data.error || 'Failed')
      }
    } catch { toast.error('Failed to process invite') }
    finally { setProcessingInvite(null) }
  }

  const teamAction = async (action: string, extra?: any) => {
    if (!selectedTeam) return
    try {
      const res = await fetch(`/api/teams/${selectedTeam.id}`, {
        method: action === 'disband' ? 'DELETE' : 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: action === 'disband' ? undefined : JSON.stringify({ action, ...extra })
      })
      const data = await res.json()
      if (res.ok) {
        toast.success(data.message || 'Done')
        if (action === 'leave' || action === 'disband') {
          setSelectedTeam(null)
          await loadAll()
        } else {
          await loadTeamDetail(selectedTeam.id)
          await loadAll()
        }
      } else {
        toast.error(data.error || 'Action failed')
      }
    } catch { toast.error('Action failed') }
  }

  const saveTeamEdit = async () => {
    if (!selectedTeam) return
    try {
      const res = await fetch(`/api/teams/${selectedTeam.id}`, {
        method: 'PATCH', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: editForm.name, description: editForm.description })
      })
      if (res.ok) {
        toast.success('Team updated')
        setEditingTeam(false)
        await loadTeamDetail(selectedTeam.id)
        await loadAll()
      }
    } catch { toast.error('Failed to update team') }
  }

  const cancelPendingInvite = async (inviteeId: string) => {
    if (!selectedTeam) return
    await fetch(`/api/teams/${selectedTeam.id}/invite`, {
      method: 'DELETE', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ inviteeId })
    })
    await loadTeamDetail(selectedTeam.id)
    toast.success('Invite cancelled')
  }

  const isOwner = (team: Team) => team.ownerId === session?.user?.id
  const myRole = (team: Team) => team.members?.find(m => m.user.id === session?.user?.id)?.role || 'MEMBER'

  if (status === 'loading' || loading) {
    return <div className="min-h-screen bg-[#0a0a0f] flex items-center justify-center"><Loader2 className="w-8 h-8 animate-spin text-purple-400" /></div>
  }

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white">
      <Navbar />
      <div className="container mx-auto px-4 py-10 max-w-6xl">
        <div className="flex items-center justify-between mb-8">
          <div>
            <div className="flex items-center gap-3 mb-1">
              <Users2 className="w-6 h-6 text-purple-400" />
              <h1 className="text-3xl font-bold">Teams</h1>
            </div>
            <p className="text-white/40 text-sm">Collaborate professionally with your team</p>
          </div>
          <div className="flex items-center gap-2">
            {pendingInvites.length > 0 && (
              <Button onClick={() => setTab('invites')} variant="outline" className="border-yellow-500/30 text-yellow-300 bg-yellow-500/10 hover:bg-yellow-500/20 gap-2 text-sm">
                <Bell className="w-4 h-4" />
                {pendingInvites.length} Invite{pendingInvites.length > 1 ? 's' : ''}
              </Button>
            )}
            <Button onClick={() => setShowCreateForm(true)} className="bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 gap-2">
              <Plus className="w-4 h-4" /> New Team
            </Button>
          </div>
        </div>

        {showCreateForm && (
          <div className="bg-white/[0.03] border border-purple-500/20 rounded-2xl p-6 mb-6">
            <h2 className="text-lg font-semibold mb-4">Create New Team</h2>
            <div className="space-y-4">
              <div>
                <label className="text-sm text-white/60 mb-1 block">Team Name *</label>
                <Input value={formData.name} onChange={e => setFormData(p => ({ ...p, name: e.target.value }))}
                  placeholder="e.g. GFX Builders" className="bg-white/[0.04] border-white/8 text-white" />
              </div>
              <div>
                <label className="text-sm text-white/60 mb-1 block">Description</label>
                <Textarea value={formData.description} onChange={e => setFormData(p => ({ ...p, description: e.target.value }))}
                  placeholder="What does your team do?" rows={2} className="bg-white/[0.04] border-white/8 text-white resize-none" />
              </div>
              <div className="flex gap-2 justify-end">
                <Button variant="ghost" onClick={() => setShowCreateForm(false)} className="text-white/60">Cancel</Button>
                <Button onClick={createTeam} disabled={creating} className="bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0">
                  {creating ? <><Loader2 className="w-4 h-4 animate-spin mr-2" />Creating...</> : 'Create Team'}
                </Button>
              </div>
            </div>
          </div>
        )}

        <div className="flex gap-1 mb-6 bg-white/[0.03] p-1 rounded-xl border border-white/8 w-fit">
          {(['mine', 'joined', 'invites'] as const).map(t => (
            <button key={t} onClick={() => setTab(t)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all capitalize relative ${tab === t ? 'bg-purple-600 text-white' : 'text-white/50 hover:text-white'}`}>
              {t === 'invites' ? 'Invites' : t === 'mine' ? 'My Teams' : 'Joined'}
              {t === 'invites' && pendingInvites.length > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-yellow-500 text-black text-[9px] font-bold rounded-full flex items-center justify-center">{pendingInvites.length}</span>
              )}
            </button>
          ))}
        </div>

        {tab === 'invites' && (
          <div className="space-y-3">
            {pendingInvites.length === 0 ? (
              <div className="text-center py-12 text-white/30">
                <Bell className="w-10 h-10 mx-auto mb-3 opacity-20" />
                <p>No pending invites</p>
              </div>
            ) : pendingInvites.map(invite => (
              <div key={invite.id} className="bg-white/[0.03] border border-white/8 rounded-xl p-5 flex items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-600/30 to-blue-600/30 flex items-center justify-center border border-white/10">
                    <Users2 className="w-5 h-5 text-purple-300" />
                  </div>
                  <div>
                    <p className="font-semibold text-white">{invite.team.name}</p>
                    <p className="text-sm text-white/40">Invited by @{invite.inviter.username} · {invite.team.members.length} members</p>
                    {invite.team.description && <p className="text-xs text-white/30 mt-0.5">{invite.team.description}</p>}
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button size="sm" onClick={() => handleInvite(invite.id, 'reject')} disabled={processingInvite === invite.id}
                    variant="ghost" className="text-red-400 hover:text-red-300 hover:bg-red-500/10 border border-red-500/20">
                    <X className="w-4 h-4" />
                  </Button>
                  <Button size="sm" onClick={() => handleInvite(invite.id, 'accept')} disabled={processingInvite === invite.id}
                    className="bg-green-600 hover:bg-green-500 text-white border-0 gap-1.5">
                    {processingInvite === invite.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <><Check className="w-4 h-4" />Accept</>}
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}

        {tab === 'mine' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="space-y-3">
              {ownedTeams.length === 0 && (
                <div className="text-center py-12 text-white/30">
                  <Users2 className="w-10 h-10 mx-auto mb-3 opacity-20" />
                  <p>No teams yet</p>
                  <Button onClick={() => setShowCreateForm(true)} size="sm" className="mt-3 bg-purple-600 text-white border-0">Create Team</Button>
                </div>
              )}
              {ownedTeams.map(team => (
                <div key={team.id} onClick={() => loadTeamDetail(team.id)}
                  className={`bg-white/[0.03] border rounded-xl p-5 cursor-pointer transition-all hover:bg-white/[0.05] ${selectedTeam?.id === team.id ? 'border-purple-500/40 bg-purple-500/5' : 'border-white/8'}`}>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-purple-600/40 to-blue-600/40 flex items-center justify-center border border-white/10 text-lg">
                        {team.name[0].toUpperCase()}
                      </div>
                      <div>
                        <p className="font-semibold text-white">{team.name}</p>
                        <div className="flex items-center gap-1.5">
                          <Crown className="w-3 h-3 text-yellow-400" />
                          <span className="text-[11px] text-yellow-400">Owner</span>
                          <span className="text-[11px] text-white/30">· {team.members?.length || 0} members</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  {team.description && <p className="text-xs text-white/40 ml-[52px]">{team.description}</p>}
                  {(team.members?.length || 0) > 0 && (
                    <div className="flex -space-x-2 mt-3 ml-[52px]">
                      {team.members?.slice(0, 5).map(m => (
                        <Avatar key={m.id} className="w-6 h-6 border-2 border-[#0a0a0f]">
                          <AvatarImage src={m.user.avatar} />
                          <AvatarFallback className="bg-purple-600/30 text-purple-300 text-[9px]">{m.user.username[0].toUpperCase()}</AvatarFallback>
                        </Avatar>
                      ))}
                      {(team.members?.length || 0) > 5 && <div className="w-6 h-6 rounded-full bg-white/10 border-2 border-[#0a0a0f] flex items-center justify-center text-[9px] text-white/50">+{(team.members?.length || 0) - 5}</div>}
                    </div>
                  )}
                </div>
              ))}
            </div>

            {selectedTeam && isOwner(selectedTeam) && (
              <div className="bg-white/[0.03] border border-white/8 rounded-xl p-5 h-fit">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold text-white flex items-center gap-2"><Settings className="w-4 h-4 text-purple-400" /> Manage Team</h3>
                  <Button size="sm" variant="ghost" onClick={() => setSelectedTeam(null)} className="text-white/40 h-7 w-7 p-0"><X className="w-4 h-4" /></Button>
                </div>

                {!editingTeam ? (
                  <div className="mb-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium text-white">{selectedTeam.name}</p>
                        {selectedTeam.description && <p className="text-xs text-white/40">{selectedTeam.description}</p>}
                      </div>
                      <Button size="sm" variant="ghost" onClick={() => setEditingTeam(true)} className="text-purple-300 text-xs">Edit</Button>
                    </div>
                  </div>
                ) : (
                  <div className="mb-4 space-y-2">
                    <Input value={editForm.name} onChange={e => setEditForm(p => ({ ...p, name: e.target.value }))} className="bg-white/[0.04] border-white/8 text-white text-sm h-8" />
                    <Textarea value={editForm.description} onChange={e => setEditForm(p => ({ ...p, description: e.target.value }))} rows={2} className="bg-white/[0.04] border-white/8 text-white text-sm resize-none" />
                    <div className="flex gap-2">
                      <Button size="sm" onClick={saveTeamEdit} className="bg-purple-600 text-white border-0 h-7 text-xs">Save</Button>
                      <Button size="sm" variant="ghost" onClick={() => setEditingTeam(false)} className="text-white/40 h-7 text-xs">Cancel</Button>
                    </div>
                  </div>
                )}

                <div className="mb-4">
                  <p className="text-xs text-white/40 mb-2">Invite by Username</p>
                  <div className="flex gap-2">
                    <Input value={inviteUsername} onChange={e => setInviteUsername(e.target.value)}
                      onKeyDown={e => { if (e.key === 'Enter') sendInvite() }}
                      placeholder="@username" className="bg-white/[0.04] border-white/8 text-white text-sm h-8" />
                    <Button size="sm" onClick={sendInvite} disabled={inviting} className="bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 h-8 px-3">
                      {inviting ? <Loader2 className="w-3 h-3 animate-spin" /> : <UserPlus className="w-3 h-3" />}
                    </Button>
                  </div>
                </div>

                {selectedTeam.invites && selectedTeam.invites.length > 0 && (
                  <div className="mb-4">
                    <p className="text-xs text-white/40 mb-2">Pending Invites ({selectedTeam.invites.length})</p>
                    <div className="space-y-1.5">
                      {selectedTeam.invites.map(inv => (
                        <div key={inv.id} className="flex items-center justify-between bg-yellow-500/5 border border-yellow-500/15 rounded-lg px-3 py-2">
                          <div className="flex items-center gap-2">
                            <Avatar className="w-6 h-6"><AvatarImage src={inv.invitee.avatar} /><AvatarFallback className="text-[9px]">{inv.invitee.username[0]}</AvatarFallback></Avatar>
                            <span className="text-xs text-white/70">@{inv.invitee.username}</span>
                            <span className="text-[10px] text-yellow-400/60">Pending</span>
                          </div>
                          <button onClick={() => cancelPendingInvite(inv.invitee.id)} className="text-white/30 hover:text-red-400 transition-colors"><X className="w-3 h-3" /></button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                <div>
                  <p className="text-xs text-white/40 mb-2">Members ({selectedTeam.members?.length || 0})</p>
                  <div className="space-y-1.5 max-h-60 overflow-y-auto">
                    {selectedTeam.members?.map(member => (
                      <div key={member.id} className="flex items-center justify-between bg-white/[0.02] rounded-lg px-3 py-2">
                        <div className="flex items-center gap-2">
                          <Avatar className="w-6 h-6"><AvatarImage src={member.user.avatar} /><AvatarFallback className="text-[9px]">{member.user.username[0]}</AvatarFallback></Avatar>
                          <span className="text-xs text-white/80">@{member.user.username}</span>
                          <Badge className={`text-[9px] px-1.5 py-0 ${ROLE_COLORS[member.role] || ROLE_COLORS.MEMBER}`}>{member.role}</Badge>
                        </div>
                        {member.user.id !== session?.user?.id && (
                          <div className="flex gap-1">
                            {member.role !== 'MODERATOR' && (
                              <button onClick={() => teamAction('changeRole', { userId: member.user.id, role: 'MODERATOR' })}
                                className="text-blue-400/60 hover:text-blue-300 transition-colors text-[10px] px-1.5 py-0.5 rounded bg-blue-500/10 hover:bg-blue-500/20">
                                <Shield className="w-3 h-3" />
                              </button>
                            )}
                            {member.role === 'MODERATOR' && (
                              <button onClick={() => teamAction('changeRole', { userId: member.user.id, role: 'MEMBER' })}
                                className="text-white/40 hover:text-white/70 transition-colors text-[10px] px-1.5 py-0.5 rounded bg-white/5">
                                <ChevronDown className="w-3 h-3" />
                              </button>
                            )}
                            <button onClick={() => { if (confirm('Remove this member?')) teamAction('kick', { userId: member.user.id }) }}
                              className="text-red-400/60 hover:text-red-300 transition-colors px-1.5 py-0.5 rounded bg-red-500/5 hover:bg-red-500/10">
                              <UserMinus className="w-3 h-3" />
                            </button>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                <div className="pt-4 mt-4 border-t border-white/5">
                  <button onClick={() => { if (confirm('Disband this team? This cannot be undone.')) teamAction('disband') }}
                    className="text-xs text-red-400/60 hover:text-red-300 transition-colors flex items-center gap-1">
                    <Trash2 className="w-3.5 h-3.5" /> Disband Team
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {tab === 'joined' && (
          <div className="space-y-3">
            {memberTeams.length === 0 && (
              <div className="text-center py-12 text-white/30">
                <Users2 className="w-10 h-10 mx-auto mb-3 opacity-20" />
                <p>You haven't joined any teams</p>
                <p className="text-sm mt-1">Accept an invite to join a team</p>
              </div>
            )}
            {memberTeams.map(team => (
              <div key={team.id} className="bg-white/[0.03] border border-white/8 rounded-xl p-5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-600/40 to-cyan-600/40 flex items-center justify-center border border-white/10 text-lg">
                      {team.name[0].toUpperCase()}
                    </div>
                    <div>
                      <p className="font-semibold text-white">{team.name}</p>
                      <div className="flex items-center gap-1.5">
                        <Badge className={`text-[9px] px-1.5 py-0 ${ROLE_COLORS[myRole(team)] || ROLE_COLORS.MEMBER}`}>{myRole(team)}</Badge>
                        <span className="text-[11px] text-white/30">Owner: @{team.owner?.username}</span>
                        <span className="text-[11px] text-white/30">· {team.members?.length || 0} members</span>
                      </div>
                    </div>
                  </div>
                  <button onClick={() => { if (confirm('Leave this team?')) { setSelectedTeam(team); teamAction('leave') } }}
                    className="text-xs text-red-400/60 hover:text-red-300 flex items-center gap-1 transition-colors">
                    <LogOut className="w-3.5 h-3.5" /> Leave
                  </button>
                </div>
                {team.description && <p className="text-xs text-white/40 mt-2 ml-[52px]">{team.description}</p>}
                {(team.members?.length || 0) > 0 && (
                  <div className="flex -space-x-2 mt-3 ml-[52px]">
                    {team.members?.slice(0, 6).map(m => (
                      <Avatar key={m.id} className="w-6 h-6 border-2 border-[#0a0a0f]">
                        <AvatarImage src={m.user.avatar} />
                        <AvatarFallback className="bg-blue-600/30 text-blue-300 text-[9px]">{m.user.username[0].toUpperCase()}</AvatarFallback>
                      </Avatar>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
      <Footer />
    </div>
  )
}
