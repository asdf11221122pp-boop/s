'use client'

import { useState, useEffect } from 'react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { ChatWidget } from '@/components/chat/chat-widget'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import {
  Download, Star, Users, Package, Search, Upload, Shield,
  MessageSquare, TrendingUp, Sparkles, Zap, Globe, ArrowRight,
  Check, Server, Heart, ShoppingCart, Play, Gift, Crown, Award, Users2, CalendarDays
} from 'lucide-react'
import Link from 'next/link'

interface Stats { totalUsers: number; totalItems: number; totalDownloads: number }
interface FeaturedItem {
  id: string; title: string; slug: string; shortDesc?: string
  downloads: number; likes: number; logo?: string; accessType?: string
  category: { name: string }; author: { username: string; avatar?: string }
}
interface FreeItem {
  id: string; title: string; slug: string; logo?: string; shortDesc?: string
  downloads: number; likes: number
  category: { name: string }
  author: { username: string; avatar?: string }
}
interface MembershipPlan {
  id: string; name: string; roleName: string; description: string
  price: number; features: string[]; color: string; isActive: boolean; sortOrder: number
}
interface ServerPlan { id: string; name: string; description: string; price: number; features?: string[]; isActive: boolean }
interface Ad {
  id: string
  title: string
  description?: string | null
  imageUrl?: string | null
  linkUrl?: string | null
  position?: string
  sortOrder?: number
}

export default function Home() {
  const [isChatOpen, setIsChatOpen] = useState(false)
  const [stats, setStats] = useState<Stats>({ totalUsers: 0, totalItems: 0, totalDownloads: 0 })
  const [featuredItems, setFeaturedItems] = useState<FeaturedItem[]>([])
  const [freeItems, setFreeItems] = useState<FreeItem[]>([])
  const [memberships, setMemberships] = useState<MembershipPlan[]>([])
  const [vpsPlans, setVpsPlans] = useState<ServerPlan[]>([])
  const [homeAds, setHomeAds] = useState<Ad[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    Promise.all([fetchStats(), fetchFeaturedItems(), fetchVpsPlans(), fetchAds(), fetchFreeItems(), fetchMemberships()])
  }, [])

  const fetchVpsPlans = async () => {
    try {
      const res = await fetch('/api/admin/plans?public=true')
      if (res.ok) { const data = await res.json(); setVpsPlans(Array.isArray(data.plans) ? data.plans.slice(0, 3) : []) }
    } catch {}
  }

  const fetchStats = async () => {
    try {
      const res = await fetch('/api/public-stats')
      if (res.ok) { const data = await res.json(); setStats(data) }
    } catch {}
  }

  const fetchFeaturedItems = async () => {
    try {
      const res = await fetch('/api/items?featured=true&limit=6')
      if (res.ok) { const data = await res.json(); setFeaturedItems(data.items || []) }
    } catch {} finally { setLoading(false) }
  }

  const fetchAds = async () => {
    try {
      const res = await fetch('/api/ads?position=homepage&limit=6')
      if (res.ok) {
        const data = await res.json()
        setHomeAds(Array.isArray(data.ads) ? data.ads : [])
      }
    } catch {}
  }

  const fetchFreeItems = async () => {
    try {
      const res = await fetch('/api/items?accessType=FREE&status=APPROVED&limit=6')
      if (res.ok) {
        const data = await res.json()
        setFreeItems(data.items || [])
      }
    } catch {}
  }

  const fetchMemberships = async () => {
    try {
      const res = await fetch('/api/memberships')
      if (res.ok) {
        const data = await res.json()
        setMemberships(Array.isArray(data) ? data.filter((m: MembershipPlan) => m.isActive) : [])
      }
    } catch {}
  }

  const fmt = (n: number) => n >= 1000000 ? (n / 1000000).toFixed(1) + 'M' : n >= 1000 ? (n / 1000).toFixed(1) + 'K' : n.toString()

  const statCards = [
    { value: fmt(stats.totalDownloads) || '10K+', label: 'Downloads', icon: <Download className="w-4 h-4" />, color: 'text-blue-400' },
    { value: fmt(stats.totalItems) || '500+', label: 'Items', icon: <Package className="w-4 h-4" />, color: 'text-purple-400' },
    { value: fmt(stats.totalUsers) || '1K+', label: 'Creators', icon: <Users className="w-4 h-4" />, color: 'text-green-400' },
    { value: '24/7', label: 'Support', icon: <Globe className="w-4 h-4" />, color: 'text-orange-400' },
  ]

  const categories = [
    { href: '/browse?category=plugins', label: 'Plugins', icon: <Zap className="h-5 w-5" />, color: 'from-blue-500/20 to-blue-600/10 border-blue-500/30 text-blue-400', desc: 'Economy, minigames & more' },
    { href: '/browse?category=mods', label: 'Mods', icon: <Star className="h-5 w-5" />, color: 'from-purple-500/20 to-purple-600/10 border-purple-500/30 text-purple-400', desc: 'Transform your gameplay' },
    { href: '/browse?category=texture-packs', label: 'Texture Packs', icon: <Package className="h-5 w-5" />, color: 'from-green-500/20 to-green-600/10 border-green-500/30 text-green-400', desc: 'Beautiful visuals' },
    { href: '/browse?category=maps', label: 'Maps', icon: <Globe className="h-5 w-5" />, color: 'from-orange-500/20 to-orange-600/10 border-orange-500/30 text-orange-400', desc: 'Adventure worlds' },
    { href: '/browse?category=shaders', label: 'Shaders', icon: <Sparkles className="h-5 w-5" />, color: 'from-pink-500/20 to-pink-600/10 border-pink-500/30 text-pink-400', desc: 'Stunning visuals' },
    { href: '/browse?category=server-setups', label: 'Server Setups', icon: <Shield className="h-5 w-5" />, color: 'from-cyan-500/20 to-cyan-600/10 border-cyan-500/30 text-cyan-400', desc: 'Ready to deploy' },
  ]

  const features = [
    { icon: <Shield className="h-6 w-6" />, title: 'Safe & Secure', desc: 'All files scanned for malware. Download with confidence.', color: 'from-green-500 to-emerald-600', shadow: 'shadow-green-500/20' },
    { icon: <Users className="h-6 w-6" />, title: 'Community Driven', desc: 'Join thousands of creators and Minecraft enthusiasts.', color: 'from-blue-500 to-cyan-600', shadow: 'shadow-blue-500/20' },
    { icon: <Zap className="h-6 w-6" />, title: 'Fast Downloads', desc: 'High-speed CDN for lightning-fast downloads worldwide.', color: 'from-purple-500 to-violet-600', shadow: 'shadow-purple-500/20' },
    { icon: <TrendingUp className="h-6 w-6" />, title: 'Creator Analytics', desc: 'Track downloads, views and earnings with detail.', color: 'from-orange-500 to-amber-600', shadow: 'shadow-orange-500/20' },
    { icon: <MessageSquare className="h-6 w-6" />, title: 'Real-time Chat', desc: 'Connect with creators instantly through live chat.', color: 'from-pink-500 to-rose-600', shadow: 'shadow-pink-500/20' },
    { icon: <Globe className="h-6 w-6" />, title: 'Global Access', desc: '24/7 availability with servers around the world.', color: 'from-cyan-500 to-teal-600', shadow: 'shadow-cyan-500/20' },
  ]

  return (
    <div className="min-h-screen bg-[#0a0a0f]">
      <Navbar onChatToggle={() => setIsChatOpen(!isChatOpen)} />

      {/* Hero */}
      <section className="relative py-28 px-4 text-center overflow-hidden">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff08_1px,transparent_1px),linear-gradient(to_bottom,#ffffff08_1px,transparent_1px)] bg-[size:32px_32px]" />
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[400px] bg-purple-600/20 rounded-full blur-[100px] pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-blue-600/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 right-0 w-64 h-64 bg-pink-600/15 rounded-full blur-3xl pointer-events-none" />

        <div className="container mx-auto relative z-10">
          <Badge className="mb-6 px-4 py-1.5 bg-purple-500/10 text-purple-300 border-purple-500/30 text-sm">
            <Sparkles className="w-3.5 h-3.5 mr-1.5" />
            The #1 Minecraft Content Marketplace
          </Badge>
          <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
            <span className="text-white">Discover</span>
            <br />
            <span className="bg-gradient-to-r from-purple-400 via-pink-400 to-blue-400 bg-clip-text text-transparent">
              Amazing Content
            </span>
          </h1>
          <p className="text-lg md:text-xl text-white/50 mb-10 max-w-2xl mx-auto leading-relaxed">
            Download plugins, mods, texture packs, and more from our community of creators.
            Join thousands of Minecraft enthusiasts and elevate your experience.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/browse">
              <Button size="lg" className="h-12 px-8 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 text-white text-base font-semibold rounded-xl shadow-lg shadow-purple-500/30 border-0 transition-all duration-300">
                <Search className="mr-2 h-5 w-5" />
                Browse Content
              </Button>
            </Link>
            <Link href="/auth/signup">
              <Button variant="outline" size="lg" className="h-12 px-8 bg-white/5 border-white/10 text-white hover:bg-white/10 text-base rounded-xl">
                <Play className="mr-2 h-5 w-5" />
                Get Started Free
              </Button>
            </Link>
          </div>

          {/* Quick stats below hero */}
          <div className="flex flex-wrap items-center justify-center gap-6 mt-12 text-sm text-white/40">
            <span className="flex items-center gap-1.5"><Check className="w-4 h-4 text-green-400" /> Free forever</span>
            <span className="flex items-center gap-1.5"><Check className="w-4 h-4 text-green-400" /> No credit card</span>
            <span className="flex items-center gap-1.5"><Check className="w-4 h-4 text-green-400" /> Instant access</span>
            <span className="flex items-center gap-1.5"><Check className="w-4 h-4 text-green-400" /> 1000+ items</span>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-14 px-4 border-y border-white/5 bg-white/[0.02]">
        <div className="container mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {statCards.map((s, i) => (
              <div key={i} className="text-center p-6 rounded-2xl bg-white/5 border border-white/5 hover:border-white/10 transition-colors">
                <div className={`text-4xl font-bold mb-2 ${s.color}`}>{s.value}</div>
                <div className="flex items-center justify-center gap-1.5 text-sm text-white/40">
                  {s.icon}
                  {s.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Quick Access */}
      <section className="py-16 px-4 border-b border-white/5">
        <div className="container mx-auto">
          <div className="text-center mb-10">
            <h2 className="text-2xl font-bold text-white mb-2">Explore Content</h2>
            <p className="text-white/40">Discover amazing Minecraft content from our community</p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
            <Link href="/freebies" className="group">
              <div className="bg-white/[0.03] hover:bg-white/[0.06] border border-white/8 hover:border-purple-500/30 rounded-xl p-4 text-center transition-all duration-300">
                <Gift className="h-8 w-8 text-green-400 mx-auto mb-2 group-hover:scale-110 transition-transform" />
                <span className="text-sm font-medium text-white/80">Freebies</span>
              </div>
            </Link>
            <Link href="/memberships" className="group">
              <div className="bg-white/[0.03] hover:bg-white/[0.06] border border-white/8 hover:border-purple-500/30 rounded-xl p-4 text-center transition-all duration-300">
                <Crown className="h-8 w-8 text-yellow-400 mx-auto mb-2 group-hover:scale-110 transition-transform" />
                <span className="text-sm font-medium text-white/80">Memberships</span>
              </div>
            </Link>
            <Link href="/badges" className="group">
              <div className="bg-white/[0.03] hover:bg-white/[0.06] border border-white/8 hover:border-purple-500/30 rounded-xl p-4 text-center transition-all duration-300">
                <Award className="h-8 w-8 text-blue-400 mx-auto mb-2 group-hover:scale-110 transition-transform" />
                <span className="text-sm font-medium text-white/80">Badges</span>
              </div>
            </Link>
            <Link href="/rewards" className="group">
              <div className="bg-white/[0.03] hover:bg-white/[0.06] border border-white/8 hover:border-purple-500/30 rounded-xl p-4 text-center transition-all duration-300">
                <Gift className="h-8 w-8 text-pink-400 mx-auto mb-2 group-hover:scale-110 transition-transform" />
                <span className="text-sm font-medium text-white/80">Rewards</span>
              </div>
            </Link>
            <Link href="/teams" className="group">
              <div className="bg-white/[0.03] hover:bg-white/[0.06] border border-white/8 hover:border-purple-500/30 rounded-xl p-4 text-center transition-all duration-300">
                <Users2 className="h-8 w-8 text-purple-400 mx-auto mb-2 group-hover:scale-110 transition-transform" />
                <span className="text-sm font-medium text-white/80">Teams</span>
              </div>
            </Link>
            <Link href="/campaigns" className="group">
              <div className="bg-white/[0.03] hover:bg-white/[0.06] border border-white/8 hover:border-purple-500/30 rounded-xl p-4 text-center transition-all duration-300">
                <CalendarDays className="h-8 w-8 text-orange-400 mx-auto mb-2 group-hover:scale-110 transition-transform" />
                <span className="text-sm font-medium text-white/80">Campaigns</span>
              </div>
            </Link>
          </div>
        </div>
      </section>

      {/* Featured Items */}
      {featuredItems.length > 0 && (
        <section className="py-20 px-4">
          <div className="container mx-auto">
            <div className="flex items-center justify-between mb-10">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <TrendingUp className="h-5 w-5 text-purple-400" />
                  <span className="text-sm font-medium text-purple-400 uppercase tracking-wider">Featured</span>
                </div>
                <h2 className="text-3xl font-bold text-white">Trending Content</h2>
                <p className="text-white/40 mt-1">Handpicked by our community</p>
              </div>
              <Link href="/browse?featured=true">
                <Button variant="ghost" className="text-white/50 hover:text-white hover:bg-white/5 gap-2">
                  View All <ArrowRight className="h-4 w-4" />
                </Button>
              </Link>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
              {featuredItems.map(item => (
                <Link key={item.id} href={`/items/${item.slug}`}>
                  <div className="group bg-white/[0.03] hover:bg-white/[0.06] border border-white/8 hover:border-purple-500/30 rounded-2xl p-5 transition-all duration-300 cursor-pointer h-full flex flex-col">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500/20 to-blue-500/20 border border-white/10 flex items-center justify-center flex-shrink-0">
                          {item.logo ? (
                            <img src={item.logo} alt={item.title} className="w-full h-full object-cover rounded-xl" />
                          ) : (
                            <Package className="w-5 h-5 text-white/30" />
                          )}
                        </div>
                        <div>
                          <div className="flex flex-wrap gap-1 mb-1">
                            <Badge className="bg-white/5 text-white/50 border-white/10 text-[10px]">{item.category?.name}</Badge>
                            {item.accessType === 'PAID' && <Badge className="bg-orange-500/20 text-orange-300 border-orange-500/30 text-[10px]">Premium</Badge>}
                            {item.accessType === 'ROLE' && <Badge className="bg-purple-500/20 text-purple-300 border-purple-500/30 text-[10px]">Membership</Badge>}
                            {item.accessType === 'FREE' && <Badge className="bg-green-500/20 text-green-300 border-green-500/30 text-[10px]">Free</Badge>}
                          </div>
                          <h3 className="font-semibold text-white text-sm group-hover:text-purple-300 transition-colors line-clamp-1">{item.title}</h3>
                        </div>
                      </div>
                    </div>
                    <p className="text-white/40 text-xs line-clamp-2 mb-4 flex-1">{item.shortDesc || 'No description available'}</p>
                    <div className="flex items-center justify-between text-xs text-white/30">
                      <span>by <span className="text-white/50">{item.author?.username}</span></span>
                      <div className="flex items-center gap-3">
                        <span className="flex items-center gap-1"><Star className="h-3 w-3 text-yellow-400" />{item.likes}</span>
                        <span className="flex items-center gap-1"><Download className="h-3 w-3" />{fmt(item.downloads)}</span>
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Freebies */}
      {freeItems.length > 0 && (
        <section className="py-20 px-4 bg-white/[0.02] border-y border-white/5">
          <div className="container mx-auto">
            <div className="flex items-center justify-between mb-10">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <Gift className="h-5 w-5 text-green-400" />
                  <span className="text-sm font-medium text-green-400 uppercase tracking-wider">Free</span>
                </div>
                <h2 className="text-3xl font-bold text-white">Free Downloads</h2>
                <p className="text-white/40 mt-1">High-quality content, completely free</p>
              </div>
              <Link href="/freebies">
                <Button variant="ghost" className="text-white/50 hover:text-white hover:bg-white/5 gap-2">
                  View All <ArrowRight className="h-4 w-4" />
                </Button>
              </Link>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
              {freeItems.map(item => (
                <Link key={item.id} href={`/items/${item.slug}`}>
                  <div className="group bg-white/[0.03] hover:bg-white/[0.06] border border-white/8 hover:border-green-500/30 rounded-2xl p-5 transition-all duration-300 cursor-pointer h-full flex flex-col">
                    <div className="flex items-start gap-3 mb-4">
                      <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-green-500/20 to-emerald-500/20 border border-white/10 flex items-center justify-center flex-shrink-0 overflow-hidden">
                        {item.logo ? (
                          <img src={item.logo} alt={item.title} className="w-full h-full object-cover rounded-xl" />
                        ) : (
                          <Gift className="w-5 h-5 text-green-400" />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex gap-1 mb-1">
                          <Badge className="bg-green-500/20 text-green-300 border-green-500/30 text-[10px]">Free</Badge>
                          <Badge className="bg-white/5 text-white/50 border-white/10 text-[10px]">{item.category?.name}</Badge>
                        </div>
                        <h3 className="font-semibold text-white text-sm group-hover:text-green-300 transition-colors line-clamp-1">{item.title}</h3>
                      </div>
                    </div>
                    <p className="text-white/40 text-xs line-clamp-2 mb-4 flex-1">{item.shortDesc || 'Free download available'}</p>
                    <div className="flex items-center justify-between text-xs text-white/30">
                      <span>by <span className="text-white/50">{item.author?.username}</span></span>
                      <div className="flex items-center gap-3">
                        <span className="flex items-center gap-1"><Heart className="h-3 w-3 text-pink-400" />{item.likes}</span>
                        <span className="flex items-center gap-1"><Download className="h-3 w-3" />{fmt(item.downloads)}</span>
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Categories */}
      <section className="py-20 px-4 bg-white/[0.02] border-y border-white/5">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <div className="flex items-center justify-center gap-2 mb-2">
              <Package className="h-5 w-5 text-blue-400" />
              <span className="text-sm font-medium text-blue-400 uppercase tracking-wider">Categories</span>
            </div>
            <h2 className="text-3xl font-bold text-white mb-2">Explore by Category</h2>
            <p className="text-white/40">Find the perfect content for your Minecraft experience</p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {categories.map(cat => (
              <Link key={cat.href} href={cat.href}>
                <div className={`group bg-gradient-to-br ${cat.color} border rounded-2xl p-5 hover:scale-[1.02] transition-all duration-300 cursor-pointer`}>
                  <div className="flex items-center gap-3 mb-2">
                    <div className={cat.color.includes('text-') ? cat.color.split(' ').find(c => c.startsWith('text-')) || '' : ''}>
                      {cat.icon}
                    </div>
                    <h3 className="font-semibold text-white">{cat.label}</h3>
                  </div>
                  <p className="text-white/40 text-sm">{cat.desc}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Ads */}
      {homeAds.length > 0 && (
        <section className="py-12 px-4 bg-white/[0.02] border-y border-white/5">
          <div className="container mx-auto">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-2">
                <Zap className="h-5 w-5 text-yellow-400" />
                <span className="text-sm font-medium text-yellow-400 uppercase tracking-wider">Sponsored</span>
              </div>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
              {homeAds.slice(0, 6).map(ad => {
                const adContent = (
                  <div className={`rounded-2xl border border-white/8 overflow-hidden h-full transition-all hover:border-white/15 ${ad.imageUrl ? 'bg-black' : 'bg-white/[0.03] hover:bg-white/[0.06] p-4'}`}>
                    {ad.imageUrl ? (
                      <div className="relative group cursor-pointer h-full min-h-[120px] overflow-hidden">
                        <img src={ad.imageUrl} alt={ad.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                        <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-60" />
                        <div className="absolute bottom-0 left-0 right-0 p-4 text-white">
                          <h3 className="text-sm font-semibold">{ad.title}</h3>
                          {ad.description && <p className="text-xs text-white/70 mt-1">{ad.description}</p>}
                        </div>
                      </div>
                    ) : (
                      <div className="flex items-start gap-3 h-full">
                        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-yellow-500/15 to-orange-500/15 border border-yellow-500/20 flex items-center justify-center flex-shrink-0">
                          <Zap className="w-5 h-5 text-yellow-400" />
                        </div>
                        <div className="min-w-0 flex-1">
                          <h3 className="text-sm font-semibold text-white/90 truncate">{ad.title}</h3>
                          {ad.description && (
                            <p className="text-xs text-white/40 mt-1 line-clamp-2">{ad.description}</p>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                )

                return (
                  <div key={ad.id}>
                    {ad.linkUrl ? (
                      <a href={ad.linkUrl} target={ad.linkUrl.startsWith('http') ? '_blank' : undefined} rel="noreferrer" onClick={() => fetch('/api/ads', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ adId: ad.id }) }).catch(() => {})}>
                        {adContent}
                      </a>
                    ) : (
                      adContent
                    )}
                  </div>
                )
              })}
            </div>
          </div>
        </section>
      )}

      {/* Features */}
      <section className="py-20 px-4">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <div className="flex items-center justify-center gap-2 mb-2">
              <Zap className="h-5 w-5 text-yellow-400" />
              <span className="text-sm font-medium text-yellow-400 uppercase tracking-wider">Why GfxStore</span>
            </div>
            <h2 className="text-3xl font-bold text-white mb-2">Everything you need</h2>
            <p className="text-white/40">Built for the Minecraft community, by the community</p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
            {features.map((f, i) => (
              <div key={i} className="group bg-white/[0.03] hover:bg-white/[0.06] border border-white/5 hover:border-white/10 rounded-2xl p-6 transition-all duration-300">
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${f.color} flex items-center justify-center mb-4 text-white shadow-lg ${f.shadow}`}>
                  {f.icon}
                </div>
                <h3 className="text-base font-semibold text-white mb-2">{f.title}</h3>
                <p className="text-sm text-white/40 leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Memberships */}
      {memberships.length > 0 && (
        <section className="py-20 px-4 bg-white/[0.02] border-y border-white/5">
          <div className="container mx-auto">
            <div className="text-center mb-12">
              <div className="flex items-center justify-center gap-2 mb-2">
                <Crown className="h-5 w-5 text-yellow-400" />
                <span className="text-sm font-medium text-yellow-400 uppercase tracking-wider">Memberships</span>
              </div>
              <h2 className="text-3xl font-bold text-white mb-2">Unlock Premium Access</h2>
              <p className="text-white/40">Get exclusive content and perks with a membership</p>
            </div>
            <div className="grid md:grid-cols-3 gap-5 max-w-4xl mx-auto">
              {memberships.slice(0, 3).map((plan, i) => (
                <div key={plan.id} className={`relative rounded-2xl p-6 flex flex-col border transition-all hover:scale-[1.02] ${i === 1 ? 'border-yellow-500/50 bg-yellow-500/5' : 'border-white/8 bg-white/[0.03]'}`}>
                  {i === 1 && (
                    <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                      <Badge className="bg-yellow-500 text-black border-0 text-xs px-3 font-bold">Most Popular</Badge>
                    </div>
                  )}
                  <div className="mb-5">
                    <div className="flex items-center gap-2 mb-2">
                      <Crown className={`h-5 w-5 ${i === 1 ? 'text-yellow-400' : 'text-white/40'}`} />
                      <h3 className="font-bold text-white text-lg">{plan.name}</h3>
                    </div>
                    <p className="text-white/40 text-sm mb-3">{plan.description}</p>
                    <div>
                      <span className="text-4xl font-bold text-white">${plan.price}</span>
                      <span className="text-white/40 text-sm">/mo</span>
                    </div>
                  </div>
                  {plan.features && plan.features.length > 0 && (
                    <ul className="space-y-2 mb-6 flex-1">
                      {plan.features.slice(0, 5).map((f, fi) => (
                        <li key={fi} className="flex items-start gap-2 text-sm text-white/60">
                          <Check className="h-4 w-4 text-yellow-400 mt-0.5 flex-shrink-0" />
                          {f}
                        </li>
                      ))}
                    </ul>
                  )}
                  <Link href="/memberships">
                    <Button className={`w-full rounded-xl ${i === 1 ? 'bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-400 hover:to-orange-400 border-0 text-black font-semibold shadow-lg shadow-yellow-500/25' : 'bg-white/5 hover:bg-white/10 border-white/10 text-white'}`}>
                      Get {plan.name} <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </Link>
                </div>
              ))}
            </div>
            <div className="text-center mt-8">
              <Link href="/memberships">
                <Button variant="ghost" className="text-white/50 hover:text-white hover:bg-white/5 gap-2">
                  View all plans <ArrowRight className="h-4 w-4" />
                </Button>
              </Link>
            </div>
          </div>
        </section>
      )}

      {/* VPS Plans */}
      {vpsPlans.length > 0 && (
        <section className="py-20 px-4 bg-white/[0.02] border-y border-white/5">
          <div className="container mx-auto">
            <div className="text-center mb-12">
              <div className="flex items-center justify-center gap-2 mb-2">
                <Server className="h-5 w-5 text-cyan-400" />
                <span className="text-sm font-medium text-cyan-400 uppercase tracking-wider">Hosting</span>
              </div>
              <h2 className="text-3xl font-bold text-white mb-2">VPS & Server Plans</h2>
              <p className="text-white/40">Powerful hosting for your Minecraft server</p>
            </div>
            <div className="grid md:grid-cols-3 gap-5 max-w-4xl mx-auto">
              {vpsPlans.map((plan, i) => (
                <div key={plan.id} className={`relative bg-white/[0.03] border rounded-2xl p-6 flex flex-col ${i === 1 ? 'border-purple-500/50 bg-purple-500/5' : 'border-white/8'}`}>
                  {i === 1 && (
                    <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                      <Badge className="bg-purple-500 text-white border-0 text-xs px-3">Most Popular</Badge>
                    </div>
                  )}
                  <div className="mb-4">
                    <h3 className="font-bold text-white text-lg">{plan.name}</h3>
                    <p className="text-white/40 text-sm mt-1">{plan.description}</p>
                    <div className="mt-3">
                      <span className="text-4xl font-bold text-white">${plan.price}</span>
                      <span className="text-white/40 text-sm">/mo</span>
                    </div>
                  </div>
                  {plan.features && (
                    <ul className="space-y-2 mb-6 flex-1">
                      {plan.features.slice(0, 5).map((f, fi) => (
                        <li key={fi} className="flex items-start gap-2 text-sm text-white/60">
                          <Check className="h-4 w-4 text-green-400 mt-0.5 flex-shrink-0" />
                          {f}
                        </li>
                      ))}
                    </ul>
                  )}
                  <Link href="/vps">
                    <Button className={`w-full rounded-xl ${i === 1 ? 'bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 border-0 text-white shadow-lg shadow-purple-500/25' : 'bg-white/5 hover:bg-white/10 border-white/10 text-white'}`}>
                      Get Started <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </Link>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* CTA */}
      <section className="py-24 px-4 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-purple-600/10 via-blue-600/10 to-purple-600/10" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-purple-600/20 rounded-full blur-3xl pointer-events-none" />
        <div className="container mx-auto text-center relative z-10">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">Ready to dive in?</h2>
          <p className="text-xl text-white/40 mb-10 max-w-xl mx-auto">
            Join thousands of Minecraft players discovering and sharing amazing content on GfxStore.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/auth/signup">
              <Button size="lg" className="h-12 px-10 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 text-white text-base font-semibold rounded-xl shadow-xl shadow-purple-500/30 border-0">
                Create Free Account
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
            <Link href="/browse">
              <Button variant="outline" size="lg" className="h-12 px-10 bg-white/5 border-white/10 text-white hover:bg-white/10 text-base rounded-xl">
                <Search className="mr-2 h-5 w-5" />
                Browse Content
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <Footer />
      <ChatWidget isOpen={isChatOpen} onToggle={() => setIsChatOpen(!isChatOpen)} />
    </div>
  )
}
