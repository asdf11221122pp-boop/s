'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Megaphone, Plus, DollarSign, Clock, Tag, Loader2, Send, Gavel, Check, Pencil, Trash2, X, Save } from 'lucide-react'
import { toast } from 'sonner'

interface CustomOrder {
  id: string; title: string; description: string; budget?: number
  deadline?: string; category?: string; status: string; createdAt: string
  buyer: { id: string; username: string; avatar?: string }
  bids: Array<{ id: string; price: number; deliveryDays: number; message: string; seller: { id: string; username: string; avatar?: string; isVerified: boolean; sellerLevel: number; totalSales: number } }>
}

function OrderCard({ order, currentUserId, onBid, onSelect, onEdit, onDelete }: {
  order: CustomOrder; currentUserId?: string
  onBid: (id: string, price: string, days: string, msg: string) => void
  onSelect: (orderId: string, bidId: string) => void
  onEdit?: (order: CustomOrder) => void
  onDelete?: (id: string) => void
}) {
  const [showBidForm, setShowBidForm] = useState(false)
  const [bidPrice, setBidPrice] = useState('')
  const [bidDays, setBidDays] = useState('')
  const [bidMsg, setBidMsg] = useState('')
  const hasBid = order.bids.some(b => b.seller.id === currentUserId)
  const isOwner = order.buyer.id === currentUserId

  return (
    <div className="bg-white/[0.03] border border-white/8 hover:border-orange-500/20 rounded-2xl p-5 transition-all">
      <div className="flex items-start justify-between gap-3 mb-3 flex-wrap">
        <div className="flex items-center gap-3">
          <Avatar className="h-8 w-8">
            <AvatarImage src={order.buyer.avatar || undefined} />
            <AvatarFallback className="bg-orange-500/20 text-orange-300 text-xs">{order.buyer.username.slice(0, 2).toUpperCase()}</AvatarFallback>
          </Avatar>
          <div>
            <h3 className="font-semibold text-white text-sm">{order.title}</h3>
            <p className="text-xs text-white/40">by {order.buyer.username}</p>
          </div>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          {order.budget && <Badge className="bg-green-500/10 text-green-400 border-green-500/20 text-xs"><DollarSign className="w-3 h-3 mr-1" />{order.budget}</Badge>}
          {order.deadline && <Badge className="bg-blue-500/10 text-blue-400 border-blue-500/20 text-xs"><Clock className="w-3 h-3 mr-1" />{order.deadline}</Badge>}
          {order.category && <Badge className="bg-white/5 text-white/40 border-white/10 text-xs"><Tag className="w-3 h-3 mr-1" />{order.category}</Badge>}
          {isOwner && order.status === 'OPEN' && (onEdit || onDelete) && (
            <div className="flex gap-1">
              {onEdit && (
                <button onClick={() => onEdit(order)} title="Edit" className="text-white/40 hover:text-blue-300 transition-colors p-1 rounded hover:bg-blue-500/10">
                  <Pencil className="w-3.5 h-3.5" />
                </button>
              )}
              {onDelete && (
                <button onClick={() => { if (confirm('Delete this request?')) onDelete(order.id) }} title="Delete" className="text-white/40 hover:text-red-300 transition-colors p-1 rounded hover:bg-red-500/10">
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          )}
        </div>
      </div>
      <p className="text-white/50 text-sm mb-4 line-clamp-3">{order.description}</p>
      <div className="flex items-center justify-between flex-wrap gap-2">
        <span className="text-xs text-white/30">{order.bids.length} bid{order.bids.length !== 1 ? 's' : ''} · {new Date(order.createdAt).toLocaleDateString()}</span>
        {!isOwner && !hasBid && order.status === 'OPEN' && currentUserId && (
          <Button size="sm" onClick={() => setShowBidForm(!showBidForm)} className="h-7 text-xs bg-orange-500/20 hover:bg-orange-500/40 text-orange-400 border-0 rounded-lg gap-1">
            <Gavel className="w-3 h-3" />Place Bid
          </Button>
        )}
        {hasBid && <Badge className="bg-green-500/10 text-green-400 border-green-500/20 text-xs"><Check className="w-3 h-3 mr-1" />Bid Placed</Badge>}
      </div>

      {showBidForm && (
        <div className="mt-4 pt-4 border-t border-white/10 space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-white/60 text-xs mb-1 block">Your Price ($) *</Label>
              <Input value={bidPrice} onChange={e => setBidPrice(e.target.value)} placeholder="25.00" type="number" className="h-9 bg-white/5 border-white/10 text-white text-sm rounded-lg" />
            </div>
            <div>
              <Label className="text-white/60 text-xs mb-1 block">Delivery (days) *</Label>
              <Input value={bidDays} onChange={e => setBidDays(e.target.value)} placeholder="3" type="number" className="h-9 bg-white/5 border-white/10 text-white text-sm rounded-lg" />
            </div>
          </div>
          <Textarea value={bidMsg} onChange={e => setBidMsg(e.target.value)} placeholder="Describe your offer and skills..." className="bg-white/5 border-white/10 text-white placeholder:text-white/30 rounded-lg min-h-[80px] text-sm resize-none" />
          <div className="flex gap-2">
            <Button size="sm" onClick={() => { onBid(order.id, bidPrice, bidDays, bidMsg); setShowBidForm(false); setBidPrice(''); setBidDays(''); setBidMsg('') }}
              className="h-8 text-xs bg-gradient-to-r from-orange-500 to-pink-500 text-white border-0 rounded-lg gap-1">
              <Send className="w-3 h-3" />Submit Bid
            </Button>
            <Button size="sm" variant="ghost" onClick={() => setShowBidForm(false)} className="h-8 text-xs text-white/50 hover:bg-white/5 rounded-lg">Cancel</Button>
          </div>
        </div>
      )}

      {isOwner && order.bids.length > 0 && (
        <div className="mt-4 pt-4 border-t border-white/10">
          <p className="text-xs font-medium text-white/60 mb-3">Received Bids ({order.bids.length})</p>
          <div className="space-y-2">
            {order.bids.map(bid => (
              <div key={bid.id} className="flex items-center gap-3 p-2.5 bg-white/[0.03] rounded-xl border border-white/5">
                <Avatar className="h-7 w-7"><AvatarFallback className="text-[10px] bg-blue-500/20 text-blue-300">{bid.seller.username.slice(0, 2).toUpperCase()}</AvatarFallback></Avatar>
                <div className="flex-1 min-w-0">
                  <span className="text-sm text-white font-medium">{bid.seller.username}</span>
                  {bid.seller.isVerified && <span className="ml-1 text-blue-400 text-xs">✓</span>}
                  <p className="text-xs text-white/40 line-clamp-1">{bid.message}</p>
                </div>
                <div className="text-right flex-shrink-0">
                  <p className="text-green-400 text-sm font-semibold">${bid.price}</p>
                  <p className="text-white/30 text-xs">{bid.deliveryDays}d</p>
                </div>
                {order.status === 'OPEN' && (
                  <Button size="sm" onClick={() => onSelect(order.id, bid.id)} className="h-6 text-xs bg-green-500/20 hover:bg-green-500/40 text-green-400 border-0 rounded-lg px-2">
                    Select
                  </Button>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

export default function CustomOrdersPage() {
  const { data: session } = useSession()
  const [orders, setOrders] = useState<CustomOrder[]>([])
  const [myOrders, setMyOrders] = useState<CustomOrder[]>([])
  const [loading, setLoading] = useState(true)
  const [posting, setPosting] = useState(false)
  const [showForm, setShowForm] = useState(false)
  const [form, setForm] = useState({ title: '', description: '', budget: '', deadline: '', category: '' })

  const [editingOrder, setEditingOrder] = useState<CustomOrder | null>(null)
  const [editForm, setEditForm] = useState({ title: '', description: '', budget: '', deadline: '', category: '' })
  const [saving, setSaving] = useState(false)
  const [deleting, setDeleting] = useState<string | null>(null)

  useEffect(() => { fetchOrders() }, [session])

  const fetchOrders = async () => {
    try {
      const [pub, my] = await Promise.all([
        fetch('/api/custom-orders'),
        session?.user?.id ? fetch('/api/custom-orders?my=true') : Promise.resolve(null)
      ])
      if (pub.ok) { const d = await pub.json(); setOrders(d.orders || []) }
      if (my?.ok) { const d = await my.json(); setMyOrders(d.orders || []) }
    } catch {} finally { setLoading(false) }
  }

  const handlePost = async () => {
    if (!form.title || !form.description) { toast.error('Title and description required'); return }
    setPosting(true)
    try {
      const res = await fetch('/api/custom-orders', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form) })
      const data = await res.json()
      if (res.ok) { toast.success('Custom order posted!'); setShowForm(false); setForm({ title: '', description: '', budget: '', deadline: '', category: '' }); fetchOrders() }
      else toast.error(data.error)
    } catch { toast.error('Failed to post order') } finally { setPosting(false) }
  }

  const handleBid = async (orderId: string, price: string, days: string, msg: string) => {
    try {
      const res = await fetch(`/api/custom-orders/${orderId}/bids`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ price: parseFloat(price), deliveryDays: parseInt(days), message: msg }) })
      const data = await res.json()
      if (res.ok) { toast.success('Bid placed!'); fetchOrders() }
      else toast.error(data.error)
    } catch { toast.error('Failed to place bid') }
  }

  const handleSelect = async (orderId: string, bidId: string) => {
    try {
      const res = await fetch(`/api/custom-orders/${orderId}/bids`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ bidId }) })
      if (res.ok) { toast.success('Bid selected!'); fetchOrders() }
    } catch { toast.error('Failed to select bid') }
  }

  const openEdit = (order: CustomOrder) => {
    setEditingOrder(order)
    setEditForm({ title: order.title, description: order.description, budget: order.budget?.toString() || '', deadline: order.deadline || '', category: order.category || '' })
  }

  const handleSaveEdit = async () => {
    if (!editingOrder) return
    setSaving(true)
    try {
      const res = await fetch(`/api/custom-orders/${editingOrder.id}`, {
        method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(editForm)
      })
      if (res.ok) {
        toast.success('Order updated!'); setEditingOrder(null); fetchOrders()
      } else {
        const d = await res.json(); toast.error(d.error || 'Failed to update')
      }
    } catch { toast.error('Failed to update order') } finally { setSaving(false) }
  }

  const handleDelete = async (id: string) => {
    setDeleting(id)
    try {
      const res = await fetch(`/api/custom-orders/${id}`, { method: 'DELETE' })
      if (res.ok) { toast.success('Order deleted'); fetchOrders() }
      else { const d = await res.json(); toast.error(d.error || 'Failed to delete') }
    } catch { toast.error('Failed to delete') } finally { setDeleting(null) }
  }

  return (
    <div className="min-h-screen bg-[#0a0a0f]">
      <Navbar />
      <div className="container mx-auto px-4 py-12 max-w-4xl">
        <div className="flex items-start justify-between mb-8 flex-wrap gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1"><Megaphone className="h-5 w-5 text-orange-400" /><span className="text-sm font-medium text-orange-400 uppercase tracking-wider">Marketplace</span></div>
            <h1 className="text-3xl font-bold text-white">Custom Orders</h1>
            <p className="text-white/40 mt-1 text-sm">Post a request and let sellers compete with their best offers</p>
          </div>
          {session && (
            <Button onClick={() => setShowForm(!showForm)} className="bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-400 hover:to-pink-400 text-white border-0 rounded-xl gap-2">
              <Plus className="h-4 w-4" />Post Request
            </Button>
          )}
        </div>

        {showForm && (
          <div className="bg-white/[0.03] border border-orange-500/20 rounded-2xl p-6 mb-6">
            <h2 className="text-lg font-semibold text-white mb-4">New Custom Order Request</h2>
            <div className="space-y-4">
              <div><Label className="text-white/60 text-sm mb-1 block">Title *</Label><Input value={form.title} onChange={e => setForm(p => ({ ...p, title: e.target.value }))} placeholder="Need a Minecraft server logo in neon style" className="h-10 bg-white/5 border-white/10 text-white placeholder:text-white/30 rounded-xl" /></div>
              <div><Label className="text-white/60 text-sm mb-1 block">Description *</Label><Textarea value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} placeholder="Describe exactly what you need..." className="bg-white/5 border-white/10 text-white placeholder:text-white/30 rounded-xl min-h-[100px] resize-none" /></div>
              <div className="grid grid-cols-3 gap-3">
                <div><Label className="text-white/60 text-xs mb-1 block">Budget ($)</Label><Input value={form.budget} onChange={e => setForm(p => ({ ...p, budget: e.target.value }))} placeholder="50" type="number" className="h-9 bg-white/5 border-white/10 text-white text-sm rounded-xl" /></div>
                <div><Label className="text-white/60 text-xs mb-1 block">Deadline</Label><Input value={form.deadline} onChange={e => setForm(p => ({ ...p, deadline: e.target.value }))} placeholder="3 days" className="h-9 bg-white/5 border-white/10 text-white text-sm rounded-xl" /></div>
                <div><Label className="text-white/60 text-xs mb-1 block">Category</Label><Input value={form.category} onChange={e => setForm(p => ({ ...p, category: e.target.value }))} placeholder="Logo, Plugin..." className="h-9 bg-white/5 border-white/10 text-white text-sm rounded-xl" /></div>
              </div>
              <div className="flex gap-2">
                <Button onClick={handlePost} disabled={posting} className="bg-gradient-to-r from-orange-500 to-pink-500 text-white border-0 rounded-xl h-10 gap-2">
                  {posting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}Post Request
                </Button>
                <Button variant="ghost" onClick={() => setShowForm(false)} className="text-white/50 hover:bg-white/5 rounded-xl h-10">Cancel</Button>
              </div>
            </div>
          </div>
        )}

        {editingOrder && (
          <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-[#0f0f1a] border border-blue-500/30 rounded-2xl p-6 w-full max-w-lg">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-white">Edit Order</h2>
                <button onClick={() => setEditingOrder(null)} className="text-white/40 hover:text-white"><X className="w-5 h-5" /></button>
              </div>
              <div className="space-y-4">
                <div><Label className="text-white/60 text-sm mb-1 block">Title *</Label><Input value={editForm.title} onChange={e => setEditForm(p => ({ ...p, title: e.target.value }))} className="bg-white/5 border-white/10 text-white rounded-xl" /></div>
                <div><Label className="text-white/60 text-sm mb-1 block">Description *</Label><Textarea value={editForm.description} onChange={e => setEditForm(p => ({ ...p, description: e.target.value }))} className="bg-white/5 border-white/10 text-white rounded-xl min-h-[100px] resize-none" /></div>
                <div className="grid grid-cols-3 gap-3">
                  <div><Label className="text-white/60 text-xs mb-1 block">Budget ($)</Label><Input value={editForm.budget} onChange={e => setEditForm(p => ({ ...p, budget: e.target.value }))} type="number" className="h-9 bg-white/5 border-white/10 text-white text-sm rounded-xl" /></div>
                  <div><Label className="text-white/60 text-xs mb-1 block">Deadline</Label><Input value={editForm.deadline} onChange={e => setEditForm(p => ({ ...p, deadline: e.target.value }))} placeholder="3 days" className="h-9 bg-white/5 border-white/10 text-white text-sm rounded-xl" /></div>
                  <div><Label className="text-white/60 text-xs mb-1 block">Category</Label><Input value={editForm.category} onChange={e => setEditForm(p => ({ ...p, category: e.target.value }))} className="h-9 bg-white/5 border-white/10 text-white text-sm rounded-xl" /></div>
                </div>
                <div className="flex gap-2 pt-2">
                  <Button onClick={handleSaveEdit} disabled={saving} className="bg-blue-600 hover:bg-blue-500 text-white border-0 gap-2">
                    {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}Save Changes
                  </Button>
                  <Button variant="ghost" onClick={() => setEditingOrder(null)} className="text-white/50">Cancel</Button>
                </div>
              </div>
            </div>
          </div>
        )}

        {loading ? (
          <div className="flex items-center justify-center py-20"><Loader2 className="w-8 h-8 animate-spin text-orange-400" /></div>
        ) : (
          <Tabs defaultValue="marketplace">
            <TabsList className="bg-white/5 border border-white/10 rounded-xl p-1 mb-6 inline-flex gap-1">
              <TabsTrigger value="marketplace" className="rounded-lg text-xs px-4 py-2 data-[state=active]:bg-orange-500/20 data-[state=active]:text-orange-300 text-white/50">
                Open Requests ({orders.length})
              </TabsTrigger>
              {session && (
                <TabsTrigger value="mine" className="rounded-lg text-xs px-4 py-2 data-[state=active]:bg-orange-500/20 data-[state=active]:text-orange-300 text-white/50">
                  My Requests ({myOrders.length})
                </TabsTrigger>
              )}
            </TabsList>
            <TabsContent value="marketplace">
              {orders.length === 0 ? (
                <div className="text-center py-16"><Megaphone className="w-12 h-12 mx-auto text-white/10 mb-3" /><p className="text-white/40">No open requests yet</p></div>
              ) : (
                <div className="space-y-4">{orders.map(o => <OrderCard key={o.id} order={o} currentUserId={session?.user?.id} onBid={handleBid} onSelect={handleSelect} />)}</div>
              )}
            </TabsContent>
            {session && (
              <TabsContent value="mine">
                {myOrders.length === 0 ? (
                  <div className="text-center py-16">
                    <Megaphone className="w-12 h-12 mx-auto text-white/10 mb-3" />
                    <p className="text-white/40">You haven&apos;t posted any requests yet</p>
                    <Button onClick={() => setShowForm(true)} size="sm" className="mt-3 bg-orange-500/20 text-orange-300 border-0 hover:bg-orange-500/30">Post a Request</Button>
                  </div>
                ) : (
                  <div className="space-y-4">{myOrders.map(o => (
                    <OrderCard key={o.id} order={o} currentUserId={session.user?.id} onBid={handleBid} onSelect={handleSelect}
                      onEdit={openEdit}
                      onDelete={deleting === o.id ? undefined : handleDelete}
                    />
                  ))}</div>
                )}
              </TabsContent>
            )}
          </Tabs>
        )}
      </div>
      <Footer />
    </div>
  )
}
