'use client'

import { useEffect, useState } from 'react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { BookOpen, Loader2 } from 'lucide-react'

export default function GuidelinesPage() {
  const [content, setContent] = useState('')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch('/api/admin/settings')
      .then(r => r.json())
      .then(d => {
        setContent(d.guidelines || '')
        setLoading(false)
      })
      .catch(() => setLoading(false))
  }, [])

  return (
    <div className="min-h-screen bg-[#0a0a0f] flex flex-col">
      <Navbar />
      <main className="flex-1 container mx-auto px-4 py-12 max-w-4xl">
        <div className="flex items-center gap-3 mb-8">
          <BookOpen className="w-8 h-8 text-green-400" />
          <h1 className="text-3xl font-bold text-white">Community Guidelines</h1>
        </div>
        {loading ? (
          <div className="flex justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin text-purple-500" />
          </div>
        ) : content ? (
          <div className="prose prose-invert max-w-none">
            <div className="text-white/70 leading-relaxed whitespace-pre-wrap bg-white/[0.03] border border-white/10 rounded-2xl p-8">
              {content}
            </div>
          </div>
        ) : (
          <div className="text-center py-20 text-white/40">
            <BookOpen className="w-12 h-12 mx-auto mb-4 opacity-30" />
            <p>Community guidelines have not been set up yet.</p>
          </div>
        )}
      </main>
      <Footer />
    </div>
  )
}
