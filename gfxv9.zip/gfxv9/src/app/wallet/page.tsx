'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Wallet, DollarSign, ArrowUpRight, ArrowDownLeft, Clock, CheckCircle, XCircle, Plus, Send, TrendingUp, Loader2, AlertTriangle, Star, Zap } from 'lucide-react'
import { toast } from 'sonner'

interface Transaction {
  id: string; amount: number; method: string; type: string; status: string; createdAt: string; notes?: string
}
interface WithdrawRequest {
  id: string; amount: number; method: string; accountInfo: string; status: string; adminNote?: string; createdAt: string; processedAt?: string
}
interface Membership {
  id: string; name: string; price: number; description?: string; owned?: boolean; features?: string[]
}

const STATUS_COLORS: Record<string, string> = {
  PENDING: 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20',
  APPROVED: 'bg-green-500/10 text-green-400 border-green-500/20',
  REJECTED: 'bg-red-500/10 text-red-400 border-red-500/20',
  COMPLETED: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
}

export default function WalletPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [balance, setBalance] = useState(0)
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [withdrawals, setWithdrawals] = useState<WithdrawRequest[]>([])
  const [memberships, setMemberships] = useState<Membership[]>([])
  const [loading, setLoading] = useState(true)
  const [withdrawForm, setWithdrawForm] = useState({ amount: '', method: 'bkash', accountInfo: '' })
  const [submitting, setSubmitting] = useState(false)
  const [dialogOpen, setDialogOpen] = useState(false)

  useEffect(() => {
    if (status === 'unauthenticated') router.push('/auth/signin')
    if (status === 'authenticated') loadAll()
  }, [status])

  const loadAll = async () => {
    setLoading(true)
    try {
      const [userRes, txRes, wdRes, memRes] = await Promise.all([
        fetch('/api/users/me').then(r => r.ok ? r.json() : {}),
        fetch('/api/transactions').then(r => r.ok ? r.json() : []),
        fetch('/api/seller/withdraw').then(r => r.ok ? r.json() : { requests: [] }),
        fetch('/api/user/memberships').then(r => r.ok ? r.json() : []).catch(() => [])
      ])
      setBalance(userRes?.walletBalance || 0)
      setTransactions(Array.isArray(txRes) ? txRes : [])
      setWithdrawals(wdRes?.requests || [])
      setMemberships(Array.isArray(memRes) ? memRes : [])
    } catch { } finally { setLoading(false) }
  }

  const submitWithdraw = async () => {
    if (!withdrawForm.amount || !withdrawForm.accountInfo) { toast.error('All fields required'); return }
    setSubmitting(true)
    try {
      const res = await fetch('/api/seller/withdraw', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(withdrawForm)
      })
      const data = await res.json()
      if (res.ok) {
        toast.success(data.message || 'Withdrawal requested!')
        setDialogOpen(false)
        setWithdrawForm({ amount: '', method: 'bkash', accountInfo: '' })
        loadAll()
      } else { toast.error(data.error || 'Failed') }
    } catch { toast.error('Failed') } finally { setSubmitting(false) }
  }

  if (loading) return (
    <div className="min-h-screen bg-[#0a0a0f] flex items-center justify-center">
      <Loader2 className="w-8 h-8 animate-spin text-purple-400" />
    </div>
  )

  const totalEarnings = transactions.filter(t => t.type === 'DEPOSIT').reduce((s, t) => s + t.amount, 0)
  const totalSpent = transactions.filter(t => t.type === 'WITHDRAWAL').reduce((s, t) => s + t.amount, 0)
  const pendingWithdrawal = withdrawals.filter(w => w.status === 'PENDING').reduce((s, w) => s + w.amount, 0)

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white">
      <Navbar />
      <div className="container mx-auto px-4 py-8 max-w-5xl">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-white">Wallet</h1>
          <p className="text-white/40 text-sm mt-1">Manage your balance, earnings, and withdrawals</p>
        </div>

        {/* Balance Cards */}
        <div className="grid sm:grid-cols-3 gap-4 mb-8">
          <div className="bg-gradient-to-br from-purple-600/20 to-blue-600/10 border border-purple-500/20 rounded-2xl p-6 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-24 h-24 bg-purple-500/10 rounded-full -translate-y-8 translate-x-8" />
            <Wallet className="w-5 h-5 text-purple-400 mb-3" />
            <p className="text-xs text-white/40 mb-1">Available Balance</p>
            <p className="text-3xl font-bold text-white">${balance.toFixed(2)}</p>
            {pendingWithdrawal > 0 && <p className="text-xs text-yellow-400/70 mt-1">≈ ${pendingWithdrawal.toFixed(2)} pending</p>}
            <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
              <DialogTrigger asChild>
                <Button size="sm" className="mt-4 bg-purple-500/20 hover:bg-purple-500/30 text-purple-300 border-0 rounded-xl text-xs gap-1.5">
                  <Send className="h-3.5 w-3.5" />Withdraw
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-[#0f0f1a] border-white/10 text-white max-w-md">
                <DialogHeader><DialogTitle>Request Withdrawal</DialogTitle></DialogHeader>
                <div className="space-y-4 mt-2">
                  <div>
                    <Label className="text-white/60 text-xs mb-1.5 block">Amount (USD)</Label>
                    <Input value={withdrawForm.amount} onChange={e => setWithdrawForm(p => ({ ...p, amount: e.target.value }))} placeholder="Min $5.00" type="number" min="5" step="0.01" className="bg-white/5 border-white/10 text-white rounded-xl" />
                  </div>
                  <div>
                    <Label className="text-white/60 text-xs mb-1.5 block">Method</Label>
                    <Select value={withdrawForm.method} onValueChange={v => setWithdrawForm(p => ({ ...p, method: v }))}>
                      <SelectTrigger className="bg-white/5 border-white/10 text-white rounded-xl">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-[#0f0f1a] border-white/10">
                        <SelectItem value="bkash" className="text-white/80">bKash</SelectItem>
                        <SelectItem value="nagad" className="text-white/80">Nagad</SelectItem>
                        <SelectItem value="paypal" className="text-white/80">PayPal</SelectItem>
                        <SelectItem value="bank" className="text-white/80">Bank Transfer</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label className="text-white/60 text-xs mb-1.5 block">Account Info</Label>
                    <Input value={withdrawForm.accountInfo} onChange={e => setWithdrawForm(p => ({ ...p, accountInfo: e.target.value }))} placeholder={withdrawForm.method === 'paypal' ? 'email@example.com' : 'Account number / phone'} className="bg-white/5 border-white/10 text-white rounded-xl" />
                  </div>
                  <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-xl p-3 flex items-start gap-2">
                    <AlertTriangle className="w-4 h-4 text-yellow-400 mt-0.5 flex-shrink-0" />
                    <p className="text-xs text-yellow-300/80">Withdrawals are processed within 24-48 hours. The amount will be deducted from your balance immediately.</p>
                  </div>
                  <Button onClick={submitWithdraw} disabled={submitting || balance < 5} className="w-full bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl">
                    {submitting ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Send className="w-4 h-4 mr-2" />}
                    Request Withdrawal
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          <div className="bg-white/[0.03] border border-white/8 rounded-2xl p-6">
            <TrendingUp className="w-5 h-5 text-green-400 mb-3" />
            <p className="text-xs text-white/40 mb-1">Total Deposited</p>
            <p className="text-2xl font-bold text-green-400">+${totalEarnings.toFixed(2)}</p>
            <p className="text-xs text-white/30 mt-2">{transactions.filter(t => t.type === 'DEPOSIT').length} deposits</p>
          </div>

          <div className="bg-white/[0.03] border border-white/8 rounded-2xl p-6">
            <ArrowUpRight className="w-5 h-5 text-red-400 mb-3" />
            <p className="text-xs text-white/40 mb-1">Total Withdrawn</p>
            <p className="text-2xl font-bold text-red-400">-${totalSpent.toFixed(2)}</p>
            <p className="text-xs text-white/30 mt-2">{withdrawals.filter(w => w.status === 'APPROVED').length} completed</p>
          </div>
        </div>

        <Tabs defaultValue="transactions" className="space-y-4">
          <TabsList className="bg-white/5 border border-white/10 rounded-xl p-1 gap-1 h-auto">
            {[['transactions', 'Transactions'], ['withdrawals', 'Withdrawals'], ['memberships', 'Memberships']].map(([v, l]) => (
              <TabsTrigger key={v} value={v} className="rounded-lg text-white/50 data-[state=active]:bg-white/10 data-[state=active]:text-white text-xs px-3 py-2">{l}</TabsTrigger>
            ))}
          </TabsList>

          <TabsContent value="transactions">
            {transactions.length === 0 ? (
              <div className="text-center py-16 bg-white/[0.02] border border-white/5 rounded-2xl">
                <DollarSign className="w-12 h-12 mx-auto text-white/10 mb-3" />
                <p className="text-white/40">No transactions yet</p>
                <Button onClick={() => router.push('/payment')} className="mt-4 bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl text-sm">Add Funds</Button>
              </div>
            ) : (
              <div className="space-y-2">
                {transactions.map(tx => (
                  <div key={tx.id} className="flex items-center gap-3 bg-white/[0.03] border border-white/8 rounded-xl p-4">
                    <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${tx.type === 'DEPOSIT' ? 'bg-green-500/10' : 'bg-red-500/10'}`}>
                      {tx.type === 'DEPOSIT' ? <ArrowDownLeft className="w-4 h-4 text-green-400" /> : <ArrowUpRight className="w-4 h-4 text-red-400" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-white capitalize font-medium">{tx.method} {tx.type.toLowerCase()}</p>
                      <p className="text-xs text-white/30">{new Date(tx.createdAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' })}</p>
                    </div>
                    <div className="text-right">
                      <p className={`font-bold text-sm ${tx.type === 'DEPOSIT' ? 'text-green-400' : 'text-red-400'}`}>{tx.type === 'DEPOSIT' ? '+' : '-'}${tx.amount.toFixed(2)}</p>
                      <Badge className={`text-[10px] ${STATUS_COLORS[tx.status] || 'bg-white/5 text-white/40'}`}>{tx.status}</Badge>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="withdrawals">
            <div className="flex items-center justify-between mb-4">
              <p className="text-sm text-white/40">{withdrawals.length} withdrawal request{withdrawals.length !== 1 ? 's' : ''}</p>
              <Button onClick={() => setDialogOpen(true)} size="sm" className="bg-purple-500/20 hover:bg-purple-500/30 text-purple-300 border-0 rounded-xl text-xs gap-1.5">
                <Plus className="h-3.5 w-3.5" />New Request
              </Button>
            </div>
            {withdrawals.length === 0 ? (
              <div className="text-center py-16 bg-white/[0.02] border border-white/5 rounded-2xl">
                <Send className="w-12 h-12 mx-auto text-white/10 mb-3" />
                <p className="text-white/40">No withdrawal requests yet</p>
              </div>
            ) : (
              <div className="space-y-2">
                {withdrawals.map(wd => (
                  <div key={wd.id} className="bg-white/[0.03] border border-white/8 rounded-xl p-4">
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-center gap-3">
                        <div className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 ${wd.status === 'PENDING' ? 'bg-yellow-500/10' : wd.status === 'APPROVED' ? 'bg-green-500/10' : 'bg-red-500/10'}`}>
                          {wd.status === 'PENDING' ? <Clock className="w-4 h-4 text-yellow-400" /> : wd.status === 'APPROVED' ? <CheckCircle className="w-4 h-4 text-green-400" /> : <XCircle className="w-4 h-4 text-red-400" />}
                        </div>
                        <div>
                          <p className="text-sm text-white font-medium capitalize">{wd.method} withdrawal</p>
                          <p className="text-xs text-white/30">{wd.accountInfo} · {new Date(wd.createdAt).toLocaleDateString()}</p>
                          {wd.adminNote && <p className="text-xs text-white/50 mt-1 italic">"{wd.adminNote}"</p>}
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-white">${wd.amount.toFixed(2)}</p>
                        <Badge className={`text-[10px] ${STATUS_COLORS[wd.status] || ''}`}>{wd.status}</Badge>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="memberships">
            {memberships.length === 0 ? (
              <div className="text-center py-16 bg-white/[0.02] border border-white/5 rounded-2xl">
                <Star className="w-12 h-12 mx-auto text-white/10 mb-3" />
                <p className="text-white/40 mb-4">No membership plans available</p>
              </div>
            ) : (
              <div className="grid sm:grid-cols-3 gap-4">
                {memberships.map(m => (
                  <div key={m.id} className={`relative bg-white/[0.03] border rounded-2xl p-6 ${m.owned ? 'border-purple-500/30' : 'border-white/8'}`}>
                    {m.owned && <Badge className="absolute top-3 right-3 text-[10px] bg-purple-500/20 text-purple-400 border-purple-500/30">Active</Badge>}
                    <Zap className="w-5 h-5 text-purple-400 mb-3" />
                    <h3 className="font-bold text-white mb-1">{m.name}</h3>
                    <p className="text-2xl font-bold text-purple-300 mb-3">${m.price.toFixed(2)}<span className="text-sm text-white/30 font-normal">/mo</span></p>
                    {m.description && <p className="text-xs text-white/40 mb-4">{m.description}</p>}
                    {!m.owned && <Button size="sm" className="w-full bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl text-xs">Subscribe</Button>}
                  </div>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
      <Footer />
    </div>
  )
}
