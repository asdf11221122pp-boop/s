'use client'

import { useState, useEffect } from 'react'
import { use } from 'react'
import { useRouter } from 'next/navigation'
import { useSession } from 'next-auth/react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Label } from '@/components/ui/label'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Loader2 } from 'lucide-react'

interface Plan {
  id: string
  name: string
  description: string
  price: number
  features?: string[]
  specs?: Record<string, any>
  isActive: boolean
  sortOrder: number
}

interface CheckoutPageProps {
  params: Promise<{
    planId: string
  }>
}

export default function CheckoutPage({ params: paramsProm }: CheckoutPageProps) {
  const { planId } = use(paramsProm)
  const { data: session, status } = useSession()
  const router = useRouter()
  const [plan, setPlan] = useState<Plan | null>(null)
  const [paymentMethod, setPaymentMethod] = useState('bkash')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  useEffect(() => {
    if (status === 'authenticated') {
      fetchPlan()
    } else if (status === 'unauthenticated') {
      router.push('/auth/signin')
    }
  }, [status])

  const fetchPlan = async () => {
    try {
      const res = await fetch('/api/admin/plans?public=true')
      const data = await res.json()
      const found = Array.isArray(data.plans)
        ? data.plans.find((p: Plan) => p.id === planId)
        : null
      setPlan(found || null)
    } catch (err) {
      console.error('Failed to load plan', err)
    }
  }

  const handleCheckout = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!plan) return
    setLoading(true)
    setError('')

    try {
      const res = await fetch('/api/vps-orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          planId: plan.id,
          paymentMethod,
          amount: plan.price
        })
      })
      if (!res.ok) throw new Error('Unable to create order')
      const data = await res.json()
      router.push(`/vps/payment/${data.order.id}`)
    } catch (err: any) {
      setError(err.message || 'Something went wrong')
    } finally {
      setLoading(false)
    }
  }

  if (status === 'loading' || !plan) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <div className="flex-1 flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin" />
        </div>
        <Footer />
      </div>
    )
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <div className="flex-1 container mx-auto px-4 py-16">
        <div className="max-w-md mx-auto">
          <Card>
            <CardHeader>
              <CardTitle>Checkout: {plan.name}</CardTitle>
              <CardDescription>Select a payment method to proceed.</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleCheckout} className="space-y-4">
                <div>
                  <Label>Amount</Label>
                  <Input value={`$${plan.price}`} disabled />
                </div>

                <div className="space-y-3">
                  <Label>Payment Method</Label>
                  <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod}>
                    <div className="flex items-center gap-2">
                      <RadioGroupItem value="bkash" id="bkash" />
                      <label htmlFor="bkash" className="cursor-pointer">
                        bKash
                      </label>
                    </div>
                    <div className="flex items-center gap-2">
                      <RadioGroupItem value="nagad" id="nagad" />
                      <label htmlFor="nagad" className="cursor-pointer">
                        Nagad
                      </label>
                    </div>
                    <div className="flex items-center gap-2">
                      <RadioGroupItem value="wallet" id="wallet" />
                      <label htmlFor="wallet" className="cursor-pointer">
                        Wallet
                      </label>
                    </div>
                  </RadioGroup>
                </div>

                {error && (
                  <Alert variant="destructive">
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}

                <Button type="submit" disabled={loading} className="w-full">
                  {loading ? 'Creating order...' : 'Continue'}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
      <Footer />
    </div>
  )
}
