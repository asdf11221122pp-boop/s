'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { User, Mail, Globe, Github, Twitter, Edit, Camera, MessageCircle, Upload, Package, Star, Download, Heart, CheckCircle, Shield, Loader2, X, Save, TrendingUp, Award, Trophy, Crown, Zap, ShieldCheck } from 'lucide-react'
import { toast } from 'sonner'
import Link from 'next/link'

interface UserBadge {
  id: string; badgeId: string; isEquipped: boolean; claimedAt: string
  badge: { id: string; name: string; icon: string | null; color: string; description?: string | null }
}

interface UserProfile {
  id: string; username: string; email: string; role: string; avatar?: string
  bio?: string; isVerified: boolean; sellerLevel: number; totalSales: number; walletBalance: number; createdAt: string
  socialLinks?: { website?: string; github?: string; twitter?: string; discord?: string }
  _count: { items: number; followers: number; following: number; reviews: number; downloads: number }
  items?: any[]
  badges?: string[]
  badgeDetails?: { id: string; name: string; icon: string | null; color: string; description?: string | null }[]
  userBadges?: UserBadge[]
  membership?: { id: string; name: string; color: string; features: any } | null
  lastRewardClaim?: string | null
}

interface LeaderboardData {
  topSellers: { id: string; username: string; avatar?: string; totalSales: number; _count: { items: number } }[]
  topItems: { id: string; title: string; slug: string; downloads: number; views: number; logo?: string; price: number; author: { username: string } }[]
}

const LEVEL_NAMES = ['', 'Starter', 'Rising', 'Pro', 'Elite', 'Legend']
const LEVEL_COLORS = ['', 'text-gray-400', 'text-blue-400', 'text-purple-400', 'text-orange-400', 'text-yellow-400']
const LEVEL_BG = ['', 'bg-gray-500/10 border-gray-500/20', 'bg-blue-500/10 border-blue-500/20', 'bg-purple-500/10 border-purple-500/20', 'bg-orange-500/10 border-orange-500/20', 'bg-yellow-500/10 border-yellow-500/20']

export default function ProfilePage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [profile, setProfile] = useState<UserProfile | null>(null)
  const [leaderboard, setLeaderboard] = useState<LeaderboardData | null>(null)
  const [loading, setLoading] = useState(true)
  const [editing, setEditing] = useState(false)
  const [saving, setSaving] = useState(false)
  const [uploadingAvatar, setUploadingAvatar] = useState(false)
  const [form, setForm] = useState({ bio: '', website: '', github: '', twitter: '', discord: '' })
  const [togglingBadge, setTogglingBadge] = useState<string | null>(null)

  useEffect(() => {
    if (status === 'unauthenticated') router.push('/auth/signin')
    if (status === 'authenticated') loadProfile()
  }, [status])

  const loadProfile = async () => {
    setLoading(true)
    try {
      const [profileRes, itemsRes] = await Promise.all([
        fetch('/api/users/me'),
        fetch('/api/items?authorId=me&limit=12')
      ])
      // Pre-load leaderboard data so it's ready when tab is clicked
      fetch('/api/leaderboard').then(res => {
        if (res.ok) res.json().then(data => setLeaderboard(data))
      }).catch(() => {})
      if (profileRes.ok) {
        const data = await profileRes.json()
        setProfile(data)
        setForm({
          bio: data.bio || '',
          website: data.socialLinks?.website || '',
          github: data.socialLinks?.github || '',
          twitter: data.socialLinks?.twitter || '',
          discord: data.socialLinks?.discord || ''
        })
        if (itemsRes.ok) {
          const itemsData = await itemsRes.json()
          setProfile(p => p ? { ...p, items: itemsData.items || [] } : null)
        }
      }
    } catch { toast.error('Failed to load profile') }
    finally { setLoading(false) }
  }

  const loadLeaderboard = async () => {
    if (leaderboard) return
    const res = await fetch('/api/leaderboard')
    if (res.ok) { const data = await res.json(); setLeaderboard(data) }
  }

  const saveProfile = async () => {
    setSaving(true)
    try {
      const socialLinks = {
        website: form.website?.trim() || null,
        github: form.github?.trim() || null,
        twitter: form.twitter?.trim() || null,
        discord: form.discord?.trim() || null,
      }
      const res = await fetch('/api/profile', {
        method: 'PATCH', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ bio: form.bio?.trim() || '', socialLinks })
      })
      const responseData = await res.json()
      if (res.ok) {
        toast.success('Profile updated!')
        setEditing(false)
        setForm({
          bio: responseData.bio || '',
          website: responseData.socialLinks?.website || '',
          github: responseData.socialLinks?.github || '',
          twitter: responseData.socialLinks?.twitter || '',
          discord: responseData.socialLinks?.discord || ''
        })
        await loadProfile()
      } else {
        toast.error(responseData.error || 'Failed to update profile')
      }
    } catch { toast.error('Failed to save profile') }
    finally { setSaving(false) }
  }

  const uploadAvatar = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    setUploadingAvatar(true)
    try {
      const formData = new FormData()
      formData.append('file', file)
      formData.append('type', 'avatar')
      const res = await fetch('/api/upload', { method: 'POST', body: formData })
      if (res.ok) {
        const data = await res.json()
        await fetch('/api/profile', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ avatar: data.url }) })
        toast.success('Avatar updated!')
        loadProfile()
      }
    } catch { toast.error('Upload failed') }
    finally { setUploadingAvatar(false) }
  }

  const toggleBadge = async (badgeId: string, isEquipped: boolean) => {
    setTogglingBadge(badgeId)
    try {
      const res = await fetch('/api/badges/manage', {
        method: 'PATCH', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ badgeId, action: isEquipped ? 'remove' : 'equip' })
      })
      if (res.ok) {
        toast.success(isEquipped ? 'Badge removed from profile' : 'Badge equipped to profile!')
        setProfile(p => p ? {
          ...p,
          userBadges: p.userBadges?.map(ub => ub.badgeId === badgeId ? { ...ub, isEquipped: !isEquipped } : ub)
        } : null)
      } else {
        const data = await res.json()
        toast.error(data.error || 'Failed')
      }
    } catch { toast.error('Failed to toggle badge') }
    finally { setTogglingBadge(null) }
  }

  if (loading) return (
    <div className="min-h-screen bg-[#0a0a0f] flex items-center justify-center">
      <Loader2 className="w-8 h-8 animate-spin text-purple-400" />
    </div>
  )

  if (!profile) return null

  const level = profile.sellerLevel || 1
  const isCreator = ['CREATOR', 'ADMIN', 'SUPER_ADMIN', 'MODERATOR'].includes(profile.role)
  const equippedBadges = profile.userBadges?.filter(ub => ub.isEquipped) || []
  const allBadges = profile.userBadges || []

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white">
      <Navbar />

      <div className="relative h-40 md:h-52 bg-gradient-to-br from-purple-900/40 via-blue-900/20 to-[#0a0a0f] border-b border-white/5 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0f] via-transparent to-transparent" />
      </div>

      <div className="container mx-auto px-4 max-w-5xl -mt-16 pb-8 relative">
        <div className="bg-[#0f0f1a] border border-white/10 rounded-2xl p-6 mb-6">
          <div className="flex items-start justify-between flex-wrap gap-4">
            <div className="flex items-end gap-4">
              <div className="relative group">
                <div className="w-20 h-20 rounded-2xl border-2 border-purple-500/30 overflow-hidden bg-gradient-to-br from-purple-900 to-blue-900">
                  {profile.avatar ? <img src={profile.avatar} alt={profile.username} className="w-full h-full object-cover" /> : (
                    <div className="w-full h-full flex items-center justify-center"><User className="w-8 h-8 text-white/30" /></div>
                  )}
                </div>
                <label className="absolute inset-0 flex items-center justify-center bg-black/50 rounded-2xl cursor-pointer opacity-0 group-hover:opacity-100 transition-opacity">
                  {uploadingAvatar ? <Loader2 className="w-5 h-5 animate-spin text-white" /> : <Camera className="w-5 h-5 text-white" />}
                  <input type="file" accept="image/*" onChange={uploadAvatar} className="hidden" />
                </label>
              </div>
              <div className="pb-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <h1 className="text-xl font-bold text-white">{profile.username}</h1>
                  {profile.isVerified && <CheckCircle className="w-4 h-4 text-blue-400" />}
                  {isCreator && (
                    <Badge className={`text-[10px] border ${LEVEL_BG[level]}`}>
                      <Award className={`w-3 h-3 mr-1 ${LEVEL_COLORS[level]}`} />
                      <span className={LEVEL_COLORS[level]}>Level {level} · {LEVEL_NAMES[level]}</span>
                    </Badge>
                  )}
                  {profile.membership && (
                    <Badge className="text-[10px] border" style={{ backgroundColor: `${profile.membership.color}20`, borderColor: `${profile.membership.color}40`, color: profile.membership.color }}>
                      <Crown className="w-3 h-3 mr-1" />
                      {profile.membership.name}
                    </Badge>
                  )}
                </div>
                <p className="text-sm text-white/40">{profile.email}</p>
                <p className="text-xs text-white/30 mt-0.5 capitalize">{profile.role.toLowerCase().replace('_', ' ')} · Since {new Date(profile.createdAt).toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}</p>
              </div>
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              <Button onClick={() => setEditing(!editing)} size="sm" className="bg-white/5 hover:bg-white/10 text-white/80 border border-white/10 rounded-xl gap-1.5 text-xs">
                {editing ? <><X className="h-3.5 w-3.5" />Cancel</> : <><Edit className="h-3.5 w-3.5" />Edit Profile</>}
              </Button>
              {isCreator && <Link href="/upload"><Button size="sm" className="bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl gap-1.5 text-xs"><Upload className="h-3.5 w-3.5" />Upload</Button></Link>}
            </div>
          </div>

          {!editing && profile.bio && <p className="text-sm text-white/60 mt-4 max-w-2xl">{profile.bio}</p>}

          {!editing && (
            <div className="flex items-center gap-3 mt-3 flex-wrap">
              {profile.socialLinks?.website && <a href={profile.socialLinks.website} target="_blank" rel="noreferrer" className="flex items-center gap-1.5 text-xs text-white/40 hover:text-white/70 transition-colors"><Globe className="h-3.5 w-3.5" />{profile.socialLinks.website.replace(/^https?:\/\//, '')}</a>}
              {profile.socialLinks?.github && <a href={`https://github.com/${profile.socialLinks.github}`} target="_blank" rel="noreferrer" className="flex items-center gap-1.5 text-xs text-white/40 hover:text-white/70"><Github className="h-3.5 w-3.5" />{profile.socialLinks.github}</a>}
              {profile.socialLinks?.twitter && <a href={`https://twitter.com/${profile.socialLinks.twitter}`} target="_blank" rel="noreferrer" className="flex items-center gap-1.5 text-xs text-white/40 hover:text-white/70"><Twitter className="h-3.5 w-3.5" />@{profile.socialLinks.twitter}</a>}
            </div>
          )}

          {!editing && equippedBadges.length > 0 && (
            <div className="flex items-center gap-2 mt-3 flex-wrap">
              {equippedBadges.map(ub => (
                <span key={ub.id} title={ub.badge.name} className="text-xl cursor-default" style={{ filter: 'drop-shadow(0 0 4px currentColor)' }}>
                  {ub.badge.icon || '⭐'}
                </span>
              ))}
            </div>
          )}

          {editing && (
            <div className="mt-5 grid sm:grid-cols-2 gap-4">
              <div className="sm:col-span-2">
                <Label className="text-white/60 text-xs mb-1.5 block">Bio</Label>
                <Textarea value={form.bio} onChange={e => setForm(p => ({ ...p, bio: e.target.value }))} placeholder="Tell the community about yourself..." className="bg-white/5 border-white/10 text-white resize-none rounded-xl text-sm" rows={3} />
              </div>
              {[['website', 'Website URL', Globe], ['github', 'GitHub username', Github], ['twitter', 'Twitter username', Twitter], ['discord', 'Discord username', MessageCircle]].map(([key, ph, Icon]: any) => (
                <div key={key}>
                  <Label className="text-white/60 text-xs mb-1.5 block capitalize">{ph}</Label>
                  <div className="relative">
                    <Icon className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/30" />
                    <Input value={(form as any)[key]} onChange={e => setForm(p => ({ ...p, [key]: e.target.value }))} placeholder={ph} className="pl-9 bg-white/5 border-white/10 text-white rounded-xl text-sm" />
                  </div>
                </div>
              ))}
              <div className="sm:col-span-2 flex justify-end">
                <Button onClick={saveProfile} disabled={saving} className="bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl gap-2">
                  {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}Save Changes
                </Button>
              </div>
            </div>
          )}

          <div className="grid grid-cols-3 sm:grid-cols-5 gap-3 mt-5 pt-4 border-t border-white/5">
            {[
              { label: 'Items', value: profile._count.items, icon: Package, color: 'text-purple-400' },
              { label: 'Followers', value: profile._count.followers, icon: Heart, color: 'text-pink-400' },
              { label: 'Following', value: profile._count.following, icon: User, color: 'text-blue-400' },
              { label: 'Sales', value: profile.totalSales, icon: TrendingUp, color: 'text-green-400' },
              { label: 'Reviews', value: profile._count.reviews, icon: Star, color: 'text-yellow-400' },
            ].map(stat => (
              <div key={stat.label} className="text-center">
                <stat.icon className={`w-4 h-4 mx-auto mb-1 ${stat.color}`} />
                <p className="text-lg font-bold text-white">{stat.value >= 1000 ? (stat.value / 1000).toFixed(1) + 'K' : stat.value}</p>
                <p className="text-[10px] text-white/30">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>

        <Tabs defaultValue="badges" onValueChange={(v) => { if (v === 'leaderboard') loadLeaderboard() }}>
          <TabsList className="bg-white/5 border border-white/10 rounded-xl p-1 gap-1 h-auto mb-5 flex-wrap">
            {[['badges', 'Badges', Award], ['items', 'My Items', Package], ['leaderboard', 'Leaderboard', Trophy], ['activity', 'Activity', TrendingUp]].map(([v, l, _Icon]: any) => (
              <TabsTrigger key={v} value={v} className="rounded-lg text-white/50 data-[state=active]:bg-white/10 data-[state=active]:text-white text-xs px-3 py-2">{l}</TabsTrigger>
            ))}
          </TabsList>

          <TabsContent value="badges">
            <div className="bg-white/[0.02] border border-white/5 rounded-2xl p-5">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Award className="h-5 w-5 text-purple-400" />
                  <h2 className="text-sm font-semibold text-white/80">Badges Collection</h2>
                  <span className="text-xs text-white/30">({allBadges.length} earned)</span>
                </div>
                <Link href="/badges">
                  <Button size="sm" variant="ghost" className="text-purple-400 text-xs h-7">Claim More →</Button>
                </Link>
              </div>

              {allBadges.length === 0 ? (
                <div className="text-center py-10">
                  <Award className="w-12 h-12 mx-auto text-white/10 mb-3" />
                  <p className="text-white/30 mb-2">No badges yet</p>
                  <Link href="/badges"><Button size="sm" className="bg-purple-600 text-white border-0 text-xs">Claim Badges</Button></Link>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {allBadges.map(ub => (
                    <div key={ub.id} className={`relative flex items-center gap-3 p-3 rounded-xl border transition-all ${ub.isEquipped ? 'border-purple-500/40 bg-purple-500/5' : 'border-white/8 bg-white/[0.02]'}`}
                      style={{ borderColor: ub.isEquipped ? `${ub.badge.color}50` : undefined }}>
                      <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 text-xl"
                        style={{ backgroundColor: `${ub.badge.color}20`, border: `1px solid ${ub.badge.color}30` }}>
                        {ub.badge.icon || '⭐'}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <p className="text-xs font-semibold text-white/90 truncate">{ub.badge.name}</p>
                          {ub.isEquipped && <span className="text-[9px] text-purple-300 bg-purple-500/15 px-1.5 py-0.5 rounded-full">Equipped</span>}
                        </div>
                        {ub.badge.description && <p className="text-[10px] text-white/40 mt-0.5 line-clamp-1">{ub.badge.description}</p>}
                        <p className="text-[10px] text-white/20 mt-0.5">Claimed {new Date(ub.claimedAt).toLocaleDateString()}</p>
                      </div>
                      <Button size="sm" onClick={() => toggleBadge(ub.badgeId, ub.isEquipped)}
                        disabled={togglingBadge === ub.badgeId}
                        className={`h-7 px-2.5 text-[10px] font-medium rounded-lg border-0 flex-shrink-0 ${ub.isEquipped ? 'bg-red-500/10 text-red-400 hover:bg-red-500/20' : 'bg-purple-500/15 text-purple-300 hover:bg-purple-500/30'}`}>
                        {togglingBadge === ub.badgeId ? <Loader2 className="w-3 h-3 animate-spin" /> : ub.isEquipped ? 'Remove' : 'Equip'}
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="items">
            {!profile.items || profile.items.length === 0 ? (
              <div className="text-center py-16 bg-white/[0.02] border border-white/5 rounded-2xl">
                <Package className="w-12 h-12 mx-auto text-white/10 mb-3" />
                <p className="text-white/40 mb-2">No items uploaded yet</p>
                {isCreator && <Link href="/upload"><Button className="mt-2 bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl text-sm">Upload First Item</Button></Link>}
              </div>
            ) : (
              <div className="grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {profile.items.map((item: any) => (
                  <Link key={item.id} href={`/items/${item.slug}`}>
                    <div className="group bg-white/[0.03] hover:bg-white/[0.06] border border-white/8 hover:border-purple-500/20 rounded-2xl overflow-hidden transition-all">
                      <div className="h-28 bg-gradient-to-br from-purple-900/20 to-blue-900/10 flex items-center justify-center border-b border-white/5 overflow-hidden">
                        {item.logo ? <img src={item.logo} alt={item.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform" /> : <Package className="w-8 h-8 text-white/10" />}
                      </div>
                      <div className="p-3">
                        <h3 className="text-sm font-medium text-white/90 line-clamp-1 group-hover:text-purple-300 transition-colors">{item.title}</h3>
                        <div className="flex items-center justify-between mt-2">
                          <div className="flex items-center gap-2 text-xs text-white/30">
                            <span className="flex items-center gap-1"><Download className="h-3 w-3" />{item.downloads || 0}</span>
                          </div>
                          <span className={`text-xs font-bold ${item.price === 0 ? 'text-green-400' : 'text-white/70'}`}>{item.price === 0 ? 'Free' : `$${item.price.toFixed(2)}`}</span>
                        </div>
                        <Badge className={`mt-1.5 text-[9px] h-4 ${item.status === 'APPROVED' ? 'bg-green-500/10 text-green-400 border-green-500/20' : item.status === 'PENDING' ? 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20' : 'bg-red-500/10 text-red-400 border-red-500/20'}`}>{item.status}</Badge>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="leaderboard">
            <div className="space-y-6">
              <div className="bg-white/[0.02] border border-white/5 rounded-2xl p-5">
                <div className="flex items-center gap-2 mb-4">
                  <Trophy className="w-5 h-5 text-yellow-400" />
                  <h2 className="text-sm font-semibold text-white/80">Top Sellers</h2>
                </div>
                {!leaderboard ? (
                  <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 animate-spin text-purple-400" /></div>
                ) : leaderboard.topSellers.length === 0 ? (
                  <p className="text-white/30 text-sm text-center py-6">No sellers yet</p>
                ) : (
                  <div className="space-y-2">
                    {leaderboard.topSellers.map((seller, idx) => (
                      <div key={seller.id} className={`flex items-center gap-3 p-3 rounded-xl ${idx < 3 ? 'bg-white/[0.03] border border-white/8' : ''}`}>
                        <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 ${idx === 0 ? 'bg-yellow-500/20 text-yellow-400' : idx === 1 ? 'bg-gray-400/20 text-gray-300' : idx === 2 ? 'bg-orange-500/20 text-orange-400' : 'bg-white/5 text-white/40'}`}>
                          {idx + 1}
                        </div>
                        <Avatar className="w-8 h-8">
                          <AvatarImage src={seller.avatar} />
                          <AvatarFallback className="text-xs bg-purple-500/20">{seller.username[0].toUpperCase()}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <p className={`text-sm font-medium truncate ${seller.id === profile.id ? 'text-purple-300' : 'text-white/80'}`}>
                            {seller.username} {seller.id === profile.id && <span className="text-[10px] text-purple-400">(you)</span>}
                          </p>
                          <p className="text-[10px] text-white/30">{seller._count.items} items</p>
                        </div>
                        <div className="text-right flex-shrink-0">
                          <p className="text-sm font-bold text-green-400">{seller.totalSales}</p>
                          <p className="text-[10px] text-white/30">sales</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="bg-white/[0.02] border border-white/5 rounded-2xl p-5">
                <div className="flex items-center gap-2 mb-4">
                  <Download className="w-5 h-5 text-blue-400" />
                  <h2 className="text-sm font-semibold text-white/80">Most Downloaded</h2>
                </div>
                {!leaderboard ? (
                  <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 animate-spin text-purple-400" /></div>
                ) : leaderboard.topItems.length === 0 ? (
                  <p className="text-white/30 text-sm text-center py-6">No items yet</p>
                ) : (
                  <div className="space-y-2">
                    {leaderboard.topItems.map((item, idx) => (
                      <Link key={item.id} href={`/items/${item.slug}`}>
                        <div className="flex items-center gap-3 p-3 rounded-xl hover:bg-white/[0.03] transition-colors">
                          <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 ${idx === 0 ? 'bg-yellow-500/20 text-yellow-400' : idx === 1 ? 'bg-gray-400/20 text-gray-300' : idx === 2 ? 'bg-orange-500/20 text-orange-400' : 'bg-white/5 text-white/40'}`}>
                            {idx + 1}
                          </div>
                          <div className="w-8 h-8 rounded-lg overflow-hidden bg-white/5 flex-shrink-0">
                            {item.logo ? <img src={item.logo} alt="" className="w-full h-full object-cover" /> : <Package className="w-4 h-4 m-2 text-white/20" />}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm text-white/80 truncate">{item.title}</p>
                            <p className="text-[10px] text-white/30">by {item.author.username}</p>
                          </div>
                          <div className="text-right flex-shrink-0">
                            <p className="text-sm font-bold text-blue-400">{item.downloads}</p>
                            <p className="text-[10px] text-white/30">downloads</p>
                          </div>
                        </div>
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="activity">
            <div className="text-center py-16 bg-white/[0.02] border border-white/5 rounded-2xl">
              <TrendingUp className="w-12 h-12 mx-auto text-white/10 mb-3" />
              <p className="text-white/40">Activity feed coming soon</p>
            </div>
          </TabsContent>
        </Tabs>
      </div>
      <Footer />
    </div>
  )
}
