'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Loader2, Lock, ArrowLeft } from 'lucide-react'
import { toast } from 'sonner'

export default function ResetPassword() {
  const [password, setPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [token, setToken] = useState<string | null>(null)
  const router = useRouter()

  useEffect(() => {
    if (typeof window === 'undefined') return

    const params = new URLSearchParams(window.location.search)
    const tokenParam = params.get('token')

    if (!tokenParam) {
      toast.error('Reset token missing')
      router.push('/auth/forgot-password')
      return
    }

    setToken(tokenParam)
  }, [router])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (password !== confirmPassword) {
      toast.error('Passwords do not match')
      return
    }

    setIsLoading(true)

    if (!token) {
      toast.error('Reset token missing')
      return
    }

    try {
      const res = await fetch('/api/auth/reset-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token, password })
      })
      const data = await res.json()

      if (res.ok && data.success) {
        toast.success('Password reset successfully')
        setSuccess(true)
      } else {
        toast.error(data.error || 'Failed to reset password')
      }
    } catch (error) {
      toast.error('An error occurred')
    } finally {
      setIsLoading(false)
    }
  }

  if (success) {
    return (
      <div className="min-h-screen bg-[#0a0a0f] flex items-center justify-center">
        <div className="bg-white/5 p-8 rounded-xl shadow-lg border border-white/10">
          <h2 className="text-white text-xl font-bold mb-4">Password updated</h2>
          <p className="text-white/70 mb-4">You can now sign in with your new password.</p>
          <Link href="/auth/signin">
            <Button>Go to Sign in</Button>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-[#0a0a0f] flex items-center justify-center">
      <div className="bg-white/5 p-8 rounded-xl shadow-lg border border-white/10 w-full max-w-md">
        <h1 className="text-3xl font-bold text-white mb-5">Reset password</h1>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label className="text-white/70 text-sm">New password</Label>
            <Input
              type="password"
              value={password}
              onChange={e => setPassword(e.target.value)}
              required
              className="mt-2"
            />
          </div>
          <div>
            <Label className="text-white/70 text-sm">Confirm password</Label>
            <Input
              type="password"
              value={confirmPassword}
              onChange={e => setConfirmPassword(e.target.value)}
              required
              className="mt-2"
            />
          </div>
          <div className="flex gap-2">
            <Button
              type="submit"
              disabled={isLoading}
              className="flex items-center gap-2"
            >
              {isLoading ? <Loader2 className="animate-spin w-4 h-4" /> : <Lock className="w-4 h-4" />}
              Reset password
            </Button>
            <Link href="/auth/signin" className="inline-flex items-center gap-1 text-sm text-purple-400 self-center">
              <ArrowLeft className="w-3.5 h-3.5" />
              Sign in
            </Link>
          </div>
        </form>
      </div>
    </div>
  )
}
