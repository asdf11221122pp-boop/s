'use client'

import { Suspense, useState, useEffect } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { signIn } from 'next-auth/react'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Eye, EyeOff, Loader2, Zap, UserPlus, Check, Gift } from 'lucide-react'

function SignUpForm() {
  const [formData, setFormData] = useState({ email: '', username: '', password: '', confirmPassword: '', referralCode: '' })
  const [showPass, setShowPass] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState('')
  const router = useRouter()
  const searchParams = useSearchParams()

  useEffect(() => {
    const ref = searchParams.get('ref')
    if (ref) setFormData(prev => ({ ...prev, referralCode: ref }))
  }, [searchParams])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError('')

    if (!formData.email || !formData.username || !formData.password || !formData.confirmPassword) {
      setError('Please fill in all fields'); setIsLoading(false); return
    }
    if (formData.password.length < 6) {
      setError('Password must be at least 6 characters'); setIsLoading(false); return
    }
    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match'); setIsLoading(false); return
    }
    if (formData.username.length < 3) {
      setError('Username must be at least 3 characters'); setIsLoading(false); return
    }

    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: formData.email, username: formData.username, password: formData.password, referralCode: formData.referralCode || undefined })
      })
      const data = await res.json()
      if (!res.ok) {
        setError(data.error || 'Registration failed')
      } else {
        const result = await signIn('credentials', { email: formData.email, password: formData.password, redirect: false })
        if (result?.ok) { router.push('/'); router.refresh() }
        else router.push('/auth/signin')
      }
    } catch {
      setError('An error occurred. Please try again.')
    } finally {
      setIsLoading(false)
    }
  }

  const perks = ['Free account forever', 'Upload & sell content', 'Join the community', 'Real-time messaging']

  return (
    <div className="min-h-screen bg-[#0a0a0f] flex items-center justify-center relative overflow-hidden px-4 py-8">
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff08_1px,transparent_1px),linear-gradient(to_bottom,#ffffff08_1px,transparent_1px)] bg-[size:32px_32px]" />
      <div className="absolute top-1/3 left-1/4 w-80 h-80 bg-purple-600/20 rounded-full blur-3xl" />
      <div className="absolute bottom-1/3 right-1/4 w-80 h-80 bg-blue-600/20 rounded-full blur-3xl" />

      <div className="relative z-10 w-full max-w-md">
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center gap-2 mb-6">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center shadow-lg shadow-purple-500/30">
              <Zap className="w-5 h-5 text-white" />
            </div>
            <span className="text-2xl font-bold text-white">GfxStore</span>
          </Link>
          <h1 className="text-3xl font-bold text-white mb-2">Create your account</h1>
          <p className="text-white/50 text-sm">Join thousands of Minecraft creators</p>
        </div>

        {/* Perks */}
        <div className="grid grid-cols-2 gap-2 mb-6">
          {perks.map(perk => (
            <div key={perk} className="flex items-center gap-2 bg-white/5 rounded-lg px-3 py-2">
              <Check className="w-3 h-3 text-green-400 flex-shrink-0" />
              <span className="text-xs text-white/60">{perk}</span>
            </div>
          ))}
        </div>

        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-8 shadow-2xl">
          {error && (
            <div className="mb-6 p-3 bg-red-500/10 border border-red-500/30 rounded-xl text-sm text-red-400 text-center">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label className="text-white/70 text-sm font-medium">Email address</Label>
              <Input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                placeholder="you@example.com"
                className="h-11 bg-white/5 border-white/10 text-white placeholder:text-white/30 focus:border-purple-500 rounded-xl"
                required
              />
            </div>

            <div className="space-y-2">
              <Label className="text-white/70 text-sm font-medium">Username</Label>
              <Input
                type="text"
                name="username"
                value={formData.username}
                onChange={handleChange}
                placeholder="coolcreator"
                className="h-11 bg-white/5 border-white/10 text-white placeholder:text-white/30 focus:border-purple-500 rounded-xl"
                required
              />
            </div>

            <div className="space-y-2">
              <Label className="text-white/70 text-sm font-medium">Password</Label>
              <div className="relative">
                <Input
                  type={showPass ? 'text' : 'password'}
                  name="password"
                  value={formData.password}
                  onChange={handleChange}
                  placeholder="Min 6 characters"
                  className="h-11 bg-white/5 border-white/10 text-white placeholder:text-white/30 focus:border-purple-500 rounded-xl pr-10"
                  required
                />
                <button type="button" onClick={() => setShowPass(!showPass)} className="absolute right-3 top-1/2 -translate-y-1/2 text-white/30 hover:text-white/70">
                  {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="space-y-2">
              <Label className="text-white/70 text-sm font-medium">Confirm password</Label>
              <Input
                type="password"
                name="confirmPassword"
                value={formData.confirmPassword}
                onChange={handleChange}
                placeholder="••••••••"
                className="h-11 bg-white/5 border-white/10 text-white placeholder:text-white/30 focus:border-purple-500 rounded-xl"
                required
              />
            </div>

            <div className="space-y-2">
              <Label className="text-white/70 text-sm font-medium flex items-center gap-1.5">
                <Gift className="w-3.5 h-3.5 text-purple-400" />
                Referral Code <span className="text-white/30 text-xs">(optional)</span>
              </Label>
              <Input
                type="text"
                name="referralCode"
                value={formData.referralCode}
                onChange={handleChange}
                placeholder="Enter referral code for $2 bonus"
                className="h-11 bg-purple-500/5 border-purple-500/20 text-white placeholder:text-white/30 focus:border-purple-500 rounded-xl"
              />
              {formData.referralCode && (
                <p className="text-[10px] text-purple-400/70 flex items-center gap-1">
                  <Check className="w-3 h-3" /> You&apos;ll get a $2 welcome bonus!
                </p>
              )}
            </div>

            <Button
              type="submit"
              className="w-full h-11 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 text-white font-semibold rounded-xl shadow-lg shadow-purple-500/25 transition-all duration-200 mt-2"
              disabled={isLoading}
            >
              {isLoading ? (
                <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Creating account...</>
              ) : (
                <><UserPlus className="w-4 h-4 mr-2" /> Create Account</>
              )}
            </Button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-white/40 text-sm">
              Already have an account?{' '}
              <Link href="/auth/signin" className="text-purple-400 hover:text-purple-300 font-medium">
                Sign in here
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}

export default function SignUp() {
  return (
    <Suspense fallback={
      <div className="min-h-screen bg-[#0a0a0f] flex items-center justify-center">
        <div className="text-white/50">Loading...</div>
      </div>
    }>
      <SignUpForm />
    </Suspense>
  )
}
