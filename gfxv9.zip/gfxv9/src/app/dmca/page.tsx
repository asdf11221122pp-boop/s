'use client'

import { useEffect, useState } from 'react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { AlertCircle, Loader2, ExternalLink } from 'lucide-react'
import { Button } from '@/components/ui/button'

export default function DmcaPage() {
  const [dmcaUrl, setDmcaUrl] = useState('')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch('/api/admin/settings')
      .then(r => r.json())
      .then(d => {
        setDmcaUrl(d.dmcaUrl || '')
        setLoading(false)
      })
      .catch(() => setLoading(false))
  }, [])

  return (
    <div className="min-h-screen bg-[#0a0a0f] flex flex-col">
      <Navbar />
      <main className="flex-1 container mx-auto px-4 py-12 max-w-4xl">
        <div className="flex items-center gap-3 mb-8">
          <AlertCircle className="w-8 h-8 text-red-400" />
          <h1 className="text-3xl font-bold text-white">DMCA Policy</h1>
        </div>
        {loading ? (
          <div className="flex justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin text-purple-500" />
          </div>
        ) : dmcaUrl ? (
          <div className="bg-white/[0.03] border border-white/10 rounded-2xl p-8 text-center">
            <AlertCircle className="w-12 h-12 mx-auto mb-4 text-red-400" />
            <p className="text-white/70 mb-6">For DMCA takedown requests, please visit our official DMCA page.</p>
            <Button asChild className="bg-red-500/20 hover:bg-red-500/30 text-red-400 border border-red-500/30">
              <a href={dmcaUrl} target="_blank" rel="noopener noreferrer">
                <ExternalLink className="w-4 h-4 mr-2" />
                Submit DMCA Request
              </a>
            </Button>
          </div>
        ) : (
          <div className="text-center py-20 text-white/40">
            <AlertCircle className="w-12 h-12 mx-auto mb-4 opacity-30" />
            <p>DMCA policy information has not been configured yet.</p>
          </div>
        )}
      </main>
      <Footer />
    </div>
  )
}
