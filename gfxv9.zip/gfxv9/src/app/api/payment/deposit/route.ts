import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { withRetry } from '@/lib/db-retry'

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const { amount, method } = body

    if (!amount || !method || amount <= 0) {
      return NextResponse.json({ error: 'Invalid amount or method' }, { status: 400 })
    }

    const transaction = await withRetry(
      async () => {
        const settings = await db.siteSettings.findFirst()
        const phoneNumber = method === 'nagad' ? settings?.nagadNumber : settings?.bkashNumber

        if (!phoneNumber) {
          throw new Error('Payment method not configured')
        }

        const tx = await db.transaction.create({
          data: {
            userId: session.user.id,
            amount: parseFloat(amount),
            method,
            type: 'DEPOSIT',
            status: 'PENDING'
          }
        })

        return { transaction: tx, phoneNumber }
      },
      'Create deposit transaction'
    )

    return NextResponse.json({
      success: true,
      transaction: transaction.transaction,
      phoneNumber: transaction.phoneNumber,
      message: `Send $${amount} to ${transaction.phoneNumber} with reference: ${transaction.transaction.id}`
    })
  } catch (error) {
    console.error('Payment error:', error)
    const errorMessage = error instanceof Error ? error.message : 'Payment failed'
    return NextResponse.json({ error: errorMessage }, { status: 500 })
  }
}
