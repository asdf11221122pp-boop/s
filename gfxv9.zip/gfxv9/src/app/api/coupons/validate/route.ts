import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { code, orderAmount } = await req.json()
  if (!code) return NextResponse.json({ error: 'Coupon code required' }, { status: 400 })

  const coupon = await db.coupon.findUnique({ where: { code: code.toUpperCase() } })
  if (!coupon) return NextResponse.json({ error: 'Invalid coupon code', valid: false }, { status: 404 })
  if (!coupon.isActive) return NextResponse.json({ error: 'Coupon is not active', valid: false }, { status: 400 })
  if (coupon.expiresAt && coupon.expiresAt < new Date()) return NextResponse.json({ error: 'Coupon has expired', valid: false }, { status: 400 })
  if (coupon.maxUsage && coupon.usageCount >= coupon.maxUsage) return NextResponse.json({ error: 'Coupon usage limit reached', valid: false }, { status: 400 })
  if (coupon.minOrderAmount && orderAmount < coupon.minOrderAmount) {
    return NextResponse.json({ error: `Minimum order amount is $${coupon.minOrderAmount}`, valid: false }, { status: 400 })
  }

  // Check if already used by this user
  const usage = await db.couponUsage.findUnique({
    where: { couponId_userId: { couponId: coupon.id, userId: session.user.id } }
  })
  if (usage) return NextResponse.json({ error: 'You already used this coupon', valid: false }, { status: 400 })

  const discountAmount = coupon.discountType === 'PERCENTAGE'
    ? (orderAmount * coupon.discountValue) / 100
    : Math.min(coupon.discountValue, orderAmount)

  return NextResponse.json({
    valid: true,
    coupon: { id: coupon.id, code: coupon.code, description: coupon.description, discountType: coupon.discountType, discountValue: coupon.discountValue },
    discountAmount,
    finalAmount: Math.max(0, orderAmount - discountAmount)
  })
}
