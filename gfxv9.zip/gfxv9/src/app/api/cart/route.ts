import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { checkFeature } from '@/lib/feature-toggles'

export async function GET() {
  const blocked = await checkFeature('cart', 'Cart & Checkout')
  if (blocked) return blocked
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const cart = await db.cartItem.findMany({
    where: { userId: session.user.id },
    include: {
      item: {
        select: { id: true, title: true, slug: true, logo: true, price: true, accessType: true,
          author: { select: { username: true } }
        }
      }
    },
    orderBy: { createdAt: 'desc' }
  })

  const total = cart.reduce((sum, c) => sum + (c.item.price * c.quantity), 0)
  return NextResponse.json({ cart, total, count: cart.length })
}

export async function POST(req: NextRequest) {
  const blocked = await checkFeature('cart', 'Cart & Checkout')
  if (blocked) return blocked
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const { itemId, quantity = 1 } = await req.json()
  if (!itemId) return NextResponse.json({ error: 'Item ID required' }, { status: 400 })

  const item = await db.item.findUnique({ where: { id: itemId } })
  if (!item) return NextResponse.json({ error: 'Item not found' }, { status: 404 })

  const cartItem = await db.cartItem.upsert({
    where: { userId_itemId: { userId: session.user.id, itemId } },
    update: { quantity },
    create: { userId: session.user.id, itemId, quantity }
  })

  return NextResponse.json({ cartItem })
}

export async function DELETE(req: NextRequest) {
  const blocked = await checkFeature('cart', 'Cart & Checkout')
  if (blocked) return blocked
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const { itemId } = await req.json()

  if (itemId) {
    await db.cartItem.deleteMany({ where: { userId: session.user.id, itemId } })
  } else {
    await db.cartItem.deleteMany({ where: { userId: session.user.id } })
  }
  return NextResponse.json({ success: true })
}
