import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'
import { checkFeature } from '@/lib/feature-toggles'

export async function POST(request: NextRequest) {
  try {
    const blocked = await checkFeature('friends', 'Friends System')
    if (blocked) return blocked
    const session = await getServerSession(authOptions)
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const user = await db.user.findUnique({
      where: { email: session.user.email }
    })

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    const { username } = await request.json()

    if (!username) {
      return NextResponse.json(
        { error: 'Username is required' },
        { status: 400 }
      )
    }

    // Find recipient user
    const recipientUser = await db.user.findUnique({
      where: { username }
    })

    if (!recipientUser) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      )
    }

    if (recipientUser.id === user.id) {
      return NextResponse.json(
        { error: 'Cannot send friend request to yourself' },
        { status: 400 }
      )
    }

    // Check if already friends
    const existingFriend = await db.friend.findUnique({
      where: {
        user1Id_user2Id: {
          user1Id: user.id < recipientUser.id ? user.id : recipientUser.id,
          user2Id: user.id < recipientUser.id ? recipientUser.id : user.id
        }
      }
    })

    if (existingFriend) {
      return NextResponse.json(
        { error: 'Already friends' },
        { status: 400 }
      )
    }

    // Check if request already exists
    const existingRequest = await db.friendRequest.findUnique({
      where: {
        senderId_receiverId: {
          senderId: user.id,
          receiverId: recipientUser.id
        }
      }
    })

    if (existingRequest && existingRequest.status === 'PENDING') {
      return NextResponse.json(
        { error: 'Friend request already sent' },
        { status: 400 }
      )
    }

    // Create friend request
    const friendRequest = await db.friendRequest.create({
      data: {
        senderId: user.id,
        receiverId: recipientUser.id,
        status: 'PENDING'
      },
      include: {
        sender: { select: { id: true, username: true, avatar: true } },
        receiver: { select: { id: true, username: true, avatar: true } }
      }
    })

    // Create notification
    await db.notification.create({
      data: {
        userId: recipientUser.id,
        title: 'Friend Request',
        content: `${user.username} sent you a friend request`,
        type: 'FRIEND_REQUEST_RECEIVED'
      }
    })

    // Emit socket notification if available
    if ((global as any).sendNotification) {
      await (global as any).sendNotification(recipientUser.id, {
        title: 'Friend Request',
        content: `${user.username} sent you a friend request`,
        type: 'FRIEND_REQUEST_RECEIVED'
      })
    }

    return NextResponse.json(friendRequest, { status: 201 })
  } catch (error) {
    console.error('Error sending friend request:', error)
    return NextResponse.json(
      { error: 'Failed to send friend request' },
      { status: 500 }
    )
  }
}
