import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { withRetry } from '@/lib/db-retry'

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { membershipId } = await request.json()

    if (!membershipId) {
      return NextResponse.json({ error: 'Membership ID required' }, { status: 400 })
    }

    const user = await withRetry(
      () => db.user.findUnique({
        where: { id: session.user.id },
        select: { id: true, walletBalance: true, role: true }
      }),
      'Fetch user for purchase'
    )

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    const membership = await withRetry(
      () => db.membership.findUnique({
        where: { id: membershipId }
      }),
      'Fetch membership'
    )

    if (!membership) {
      return NextResponse.json({ error: 'Membership not found' }, { status: 404 })
    }

    if ((user.walletBalance || 0) < membership.price) {
      return NextResponse.json(
        { error: 'Insufficient balance' },
        { status: 400 }
      )
    }

    const updatedUser = await withRetry(
      async () => {
        return await db.user.update({
          where: { id: session.user.id },
          data: {
            walletBalance: (user.walletBalance || 0) - membership.price,
            role: membership.roleName
          }
        })
      },
      'Update user with membership'
    )

    return NextResponse.json({
      success: true,
      message: `Successfully purchased ${membership.name}`,
      newRole: updatedUser.role,
      newBalance: updatedUser.walletBalance
    })
  } catch (error) {
    console.error('Error purchasing membership:', error)
    return NextResponse.json(
      { error: 'Failed to purchase membership', message: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    )
  }
}
