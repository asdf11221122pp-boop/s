import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ userId: string }> } // ✅ Promise (IMPORTANT)
) {
  try {
    // 🔐 Auth check
    const session = await getServerSession(authOptions)

    if (!session?.user?.email) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      )
    }

    // 👤 Current user
    const user = await db.user.findUnique({
      where: { email: session.user.email }
    })

    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      )
    }

    // ✅ MUST await params (MAIN FIX)
    const { userId } = await params

    // ❌ Prevent self chat
    if (user.id === userId) {
      return NextResponse.json(
        { error: 'You cannot chat with yourself' },
        { status: 400 }
      )
    }

    // 🎯 Target user
    const targetUser = await db.user.findUnique({
      where: { id: userId }
    })

    if (!targetUser) {
      return NextResponse.json(
        { error: 'Target user not found' },
        { status: 404 }
      )
    }

    // 💬 Fetch messages
    const messages = await db.privateMessage.findMany({
      where: {
        OR: [
          {
            senderId: user.id,
            receiverId: userId
          },
          {
            senderId: userId,
            receiverId: user.id
          }
        ]
      },
      include: {
        sender: {
          select: {
            id: true,
            username: true,
            avatar: true
          }
        },
        receiver: {
          select: {
            id: true,
            username: true,
            avatar: true
          }
        }
      },
      orderBy: {
        createdAt: 'asc'
      },
      take: 100
    })

    // ✅ Mark messages as read (only unread)
    await db.privateMessage.updateMany({
      where: {
        receiverId: user.id,
        senderId: userId,
        isRead: false
      },
      data: {
        isRead: true
      }
    })

    // 🚀 Response
    return NextResponse.json({
      success: true,
      messages,
      otherUser: {
        id: targetUser.id,
        username: targetUser.username,
        avatar: targetUser.avatar,
        bio: targetUser.bio,
        isActive: targetUser.isActive
      }
    })

  } catch (error) {
    console.error('❌ Error fetching messages:', error)

    return NextResponse.json(
      {
        success: false,
        error: 'Internal Server Error'
      },
      { status: 500 }
    )
  }
}