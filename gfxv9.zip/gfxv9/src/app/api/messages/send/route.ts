import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'
import { checkFeature } from '@/lib/feature-toggles'

export async function POST(request: NextRequest) {
  try {
    const blocked = await checkFeature('chat', 'Chat System')
    if (blocked) return blocked
    const session = await getServerSession(authOptions)
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const user = await db.user.findUnique({
      where: { email: session.user.email }
    })

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    const { receiverId, content, vpsOrderInfo } = await request.json()

    if (!receiverId || !content) {
      return NextResponse.json(
        { error: 'Receiver ID and content are required' },
        { status: 400 }
      )
    }

    // Check if receiver exists
    const receiver = await db.user.findUnique({
      where: { id: receiverId }
    })

    if (!receiver) {
      return NextResponse.json(
        { error: 'Receiver not found' },
        { status: 404 }
      )
    }

    // Check if users are friends
    const friendship = await db.friend.findFirst({
      where: {
        OR: [
          {
            AND: [
              { user1Id: user.id },
              { user2Id: receiverId }
            ]
          },
          {
            AND: [
              { user1Id: receiverId },
              { user2Id: user.id }
            ]
          }
        ]
      }
    })

    if (!friendship && vpsOrderInfo === undefined) {
      return NextResponse.json(
        { error: 'You must be friends to send messages' },
        { status: 403 }
      )
    }

    // Create private message
    const message = await db.privateMessage.create({
      data: {
        senderId: user.id,
        receiverId,
        content: content.trim().slice(0, 2000),
        vpsOrderInfo: vpsOrderInfo ? vpsOrderInfo : null,
      },
      include: {
        sender: {
          select: {
            id: true,
            username: true,
            avatar: true
          }
        },
        receiver: {
          select: {
            id: true,
            username: true,
            avatar: true
          }
        }
      }
    })

    // Create notification
    await db.notification.create({
      data: {
        userId: receiverId,
        title: 'New Message',
        content: `${user.username} sent you a message`,
        type: 'NEW_MESSAGE'
      }
    })

    // Emit socket notification if available
    if ((global as any).sendNotification) {
      await (global as any).sendNotification(receiverId, {
        title: 'New Message',
        content: `${user.username} sent you a message`,
        type: 'NEW_MESSAGE'
      })
    }

    // Emit real-time message via Socket.IO
    if ((global as any).io) {
      (global as any).io.to(`user:${receiverId}`).emit('newPrivateMessage', message)
    }

    return NextResponse.json(message, { status: 201 })
  } catch (error) {
    console.error('Error sending message:', error)
    return NextResponse.json(
      { error: 'Failed to send message' },
      { status: 500 }
    )
  }
}
