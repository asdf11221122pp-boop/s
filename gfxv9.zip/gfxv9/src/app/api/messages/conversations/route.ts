import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'
import { checkFeature } from '@/lib/feature-toggles'

export async function GET(request: NextRequest) {
  try {
    const blocked = await checkFeature('chat', 'Chat System')
    if (blocked) return blocked
    const session = await getServerSession(authOptions)
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const user = await db.user.findUnique({
      where: { email: session.user.email },
      include: {
        sentMessages: {
          include: {
            receiver: {
              select: {
                id: true,
                username: true,
                avatar: true
              }
            }
          },
          orderBy: { createdAt: 'desc' }
        },
        receivedMessages: {
          include: {
            sender: {
              select: {
                id: true,
                username: true,
                avatar: true
              }
            }
          },
          orderBy: { createdAt: 'desc' }
        }
      }
    })

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    // Create a map of conversations
    const conversationMap = new Map<string, any>()

    // Add sent messages
    for (const msg of user.sentMessages) {
      const key = msg.receiverId
      if (!conversationMap.has(key)) {
        conversationMap.set(key, {
          userId: msg.receiver.id,
          username: msg.receiver.username,
          avatar: msg.receiver.avatar,
          lastMessage: msg.content,
          lastMessageTime: msg.createdAt,
          unreadCount: 0
        })
      }
    }

    // Add received messages
    for (const msg of user.receivedMessages) {
      const key = msg.senderId
      if (conversationMap.has(key)) {
        const conv = conversationMap.get(key)
        conv.lastMessage = msg.content
        conv.lastMessageTime = msg.createdAt
        if (!msg.isRead) conv.unreadCount++
      } else {
        const unreadCount = user.receivedMessages.filter(
          m => m.senderId === msg.senderId && !m.isRead
        ).length
        conversationMap.set(key, {
          userId: msg.sender.id,
          username: msg.sender.username,
          avatar: msg.sender.avatar,
          lastMessage: msg.content,
          lastMessageTime: msg.createdAt,
          unreadCount
        })
      }
    }

    // Sort by last message time
    const conversations = Array.from(conversationMap.values()).sort(
      (a, b) => new Date(b.lastMessageTime).getTime() - new Date(a.lastMessageTime).getTime()
    )

    return NextResponse.json({
      conversations,
      count: conversations.length
    })
  } catch (error) {
    console.error('Error fetching conversations:', error)
    return NextResponse.json(
      { error: 'Failed to fetch conversations' },
      { status: 500 }
    )
  }
}
