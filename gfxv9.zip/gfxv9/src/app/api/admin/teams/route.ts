import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  if (!['ADMIN', 'SUPER_ADMIN'].includes(session.user.role || '')) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  try {
    const teams = await db.team.findMany({
      include: {
        owner: { select: { id: true, username: true, avatar: true } },
        members: {
          include: { user: { select: { id: true, username: true, avatar: true } } }
        }
      },
      orderBy: { createdAt: 'desc' }
    })

    return NextResponse.json({ teams })
  } catch (error) {
    return NextResponse.json({ teams: [] })
  }
}
