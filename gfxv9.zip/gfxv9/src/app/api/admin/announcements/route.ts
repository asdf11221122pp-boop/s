import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

function isAdmin(role?: string) { return ['ADMIN', 'SUPER_ADMIN'].includes(role || '') }

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id || !isAdmin(session.user.role)) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  const { message, title } = await req.json()
  if (!message?.trim()) return NextResponse.json({ error: 'Message required' }, { status: 400 })

  // Send announcement to all users
  const users = await db.user.findMany({ select: { id: true } })
  
  await db.$transaction(
    users.map(u => db.notification.create({
      data: {
        userId: u.id,
        type: 'ADMIN_ANNOUNCEMENT' as any,
        title: title || 'Admin Announcement',
        content: message
      }
    }))
  )

  return NextResponse.json({ success: true, sentTo: users.length })
}
