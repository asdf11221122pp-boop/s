import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  if (!['ADMIN', 'SUPER_ADMIN'].includes(session.user.role || '')) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  try {
    const badges = await db.badge.findMany({
      include: { tasks: true },
      orderBy: { createdAt: 'desc' }
    })
    return NextResponse.json({ badges })
  } catch (error) {
    return NextResponse.json({ badges: [] })
  }
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  if (!['ADMIN', 'SUPER_ADMIN'].includes(session.user.role || '')) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  try {
    const data = await req.json()
    const badge = await db.badge.create({
      data: {
        name: data.name,
        description: data.description || '',
        icon: data.icon || '⭐',
        color: data.color || '#8B5CF6',
        criteria: data.criteria || null,
        isAutomatic: data.isAutomatic ?? false,
        isActive: data.isActive ?? true
      }
    })

    // Create associated task if provided
    if (data.task) {
      await db.badgeTask.create({
        data: {
          badgeId: badge.id,
          name: data.task.name,
          description: data.task.description,
          type: data.task.type || 'CUSTOM',
          targetValue: data.task.targetValue || 1
        }
      })
    }

    const badgeWithTask = await db.badge.findUnique({
      where: { id: badge.id },
      include: { tasks: true }
    })

    return NextResponse.json({ badge: badgeWithTask })
  } catch (error) {
    console.error('Badge creation error:', error)
    return NextResponse.json({ error: 'Failed to create badge' }, { status: 500 })
  }
}

export async function PATCH(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  if (!['ADMIN', 'SUPER_ADMIN'].includes(session.user.role || '')) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  try {
    const data = await req.json()
    const { badgeId, task, ...updateData } = data

    if (!badgeId) return NextResponse.json({ error: 'Badge ID required' }, { status: 400 })

    // Update badge
    const badge = await db.badge.update({
      where: { id: badgeId },
      data: updateData,
      include: { tasks: true }
    })

    // Update or create task
    if (task) {
      const existingTask = await db.badgeTask.findFirst({
        where: { badgeId }
      })

      if (existingTask) {
        await db.badgeTask.update({
          where: { id: existingTask.id },
          data: {
            name: task.name,
            description: task.description,
            type: task.type || 'CUSTOM',
            targetValue: task.targetValue || 1
          }
        })
      } else {
        await db.badgeTask.create({
          data: {
            badgeId,
            name: task.name,
            description: task.description,
            type: task.type || 'CUSTOM',
            targetValue: task.targetValue || 1
          }
        })
      }
    }

    const updatedBadge = await db.badge.findUnique({
      where: { id: badgeId },
      include: { tasks: true }
    })

    return NextResponse.json({ badge: updatedBadge })
  } catch (error) {
    console.error('Badge update error:', error)
    return NextResponse.json({ error: 'Failed to update badge' }, { status: 500 })
  }
}

export async function DELETE(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  if (!['ADMIN', 'SUPER_ADMIN'].includes(session.user.role || '')) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  try {
    const data = await req.json()
    const { badgeId } = data

    if (!badgeId) return NextResponse.json({ error: 'Badge ID required' }, { status: 400 })

    await db.badge.delete({
      where: { id: badgeId }
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Badge delete error:', error)
    return NextResponse.json({ error: 'Failed to delete badge' }, { status: 500 })
  }
}
