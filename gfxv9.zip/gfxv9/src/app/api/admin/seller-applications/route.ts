import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

function isAdmin(role?: string) { return ['ADMIN', 'SUPER_ADMIN'].includes(role || '') }

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id || !isAdmin(session.user.role)) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  const applications = await db.sellerApplication.findMany({
    include: { user: { select: { id: true, username: true, email: true, avatar: true, totalSales: true, sellerLevel: true, isVerified: true } } },
    orderBy: { createdAt: 'desc' }
  })

  return NextResponse.json({ applications })
}

export async function PATCH(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id || !isAdmin(session.user.role)) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  const { id, status, adminNote } = await req.json()

  const application = await db.sellerApplication.update({
    where: { id },
    data: { status, adminNote }
  })

  // If approved, mark user as verified seller
  if (status === 'APPROVED') {
    await db.user.update({ where: { id: application.userId }, data: { isVerified: true, role: 'CREATOR' } })
    await db.notification.create({
      data: {
        userId: application.userId,
        type: 'SELLER_VERIFIED' as any,
        title: 'Seller Application Approved! 🎉',
        content: 'Congratulations! You are now a verified seller on GfxStore. Start uploading your content!'
      }
    })
  } else if (status === 'REJECTED') {
    await db.notification.create({
      data: {
        userId: application.userId,
        type: 'SYSTEM_ANNOUNCEMENT' as any,
        title: 'Seller Application Status',
        content: adminNote || 'Your seller application was not approved at this time.'
      }
    })
  }

  return NextResponse.json({ application })
}
