import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

function isAdmin(role?: string) { return ['ADMIN', 'SUPER_ADMIN'].includes(role || '') }

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id || !isAdmin(session.user.role)) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  const requests = await db.withdrawRequest.findMany({
    include: { user: { select: { id: true, username: true, email: true, avatar: true, walletBalance: true } } },
    orderBy: { createdAt: 'desc' }
  })

  return NextResponse.json({ requests })
}

export async function PATCH(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id || !isAdmin(session.user.role)) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  const { id, status, adminNote } = await req.json()
  if (!id || !status) return NextResponse.json({ error: 'ID and status required' }, { status: 400 })

  const request = await db.withdrawRequest.findUnique({ where: { id } })
  if (!request) return NextResponse.json({ error: 'Request not found' }, { status: 404 })

  const updated = await db.$transaction(async (tx) => {
    const upd = await tx.withdrawRequest.update({
      where: { id },
      data: { status, adminNote, processedAt: new Date() }
    })

    // If rejected, refund the amount back to user's wallet
    if (status === 'REJECTED') {
      await tx.user.update({ where: { id: request.userId }, data: { walletBalance: { increment: request.amount } } })
    }

    // Notify user
    await tx.notification.create({
      data: {
        userId: request.userId,
        type: 'TRANSACTION_APPROVED' as any,
        title: `Withdrawal ${status.toLowerCase()}`,
        content: status === 'APPROVED'
          ? `Your withdrawal of $${request.amount} has been approved and will be sent to your ${request.method} account.`
          : `Your withdrawal of $${request.amount} was rejected. ${adminNote || ''} The amount has been refunded.`
      }
    })

    return upd
  })

  return NextResponse.json({ request: updated })
}
