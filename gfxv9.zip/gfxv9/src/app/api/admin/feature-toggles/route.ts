import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

const DEFAULT_FEATURES = [
  { featureKey: 'marketplace', featureName: 'Marketplace', description: 'Browse and purchase items', category: 'core' },
  { featureKey: 'upload', featureName: 'Upload System', description: 'Sellers can upload new items', category: 'core' },
  { featureKey: 'reviews', featureName: 'Reviews & Ratings', description: 'Users can leave reviews on items', category: 'core' },
  { featureKey: 'search', featureName: 'Search & Filters', description: 'Search items with filters', category: 'core' },
  { featureKey: 'cart', featureName: 'Cart & Checkout', description: 'Shopping cart and checkout flow', category: 'core' },
  { featureKey: 'wallet', featureName: 'Wallet System', description: 'User wallet for deposits and purchases', category: 'payments' },
  { featureKey: 'withdrawals', featureName: 'Seller Withdrawals', description: 'Sellers can withdraw earnings', category: 'payments' },
  { featureKey: 'coupons', featureName: 'Coupon System', description: 'Discount coupons for purchases', category: 'payments' },
  { featureKey: 'chat', featureName: 'Chat System', description: 'Real-time private messaging', category: 'social' },
  { featureKey: 'friends', featureName: 'Friends System', description: 'Friend requests and connections', category: 'social' },
  { featureKey: 'notifications', featureName: 'Notifications', description: 'Push notifications and alerts', category: 'social' },
  { featureKey: 'custom_orders', featureName: 'Custom Orders', description: 'Custom work requests', category: 'marketplace' },
  { featureKey: 'freebies', featureName: 'Freebies Page', description: 'Free items section', category: 'marketplace' },
  { featureKey: 'creators', featureName: 'Creators Page', description: 'Seller profiles and rankings', category: 'marketplace' },
  { featureKey: 'wishlist', featureName: 'Wishlist', description: 'Save items to wishlist', category: 'marketplace' },
  { featureKey: 'seller_apps', featureName: 'Seller Applications', description: 'Apply to become a seller', category: 'seller' },
  { featureKey: 'seller_levels', featureName: 'Seller Levels', description: 'Automated seller level system', category: 'seller' },
  { featureKey: 'verified_sellers', featureName: 'Verified Sellers', description: 'Seller verification badges', category: 'seller' },
  { featureKey: 'vps_hosting', featureName: 'VPS Hosting', description: 'Server hosting marketplace', category: 'services' },
  { featureKey: 'memberships', featureName: 'Memberships', description: 'Premium membership tiers', category: 'services' },
  { featureKey: 'ads', featureName: 'Advertisements', description: 'Display promotional ads', category: 'marketing' },
  { featureKey: 'boost', featureName: 'Item Boosting', description: 'Boost items for visibility', category: 'marketing' },
  { featureKey: 'reports', featureName: 'Report System', description: 'Report users and items', category: 'moderation' },
  { featureKey: 'downloads', featureName: 'Secure Downloads', description: 'Token-based download protection', category: 'core' },
]

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  if (!['ADMIN', 'SUPER_ADMIN'].includes(session.user.role || '')) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  try {
    let features = await db.featureToggle.findMany({ orderBy: [{ category: 'asc' }, { featureName: 'asc' }] })

    if (features.length === 0) {
      await db.featureToggle.createMany({
        data: DEFAULT_FEATURES.map(f => ({ ...f, isEnabled: true })),
        skipDuplicates: true
      })
      features = await db.featureToggle.findMany({ orderBy: [{ category: 'asc' }, { featureName: 'asc' }] })
    }

    const missingKeys = DEFAULT_FEATURES.filter(df => !features.find(f => f.featureKey === df.featureKey))
    if (missingKeys.length > 0) {
      await db.featureToggle.createMany({
        data: missingKeys.map(f => ({ ...f, isEnabled: true })),
        skipDuplicates: true
      })
      features = await db.featureToggle.findMany({ orderBy: [{ category: 'asc' }, { featureName: 'asc' }] })
    }

    return NextResponse.json({ features })
  } catch (error) {
    return NextResponse.json({ features: [] })
  }
}

export async function PATCH(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  if (!['ADMIN', 'SUPER_ADMIN'].includes(session.user.role || '')) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  try {
    const { id, isEnabled } = await req.json()
    const feature = await db.featureToggle.update({
      where: { id },
      data: { isEnabled }
    })
    return NextResponse.json({ feature })
  } catch (error) {
    return NextResponse.json({ error: 'Failed to update feature' }, { status: 500 })
  }
}
