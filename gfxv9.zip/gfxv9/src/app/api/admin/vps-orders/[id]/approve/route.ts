import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id || (session.user.role !== 'ADMIN' && session.user.role !== 'SUPER_ADMIN')) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { id } = await params
    const body = await request.json()
    const { serverInfo } = body

    const order = await db.vPSOrder.findUnique({ 
      where: { id }, 
      include: { 
        plan: true,
        user: {
          select: { id: true, username: true }
        }
      } 
    })
    if (!order) {
      return NextResponse.json({ error: 'Order not found' }, { status: 404 })
    }
    if (order.status === 'APPROVED') {
      return NextResponse.json({ error: 'Order already approved' }, { status: 400 })
    }

    const updated = await db.vPSOrder.update({
      where: { id },
      data: {
        status: 'APPROVED',
        serverInfo: serverInfo || {}
      }
    })

    // Create notification
    await db.notification.create({
      data: {
        userId: order.userId,
        title: '✅ VPS Order Approved',
        content: `Your order for ${order.plan.name} has been approved. Check your messages for server details.`,
        type: 'VPS_ORDER_APPROVED',
        vpsOrderId: order.id
      }
    })

    // Send notification via Socket.IO
    if ((global as any).sendNotification) {
      try {
        await (global as any).sendNotification(order.userId, {
          title: '✅ VPS Order Approved',
          content: `Your order for ${order.plan.name} has been approved. Check your messages for server details.`,
          type: 'VPS_ORDER_APPROVED'
        })
      } catch (notifErr) {
        console.error('Failed to send notification', notifErr)
      }
    }

    // Send VPS info through private message
    try {
      const adminUser = await db.user.findUnique({
        where: { email: session.user.email },
        select: { id: true, username: true }
      })

      if (adminUser) {
        // Format server info for message - handle both string and object
        let formattedInfo = ''
        if (typeof serverInfo === 'string') {
          formattedInfo = serverInfo
        } else if (typeof serverInfo === 'object' && serverInfo !== null) {
          formattedInfo = JSON.stringify(serverInfo, null, 2)
        }
        
        const vpsInfoMessage = `📦 **VPS Order Approved**\n\nPlan: ${order.plan.name}\nAmount: $${order.amount}\n\n**Server Details:**\n${formattedInfo}`

        const message = await db.privateMessage.create({
          data: {
            senderId: adminUser.id,
            receiverId: order.userId,
            content: vpsInfoMessage,
            vpsOrderInfo: serverInfo || {}
          }
        })

        // Emit real-time message
        if ((global as any).io) {
          (global as any).io.to(`user:${order.userId}`).emit('newPrivateMessage', message)
        }
      }
    } catch (msgErr) {
      console.error('Failed to send private message:', msgErr)
    }

    // Also create a support chat message for reference
    try {
      await db.chatMessage.create({
        data: {
          userId: order.userId,
          content: `Your VPS order has been approved. Server information: ${JSON.stringify(serverInfo ?? {})}`,
          type: 'SUPPORT'
        }
      })
    } catch (chatErr) {
      console.error('Failed to log support chat message', chatErr)
    }

    return NextResponse.json({ success: true, order: updated })
  } catch (error) {
    console.error('Error approving VPS order:', error)
    return NextResponse.json({ error: 'Failed to approve order' }, { status: 500 })
  }
}
