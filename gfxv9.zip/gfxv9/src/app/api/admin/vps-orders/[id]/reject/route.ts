import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id || (session.user.role !== 'ADMIN' && session.user.role !== 'SUPER_ADMIN')) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { id } = await params
    const body = await request.json()
    const { reason } = body

    const order = await db.vPSOrder.findUnique({ 
      where: { id },
      include: { plan: true }
    })
    if (!order) {
      return NextResponse.json({ error: 'Order not found' }, { status: 404 })
    }
    if (order.status === 'REJECTED') {
      return NextResponse.json({ error: 'Order already rejected' }, { status: 400 })
    }

    const updated = await db.vPSOrder.update({
      where: { id },
      data: { status: 'REJECTED' }
    })

    // Create notification
    await db.notification.create({
      data: {
        userId: order.userId,
        title: '❌ VPS Order Rejected',
        content: `Your VPS order for ${order.plan.name} has been rejected${reason ? `: ${reason}` : '.'}`,
        type: 'VPS_ORDER_REJECTED',
        vpsOrderId: order.id
      }
    })

    if ((global as any).sendNotification) {
      try {
        await (global as any).sendNotification(order.userId, {
          title: '❌ VPS Order Rejected',
          content: `Your VPS order for ${order.plan.name} has been rejected${reason ? `: ${reason}` : '.'}`,
          type: 'VPS_ORDER_REJECTED'
        })
      } catch (notifErr) {
        console.error('Failed to send rejection notification', notifErr)
      }
    }

    return NextResponse.json({ success: true, order: updated })
  } catch (error) {
    console.error('Error rejecting VPS order:', error)
    return NextResponse.json({ error: 'Failed to reject order' }, { status: 500 })
  }
}
