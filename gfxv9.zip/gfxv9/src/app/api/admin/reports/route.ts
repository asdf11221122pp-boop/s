import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

function isAdmin(role?: string) { return ['ADMIN', 'SUPER_ADMIN'].includes(role || '') }

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  
  const userRole = session.user.role || ''
  if (!isAdmin(userRole)) {
    console.error(`Reports access denied for user ${session.user.id} with role: ${userRole}`)
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  }

  const reports = await db.report.findMany({
    include: {
      reporter: { select: { id: true, username: true, email: true } },
      reportedUser: { select: { id: true, username: true } },
      item: { select: { id: true, title: true, slug: true } }
    },
    orderBy: { createdAt: 'desc' }
  })

  return NextResponse.json({ reports })
}

export async function PATCH(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id || !isAdmin(session.user.role)) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  const { id, status } = await req.json()
  if (!id || !status) return NextResponse.json({ error: 'ID and status required' }, { status: 400 })

  const report = await db.report.update({ where: { id }, data: { status } })
  return NextResponse.json({ report })
}
