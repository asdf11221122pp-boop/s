import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

function isAdmin(role?: string) { return ['ADMIN', 'SUPER_ADMIN'].includes(role || '') }

// Resolve item by id or slug
async function resolveItem(slug: string) {
  // Try by id first, then by slug
  const byId = await db.item.findUnique({ where: { id: slug } }).catch(() => null)
  if (byId) return byId
  return db.item.findUnique({ where: { slug } })
}

export async function GET(req: NextRequest, { params }: { params: Promise<{ slug: string }> }) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id || !isAdmin(session.user.role)) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  const { slug } = await params
  const item = await resolveItem(slug)
  if (!item) return NextResponse.json({ error: 'Not found' }, { status: 404 })
  return NextResponse.json({ item })
}

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ slug: string }> }) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id || !isAdmin(session.user.role)) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  const { slug } = await params
  const existing = await resolveItem(slug)
  if (!existing) return NextResponse.json({ error: 'Item not found' }, { status: 404 })

  const data = await req.json()
  const updateData: any = {}
  if (data.status) updateData.status = data.status
  if (typeof data.featured === 'boolean') updateData.featured = data.featured
  if (typeof data.isBoosted === 'boolean') updateData.isBoosted = data.isBoosted

  const item = await db.item.update({ where: { id: existing.id }, data: updateData })

  // Notify author if status changed
  if (data.status && ['APPROVED', 'REJECTED'].includes(data.status)) {
    await db.notification.create({
      data: {
        userId: existing.authorId,
        type: (data.status === 'APPROVED' ? 'ITEM_APPROVED' : 'ITEM_REJECTED') as any,
        title: `Item ${data.status.toLowerCase()}`,
        content: `Your item "${existing.title}" has been ${data.status.toLowerCase()}${data.adminNote ? ': ' + data.adminNote : ''}`
      }
    }).catch(() => {})
  }

  return NextResponse.json({ item })
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ slug: string }> }) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id || !isAdmin(session.user.role)) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  const { slug } = await params
  const existing = await resolveItem(slug)
  if (!existing) return NextResponse.json({ error: 'Not found' }, { status: 404 })

  await db.item.delete({ where: { id: existing.id } })
  return NextResponse.json({ success: true })
}
