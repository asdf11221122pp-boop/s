import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  if (!['ADMIN', 'SUPER_ADMIN'].includes(session.user.role || '')) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  try {
    const rewards = await db.mysteryReward.findMany({ orderBy: { createdAt: 'desc' } })
    const recentLogs = await db.mysteryRewardLog.findMany({
      orderBy: { createdAt: 'desc' },
      take: 20
    })
    return NextResponse.json({ rewards, recentLogs })
  } catch (error) {
    return NextResponse.json({ rewards: [], recentLogs: [] })
  }
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  if (!['ADMIN', 'SUPER_ADMIN'].includes(session.user.role || '')) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  try {
    const data = await req.json()
    const reward = await db.mysteryReward.create({
      data: {
        name: data.name,
        type: data.type || 'COINS',
        value: parseFloat(data.value) || 0,
        probability: parseFloat(data.probability) || 0.1,
        isActive: data.isActive ?? true
      }
    })
    return NextResponse.json({ reward })
  } catch (error) {
    return NextResponse.json({ error: 'Failed to create reward' }, { status: 500 })
  }
}
