import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  
  const userRole = session.user.role || ''
  if (!['ADMIN', 'SUPER_ADMIN'].includes(userRole)) {
    console.error(`Leaderboard access denied for user ${session.user.id} with role: ${userRole}`)
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  }

  try {
    const oneWeekAgo = new Date()
    oneWeekAgo.setDate(oneWeekAgo.getDate() - 7)

    const topSellers = await db.user.findMany({
      where: { role: { in: ['SELLER', 'ADMIN', 'SUPER_ADMIN'] } },
      select: {
        id: true,
        username: true,
        avatar: true,
        totalSales: true,
        walletBalance: true,
        _count: { select: { items: true } }
      },
      orderBy: { totalSales: 'desc' },
      take: 10
    })

    const topBuyers = await db.user.findMany({
      select: {
        id: true,
        username: true,
        avatar: true,
        _count: { select: { downloadRecords: true, buyerOrders: true } }
      },
      orderBy: { downloadRecords: { _count: 'desc' } },
      take: 10
    })

    const topItems = await db.item.findMany({
      select: {
        id: true,
        title: true,
        downloads: true,
        views: true,
        likes: true,
        price: true,
        author: { select: { username: true } }
      },
      orderBy: { downloads: 'desc' },
      take: 10
    })

    return NextResponse.json({ topSellers, topBuyers, topItems })
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch leaderboard' }, { status: 500 })
  }
}
