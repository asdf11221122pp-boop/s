import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export async function GET(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const order = await db.customOrder.findUnique({
    where: { id },
    include: {
      buyer: { select: { id: true, username: true, avatar: true } },
      bids: {
        include: {
          seller: { select: { id: true, username: true, avatar: true, isVerified: true, sellerLevel: true, totalSales: true } }
        }
      }
    }
  })
  if (!order) return NextResponse.json({ error: 'Not found' }, { status: 404 })
  return NextResponse.json({ order })
}

export async function PATCH(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { id } = await params
  const order = await db.customOrder.findUnique({ where: { id } })
  if (!order) return NextResponse.json({ error: 'Not found' }, { status: 404 })

  const isAdmin = ['ADMIN', 'SUPER_ADMIN'].includes(session.user.role || '')
  if (order.buyerId !== session.user.id && !isAdmin) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  }

  if (!isAdmin && order.status !== 'OPEN') {
    return NextResponse.json({ error: 'Can only edit open orders' }, { status: 400 })
  }

  const { title, description, budget, deadline, category, status } = await request.json()

  const updateData: any = {}
  if (title) updateData.title = title
  if (description) updateData.description = description
  if (budget !== undefined) updateData.budget = budget ? parseFloat(budget) : null
  if (deadline !== undefined) updateData.deadline = deadline
  if (category !== undefined) updateData.category = category
  if (status && isAdmin) updateData.status = status

  const updated = await db.customOrder.update({ where: { id }, data: updateData })
  return NextResponse.json({ order: updated })
}

export async function DELETE(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { id } = await params
  const order = await db.customOrder.findUnique({ where: { id } })
  if (!order) return NextResponse.json({ error: 'Not found' }, { status: 404 })

  const isAdmin = ['ADMIN', 'SUPER_ADMIN'].includes(session.user.role || '')
  if (order.buyerId !== session.user.id && !isAdmin) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  }

  await db.customOrder.delete({ where: { id } })
  return NextResponse.json({ success: true })
}
