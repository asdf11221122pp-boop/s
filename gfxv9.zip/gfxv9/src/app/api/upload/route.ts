import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { NextRequest, NextResponse } from 'next/server'
import { writeFile, mkdir } from 'fs/promises'
import { join } from 'path'
import { existsSync } from 'fs'
import crypto from 'crypto'
import { checkFeature } from '@/lib/feature-toggles'
import { FileStorageService } from '@/lib/storage'

export async function POST(request: NextRequest) {
  try {
    const blocked = await checkFeature('upload', 'Upload System')
    if (blocked) return blocked
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const formData = await request.formData()
    const file = formData.get('file') as File
    const type = (formData.get('type') as string) || 'general'

    if (!file) {
      return NextResponse.json({ error: 'No file provided' }, { status: 400 })
    }

    // Support files from 1KB to 10GB
    const minSize = 1 * 1024
    const maxSize = 10 * 1024 * 1024 * 1024
    if (file.size < minSize) {
      return NextResponse.json({ error: 'File too small (minimum 1KB)' }, { status: 400 })
    }
    if (file.size > maxSize) {
      return NextResponse.json({ error: 'File too large (max 10GB)' }, { status: 400 })
    }

    // Support image types and documents
    const ext = file.name.split('.').pop()?.toLowerCase() || 'bin'
    const allowedImages = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg']
    const allowedDocs = ['pdf', 'doc', 'docx', 'txt', 'zip', 'rar', '7z']
    const allowed = [...allowedImages, ...allowedDocs]
    
    if (!allowed.includes(ext)) {
      return NextResponse.json({ error: `Invalid file type. Allowed: ${allowed.join(', ')}` }, { status: 400 })
    }

    const subDir = type === 'avatar' ? 'avatars' : 'general'
    const uniqueName = `${crypto.randomUUID()}.${ext}`

    // Try to use S3 first if configured, otherwise use local storage
    let url = ''
    
    if (process.env.S3_BUCKET && process.env.S3_ACCESS_KEY && process.env.S3_SECRET_KEY) {
      try {
        const storage = new FileStorageService()
        const key = storage.generateFileKey(subDir, uniqueName, session.user.id)
        const bytes = await file.arrayBuffer()
        const contentType = file.type || 'application/octet-stream'
        url = await storage.uploadFile(key, Buffer.from(bytes), contentType)
      } catch (s3Error) {
        console.warn('S3 upload failed, falling back to local storage:', s3Error)
        // Fall back to local storage
        const uploadDir = join(process.cwd(), 'public', 'uploads', subDir)
        if (!existsSync(uploadDir)) {
          await mkdir(uploadDir, { recursive: true })
        }
        const filePath = join(uploadDir, uniqueName)
        const bytes = await file.arrayBuffer()
        await writeFile(filePath, Buffer.from(bytes))
        url = `/uploads/${subDir}/${uniqueName}`
      }
    } else {
      // Use local storage
      const uploadDir = join(process.cwd(), 'public', 'uploads', subDir)
      if (!existsSync(uploadDir)) {
        await mkdir(uploadDir, { recursive: true })
      }
      const filePath = join(uploadDir, uniqueName)
      const bytes = await file.arrayBuffer()
      await writeFile(filePath, Buffer.from(bytes))
      url = `/uploads/${subDir}/${uniqueName}`
    }

    return NextResponse.json({ url, fileName: file.name, size: file.size })
  } catch (error) {
    console.error('Upload error:', error)
    return NextResponse.json({ error: 'Upload failed' }, { status: 500 })
  }
}
