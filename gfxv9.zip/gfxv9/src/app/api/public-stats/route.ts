import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { withRetry } from '@/lib/db-retry'

export async function GET() {
  try {
    const [totalUsers, totalItems, totalDownloadsResult] = await withRetry(
      () => Promise.all([
        db.user.count(),
        db.item.count({ where: { status: 'APPROVED' } }),
        db.item.aggregate({
          _sum: { downloads: true }
        })
      ]),
      'Fetch public stats'
    )

    return NextResponse.json({
      totalUsers: totalUsers || 0,
      totalItems: totalItems || 0,
      totalDownloads: totalDownloadsResult?._sum?.downloads || 0
    })
  } catch (error) {
    console.error('Error fetching public stats:', error)
    return NextResponse.json({
      totalUsers: 0,
      totalItems: 0,
      totalDownloads: 0
    })
  }
}
