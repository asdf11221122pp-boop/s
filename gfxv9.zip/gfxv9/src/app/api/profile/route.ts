import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { parseBadgeIds, getBadgeDetailsByIds } from '@/lib/badge-utils'

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const user = await db.user.findUnique({
    where: { id: session.user.id },
    select: {
      id: true, username: true, email: true, role: true, avatar: true,
      badges: true, bio: true, socialLinks: true, isVerified: true, sellerLevel: true, totalSales: true,
      walletBalance: true, createdAt: true,
      _count: { select: { items: true, followers: true, following: true, reviews: true } }
    }
  })

  const profile = await db.profile.findUnique({
    where: { userId: session.user.id }
  })

  const badgeIds = parseBadgeIds((user as any).badges)
  const badgeDetails = await getBadgeDetailsByIds(badgeIds)

  return NextResponse.json({ 
    ...user, 
    displayName: profile?.displayName,
    website: profile?.website,
    github: profile?.github,
    twitter: profile?.twitter,
    discord: profile?.discord,
    badges: badgeIds, 
    badgeDetails 
  })
}

export async function PATCH(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  try {
    const data = await req.json()
    const { bio, socialLinks, avatar, username, displayName, website, github, twitter, discord } = data

    const updateData: any = {}
    if (bio !== undefined) updateData.bio = bio || ''
    if (socialLinks !== undefined) {
      // Clean up social links - remove null values
      const cleanedLinks = Object.fromEntries(
        Object.entries(socialLinks)
          .filter(([_, v]) => v !== null && v !== undefined)
          .map(([k, v]) => [k, v])
      )
      updateData.socialLinks = cleanedLinks
    }
    if (avatar !== undefined) updateData.avatar = avatar
    if (username !== undefined) {
      // Check username availability
      const existing = await db.user.findFirst({ where: { username, NOT: { id: session.user.id } } })
      if (existing) return NextResponse.json({ error: 'Username already taken' }, { status: 400 })
      updateData.username = username
    }

    console.log('Updating user with:', updateData)

    const updated = await db.user.update({
      where: { id: session.user.id },
      data: updateData,
      select: {
        id: true, username: true, email: true, bio: true, avatar: true, socialLinks: true,
        badges: true, isVerified: true, sellerLevel: true, totalSales: true
      }
    })

    // Update or create profile
    const profileData: any = {}
    if (displayName !== undefined) profileData.displayName = displayName || null
    if (website !== undefined) profileData.website = website || null
    if (github !== undefined) profileData.github = github || null
    if (twitter !== undefined) profileData.twitter = twitter || null
    if (discord !== undefined) profileData.discord = discord || null

    if (Object.keys(profileData).length > 0) {
      await db.profile.upsert({
        where: { userId: session.user.id },
        update: profileData,
        create: { userId: session.user.id, ...profileData }
      })
    }

    const badgeIds = parseBadgeIds((updated as any).badges)
    const badgeDetails = await getBadgeDetailsByIds(badgeIds)

    return NextResponse.json({ ...updated, badges: badgeIds, badgeDetails })
  } catch (error) {
    console.error('Profile update error:', error)
    return NextResponse.json({ error: 'Failed to update profile' }, { status: 500 })
  }
}
