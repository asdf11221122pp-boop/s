import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export async function PATCH(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { badgeId, action } = await req.json()
  if (!badgeId || !action) return NextResponse.json({ error: 'Badge ID and action required' }, { status: 400 })
  if (!['equip', 'remove'].includes(action)) return NextResponse.json({ error: 'Invalid action' }, { status: 400 })

  const userBadge = await db.userBadge.findUnique({
    where: { userId_badgeId: { userId: session.user.id, badgeId } }
  })
  if (!userBadge) return NextResponse.json({ error: 'Badge not owned' }, { status: 404 })

  const updated = await db.userBadge.update({
    where: { userId_badgeId: { userId: session.user.id, badgeId } },
    data: { isEquipped: action === 'equip' }
  })

  return NextResponse.json({ success: true, userBadge: updated })
}

export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const userBadges = await db.userBadge.findMany({
    where: { userId: session.user.id },
    include: { badge: true },
    orderBy: { claimedAt: 'desc' }
  })

  return NextResponse.json({ userBadges })
}

export async function DELETE(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { badgeId } = await req.json()
  if (!badgeId) return NextResponse.json({ error: 'Badge ID required' }, { status: 400 })

  await db.userBadge.deleteMany({ where: { userId: session.user.id, badgeId } })
  return NextResponse.json({ success: true })
}
