import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { parseBadgeIds } from '@/lib/badge-utils'

/**
 * Get badges that user can claim based on their achievements
 */
export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // Get user's current badges
    const user = await db.user.findUnique({
      where: { id: session.user.id },
      select: {
        badges: true,
        totalSales: true,
        userBadges: { select: { badgeId: true } },
        _count: {
          select: {
            items: true,
            reviews: true,
            downloadRecords: true,
            followers: true,
            following: true,
          },
        },
      },
    })

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    // Get all available badges
    const allBadges = await db.badge.findMany({
      where: { isActive: true },
      select: {
        id: true,
        name: true,
        description: true,
        icon: true,
        color: true,
        criteria: true,
        isAutomatic: true,
      },
    })

    // Combine both badge sources for owned check
    const jsonBadgeIds = parseBadgeIds(user.badges)
    const tableBadgeIds = user.userBadges.map(ub => ub.badgeId)
    const currentBadgeIds = [...new Set([...jsonBadgeIds, ...tableBadgeIds])]
    const currentSet = new Set(currentBadgeIds)

    // Evaluate which badges user can claim
    const claimableBadges = allBadges.filter((badge) => {
      if (currentSet.has(badge.id)) return false // Already has it

      // If badge has criteria, check if user meets it
      if (badge.criteria && badge.isAutomatic) {
        const criteria = badge.criteria.toLowerCase()
        
        // Parse and evaluate criteria
        if (criteria.includes('first review') && user._count.reviews >= 1) return true
        if (criteria.includes('first download') && user._count.downloadRecords >= 1) return true
        if (criteria.includes('first item') && user._count.items >= 1) return true
        if (criteria.includes('first follow') && user._count.following >= 1) return true
        if (criteria.includes('first follower') && user._count.followers >= 1) return true
        if (criteria.includes('first sale') && user.totalSales >= 1) return true
        
        // Parse numeric criteria
        const reviewMatch = criteria.match(/(\d+)\s*review/)
        if (reviewMatch && user._count.reviews >= parseInt(reviewMatch[1])) return true

        const downloadMatch = criteria.match(/(\d+)\s*download/)
        if (downloadMatch && user._count.downloadRecords >= parseInt(downloadMatch[1])) return true

        const saleMatch = criteria.match(/(\d+)\s*(sale|sell|sold|deliver)/)
        if (saleMatch && user.totalSales >= parseInt(saleMatch[1])) return true

        const followingMatch = criteria.match(/(\d+)\s*following/)
        if (followingMatch && user._count.following >= parseInt(followingMatch[1])) return true

        const followerMatch = criteria.match(/(\d+)\s*follower/)
        if (followerMatch && user._count.followers >= parseInt(followerMatch[1])) return true
      }

      return false
    })

    return NextResponse.json({ claimableBadges })
  } catch (error) {
    console.error('Error fetching claimable badges:', error)
    return NextResponse.json(
      { error: 'Failed to fetch claimable badges' },
      { status: 500 }
    )
  }
}

/**
 * Claim a badge - manual claiming for badges the user qualifies for
 */
export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { badgeId } = await req.json()
    if (!badgeId) {
      return NextResponse.json({ error: 'Badge ID required' }, { status: 400 })
    }

    // Get user and badge
    const user = await db.user.findUnique({
      where: { id: session.user.id },
      select: { badges: true, userBadges: { select: { badgeId: true } } },
    })

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    const badge = await db.badge.findUnique({
      where: { id: badgeId },
      select: { id: true, name: true, isActive: true },
    })

    if (!badge || !badge.isActive) {
      return NextResponse.json({ error: 'Badge not found' }, { status: 404 })
    }

    // Check both badge storage systems
    const jsonBadgeIds = parseBadgeIds(user.badges)
    const tableBadgeIds = user.userBadges.map(ub => ub.badgeId)
    if (jsonBadgeIds.includes(badgeId) || tableBadgeIds.includes(badgeId)) {
      return NextResponse.json({ error: 'Badge already claimed' }, { status: 400 })
    }

    // Create UserBadge record (new system — supports equip/unequip via /api/badges/manage)
    await db.userBadge.create({
      data: { userId: session.user.id, badgeId, isEquipped: false }
    })

    // Also update legacy JSON field for backward compatibility
    const updatedBadges = [...jsonBadgeIds, badgeId]
    await db.user.update({
      where: { id: session.user.id },
      data: { badges: updatedBadges },
    })

    return NextResponse.json({ success: true, message: `Badge "${badge.name}" claimed successfully!` })
  } catch (error) {
    console.error('Error claiming badge:', error)
    return NextResponse.json({ error: 'Failed to claim badge' }, { status: 500 })
  }
}
