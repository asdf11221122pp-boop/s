import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import crypto from 'crypto'

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  try {
    const user = await db.user.findUnique({
      where: { id: session.user.id },
      select: { referralCode: true, referralEarnings: true }
    })

    const referralCount = await db.user.count({
      where: { referredById: session.user.id }
    })

    const referrals = await db.user.findMany({
      where: { referredById: session.user.id },
      select: { id: true, username: true, avatar: true, createdAt: true },
      orderBy: { createdAt: 'desc' },
      take: 50
    })

    return NextResponse.json({
      referralCode: user?.referralCode,
      referralEarnings: user?.referralEarnings || 0,
      referralCount,
      referrals
    })
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch referrals' }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  try {
    const { action, referralCode } = await req.json()

    if (action === 'generate') {
      const user = await db.user.findUnique({ where: { id: session.user.id }, select: { referralCode: true } })
      if (user?.referralCode) {
        return NextResponse.json({ referralCode: user.referralCode })
      }
      const code = session.user.username?.toUpperCase().slice(0, 6) + '-' + crypto.randomBytes(3).toString('hex').toUpperCase()
      await db.user.update({ where: { id: session.user.id }, data: { referralCode: code } })
      return NextResponse.json({ referralCode: code })
    }

    if (action === 'apply' && referralCode) {
      const user = await db.user.findUnique({ where: { id: session.user.id }, select: { referredById: true } })
      if (user?.referredById) {
        return NextResponse.json({ error: 'Already referred' }, { status: 400 })
      }

      const referrer = await db.user.findFirst({ where: { referralCode } })
      if (!referrer) return NextResponse.json({ error: 'Invalid referral code' }, { status: 404 })
      if (referrer.id === session.user.id) return NextResponse.json({ error: 'Cannot refer yourself' }, { status: 400 })

      await db.user.update({
        where: { id: session.user.id },
        data: { referredById: referrer.id }
      })

      const bonusAmount = 5.0
      await db.user.update({
        where: { id: referrer.id },
        data: {
          walletBalance: { increment: bonusAmount },
          referralEarnings: { increment: bonusAmount }
        }
      })

      await db.user.update({
        where: { id: session.user.id },
        data: { walletBalance: { increment: 2.0 } }
      })

      return NextResponse.json({ success: true, message: 'Referral applied! You got $2 bonus!' })
    }

    return NextResponse.json({ error: 'Invalid action' }, { status: 400 })
  } catch (error) {
    return NextResponse.json({ error: 'Failed to process referral' }, { status: 500 })
  }
}
