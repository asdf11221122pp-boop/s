import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import bcrypt from 'bcryptjs'

export async function POST(request: Request) {
  try {
    const { email, password, username, referralCode } = await request.json()

    if (!email || !password || !username) {
      return NextResponse.json(
        { error: 'Email, password, and username are required' },
        { status: 400 }
      )
    }

    if (password.length < 6) {
      return NextResponse.json(
        { error: 'Password must be at least 6 characters' },
        { status: 400 }
      )
    }

    if (!email.includes('@')) {
      return NextResponse.json(
        { error: 'Please enter a valid email address' },
        { status: 400 }
      )
    }

    const existingUser = await db.user.findFirst({
      where: {
        OR: [
          { email: email.toLowerCase() },
          { username }
        ]
      }
    })

    if (existingUser) {
      return NextResponse.json(
        { error: 'User with this email or username already exists' },
        { status: 400 }
      )
    }

    const hashedPassword = await bcrypt.hash(password, 12)

    let referrerId: string | undefined
    if (referralCode) {
      const referrer = await db.user.findFirst({
        where: { referralCode: referralCode.trim() }
      })
      if (referrer) {
        referrerId = referrer.id
      }
    }

    const user = await db.user.create({
      data: {
        email: email.toLowerCase(),
        username,
        password: hashedPassword,
        role: 'USER',
        ...(referrerId ? { referredById: referrerId } : {})
      }
    })

    if (referrerId) {
      try {
        await db.user.update({
          where: { id: referrerId },
          data: {
            walletBalance: { increment: 5.0 },
            referralEarnings: { increment: 5.0 }
          }
        })
        await db.user.update({
          where: { id: user.id },
          data: { walletBalance: { increment: 2.0 } }
        })
        await db.notification.create({
          data: {
            userId: referrerId,
            title: 'New Referral!',
            content: `${username} signed up with your referral code! You earned $5.00`,
            type: 'REFERRAL_BONUS' as any
          }
        })
      } catch (refError) {
        console.error('Referral bonus error:', refError)
      }
    }

    return NextResponse.json({
      message: 'User created successfully',
      user: {
        id: user.id,
        email: user.email,
        username: user.username,
        role: user.role
      }
    }, { status: 201 })
  } catch (error) {
    console.error('Registration error:', error instanceof Error ? error.message : error)
    return NextResponse.json(
      { error: 'Failed to create user. Please try again.' },
      { status: 500 }
    )
  }
}