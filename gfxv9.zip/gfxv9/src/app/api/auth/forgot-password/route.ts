import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import crypto from 'crypto'
import nodemailer from 'nodemailer'

export async function POST(req: NextRequest) {
  try {
    const { email } = await req.json()

    if (!email) {
      return NextResponse.json({ error: 'Email is required' }, { status: 400 })
    }

    // Check if user exists
    const user = await db.user.findUnique({
      where: { email },
      select: { id: true, email: true }
    })

    if (!user) {
      // Don't reveal if email exists or not for security
      return NextResponse.json({ success: true })
    }

    // Generate reset token and expiry (1 hour)
    const token = crypto.randomBytes(32).toString('hex')
    const expiresAt = new Date(Date.now() + 60 * 60 * 1000) // 1 hour

    await db.user.update({
      where: { email },
      data: {
        passwordResetToken: token,
        passwordResetTokenExpiry: expiresAt
      }
    })

    const frontendUrl = process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'
    const resetLink = `${frontendUrl}/auth/reset-password?token=${token}`

    // send email with nodemailer
    try {
      const transporter = nodemailer.createTransport({
        host: process.env.SMTP_HOST,
        port: Number(process.env.SMTP_PORT || 587),
        secure: process.env.SMTP_SECURE === 'true',
        auth: {
          user: process.env.SMTP_USER,
          pass: process.env.SMTP_PASS
        }
      })

      const mailOptions = {
        from: process.env.EMAIL_FROM || 'no-reply@example.com',
        to: email,
        subject: 'GfxStore Password Reset',
        html: `<p>You requested a password reset. Click the link below:</p><p><a href="${resetLink}">${resetLink}</a></p><p>If you did not request this, ignore this email.</p>`
      }

      await transporter.sendMail(mailOptions)
    } catch (emailError) {
      console.error('Forgot password email send failure:', emailError)
      // continue to avoid leaking whether user exists
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Forgot password error:', error)
    return NextResponse.json({ error: 'Failed to process request' }, { status: 500 })
  }
}