import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  try {
    const ownedTeams = await db.team.findMany({
      where: { ownerId: session.user.id },
      include: {
        owner: { select: { id: true, username: true, avatar: true } },
        members: { include: { user: { select: { id: true, username: true, avatar: true } } } }
      }
    })

    const memberTeams = await db.teamMember.findMany({
      where: { userId: session.user.id },
      include: {
        team: {
          include: {
            owner: { select: { id: true, username: true, avatar: true } },
            members: { include: { user: { select: { id: true, username: true, avatar: true } } } }
          }
        }
      }
    })

    return NextResponse.json({ ownedTeams, memberTeams })
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch teams' }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  try {
    const { name, description, memberUsernames } = await req.json()

    const team = await db.team.create({
      data: {
        name,
        description: description || '',
        ownerId: session.user.id,
        members: {
          create: { userId: session.user.id, role: 'OWNER' }
        }
      }
    })

    if (memberUsernames?.length) {
      for (const username of memberUsernames) {
        const user = await db.user.findUnique({ where: { username } })
        if (user && user.id !== session.user.id) {
          await db.teamMember.create({
            data: { teamId: team.id, userId: user.id, role: 'MEMBER' }
          }).catch(() => {})
        }
      }
    }

    return NextResponse.json({ team })
  } catch (error) {
    return NextResponse.json({ error: 'Failed to create team' }, { status: 500 })
  }
}
