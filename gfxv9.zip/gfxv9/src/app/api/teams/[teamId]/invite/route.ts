import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export async function POST(request: NextRequest, { params }: { params: Promise<{ teamId: string }> }) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { teamId } = await params

  const team = await db.team.findUnique({
    where: { id: teamId },
    include: { members: { select: { userId: true, role: true } } }
  })
  if (!team) return NextResponse.json({ error: 'Team not found' }, { status: 404 })

  const myMembership = team.members.find((m: any) => m.userId === session.user.id)
  const isMod = team.ownerId === session.user.id || myMembership?.role === 'MODERATOR'
  if (!isMod) return NextResponse.json({ error: 'Only team owner/moderator can invite' }, { status: 403 })

  const { username } = await request.json().catch(() => ({}))
  if (!username) return NextResponse.json({ error: 'Username required' }, { status: 400 })

  const invitee = await db.user.findUnique({ where: { username } })
  if (!invitee) return NextResponse.json({ error: 'User not found' }, { status: 404 })
  if (invitee.id === session.user.id) return NextResponse.json({ error: 'Cannot invite yourself' }, { status: 400 })

  const alreadyMember = team.members.some((m: any) => m.userId === invitee.id)
  if (alreadyMember) return NextResponse.json({ error: 'User is already a member' }, { status: 400 })

  const invite = await db.teamInvite.upsert({
    where: { teamId_inviteeId: { teamId, inviteeId: invitee.id } },
    create: { teamId, inviterId: session.user.id, inviteeId: invitee.id, status: 'PENDING' },
    update: { status: 'PENDING', inviterId: session.user.id }
  })

  await db.notification.create({
    data: {
      userId: invitee.id,
      type: 'TEAM_INVITE',
      message: `${session.user.name || 'Someone'} invited you to join team "${team.name}"`,
      link: '/teams',
      metadata: JSON.stringify({ teamId, inviteId: invite.id })
    }
  }).catch(() => {})

  return NextResponse.json({ invite, message: `Invite sent to @${username}` })
}

export async function DELETE(request: NextRequest, { params }: { params: Promise<{ teamId: string }> }) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { teamId } = await params
  const { inviteeId } = await request.json().catch(() => ({}))

  const team = await db.team.findUnique({ where: { id: teamId } })
  if (!team || team.ownerId !== session.user.id) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  await db.teamInvite.deleteMany({ where: { teamId, inviteeId } })
  return NextResponse.json({ success: true })
}
