import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export async function GET(request: NextRequest, { params }: { params: Promise<{ teamId: string }> }) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { teamId } = await params
  const team = await db.team.findUnique({
    where: { id: teamId },
    include: {
      owner: { select: { id: true, username: true, avatar: true } },
      members: {
        include: { user: { select: { id: true, username: true, avatar: true, isVerified: true } } },
        orderBy: { createdAt: 'asc' }
      },
      invites: {
        where: { status: 'PENDING' },
        include: {
          invitee: { select: { id: true, username: true, avatar: true } },
          inviter: { select: { id: true, username: true } }
        }
      }
    }
  })
  if (!team) return NextResponse.json({ error: 'Not found' }, { status: 404 })

  return NextResponse.json({ team })
}

export async function PATCH(request: NextRequest, { params }: { params: Promise<{ teamId: string }> }) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { teamId } = await params
  const data = await request.json().catch(() => ({}))

  const team = await db.team.findUnique({
    where: { id: teamId },
    include: { members: { select: { userId: true, role: true } } }
  })
  if (!team) return NextResponse.json({ error: 'Team not found' }, { status: 404 })

  const isOwner = team.ownerId === session.user.id

  if (data.action === 'kick' && data.userId) {
    if (!isOwner) return NextResponse.json({ error: 'Only owner can kick' }, { status: 403 })
    if (data.userId === session.user.id) return NextResponse.json({ error: 'Cannot kick yourself' }, { status: 400 })
    await db.teamMember.deleteMany({ where: { teamId, userId: data.userId } })
    return NextResponse.json({ success: true, message: 'Member removed' })
  }

  if (data.action === 'changeRole' && data.userId && data.role) {
    if (!isOwner) return NextResponse.json({ error: 'Only owner can change roles' }, { status: 403 })
    await db.teamMember.updateMany({
      where: { teamId, userId: data.userId },
      data: { role: data.role }
    })
    return NextResponse.json({ success: true, message: 'Role updated' })
  }

  if (data.action === 'leave') {
    if (isOwner) return NextResponse.json({ error: 'Owner cannot leave. Transfer ownership or disband team.' }, { status: 400 })
    await db.teamMember.deleteMany({ where: { teamId, userId: session.user.id } })
    return NextResponse.json({ success: true, message: 'Left team' })
  }

  if (data.action === 'transferOwnership' && data.userId) {
    if (!isOwner) return NextResponse.json({ error: 'Only owner can transfer' }, { status: 403 })
    const isMember = team.members.some((m: any) => m.userId === data.userId)
    if (!isMember) return NextResponse.json({ error: 'User is not a member' }, { status: 400 })
    await db.team.update({ where: { id: teamId }, data: { ownerId: data.userId } })
    await db.teamMember.updateMany({ where: { teamId, userId: data.userId }, data: { role: 'OWNER' } })
    await db.teamMember.updateMany({ where: { teamId, userId: session.user.id }, data: { role: 'MEMBER' } })
    return NextResponse.json({ success: true, message: 'Ownership transferred' })
  }

  if (isOwner) {
    const updateData: any = {}
    if (data.name) updateData.name = data.name
    if (data.description !== undefined) updateData.description = data.description
    if (data.avatar !== undefined) updateData.avatar = data.avatar
    const updated = await db.team.update({ where: { id: teamId }, data: updateData })
    return NextResponse.json({ team: updated })
  }

  return NextResponse.json({ error: 'Invalid action' }, { status: 400 })
}

export async function DELETE(request: NextRequest, { params }: { params: Promise<{ teamId: string }> }) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { teamId } = await params
  const team = await db.team.findUnique({ where: { id: teamId } })
  if (!team) return NextResponse.json({ error: 'Not found' }, { status: 404 })
  if (team.ownerId !== session.user.id) return NextResponse.json({ error: 'Only owner can disband' }, { status: 403 })

  await db.team.delete({ where: { id: teamId } })
  return NextResponse.json({ success: true, message: 'Team disbanded' })
}
