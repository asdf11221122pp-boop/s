import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { maybeAwardBadges } from '@/lib/badge-awarder'

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const body = await req.json()
  // Frontend uses `followingId`, but older code expects `userId`.
  const userId = body.userId || body.followingId
  if (!userId) return NextResponse.json({ error: 'User ID required' }, { status: 400 })
  if (userId === session.user.id) return NextResponse.json({ error: 'Cannot follow yourself' }, { status: 400 })

  const existing = await db.follow.findUnique({
    where: { followerId_followingId: { followerId: session.user.id, followingId: userId } }
  })

  if (existing) {
    await db.follow.delete({ where: { followerId_followingId: { followerId: session.user.id, followingId: userId } } })
    return NextResponse.json({ following: false })
  }

  await db.follow.create({ data: { followerId: session.user.id, followingId: userId } })
  await maybeAwardBadges(session.user.id)
  return NextResponse.json({ following: true })
}

export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const { searchParams } = new URL(req.url)
  const userId = searchParams.get('userId') || session.user.id

  const [followers, following] = await Promise.all([
    db.follow.count({ where: { followingId: userId } }),
    db.follow.count({ where: { followerId: userId } })
  ])

  const isFollowing = session.user.id !== userId
    ? !!(await db.follow.findUnique({ where: { followerId_followingId: { followerId: session.user.id, followingId: userId } } }))
    : false

  return NextResponse.json({ followers, following, isFollowing })
}
