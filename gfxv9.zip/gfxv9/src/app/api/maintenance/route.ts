import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

/**
 * Public maintenance flag.
 * Used by middleware to redirect users to `/maintenance` when admin enables maintenance mode.
 */
export async function GET() {
  try {
    const settings = await db.siteSettings.findFirst()
    return NextResponse.json({ maintenance: settings?.maintenance ?? false })
  } catch {
    return NextResponse.json({ maintenance: false })
  }
}

