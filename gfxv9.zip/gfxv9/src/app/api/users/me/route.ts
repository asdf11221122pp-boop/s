import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { getBadgeDetailsByIds, parseBadgeIds } from '@/lib/badge-utils'

export async function GET() {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const user = await db.user.findUnique({
      where: { id: session.user.id },
      include: {
        _count: { select: { items: true, followers: true, following: true, reviews: true, downloadRecords: true } },
        userBadges: {
          include: { badge: { select: { id: true, name: true, icon: true, color: true, description: true } } },
          orderBy: { claimedAt: 'desc' }
        }
      }
    })

    if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 })

    const badgeIds = parseBadgeIds((user as any).badges)
    const badgeDetails = await getBadgeDetailsByIds(badgeIds)

    const membership = await db.membership.findFirst({
      where: { roleName: user.role, isActive: true },
      select: { id: true, name: true, color: true, features: true }
    }).catch(() => null)

    return NextResponse.json({
      id: user.id, username: user.username, email: user.email,
      role: user.role, avatar: user.avatar, bio: user.bio,
      socialLinks: user.socialLinks, isVerified: user.isVerified,
      sellerLevel: user.sellerLevel, totalSales: user.totalSales,
      walletBalance: user.walletBalance, createdAt: user.createdAt,
      lastRewardClaim: user.lastRewardClaim,
      badges: badgeIds,
      badgeDetails,
      userBadges: user.userBadges.map(ub => ({
        id: ub.id,
        badgeId: ub.badgeId,
        isEquipped: ub.isEquipped,
        claimedAt: ub.claimedAt,
        badge: ub.badge
      })),
      membership,
      _count: {
        items: user._count.items,
        followers: user._count.followers,
        following: user._count.following,
        reviews: user._count.reviews,
        downloads: user._count.downloadRecords
      }
    })
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch user' }, { status: 500 })
  }
}
