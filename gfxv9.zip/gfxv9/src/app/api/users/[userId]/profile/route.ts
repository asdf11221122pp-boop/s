import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { parseBadgeIds, getBadgeDetailsByIds } from '@/lib/badge-utils'

export async function GET(
  request: Request,
  { params }: { params: Promise<{ userId: string }> }
) {
  try {
    const { userId } = await params

    const profile = await db.user.findFirst({
      where: { OR: [{ id: userId }, { username: userId }] },
      include: {
        items: {
          where: { status: 'APPROVED' },
          take: 20,
          orderBy: { createdAt: 'desc' },
          include: {
            category: { select: { name: true, slug: true } },
            screenshots: { orderBy: { sortOrder: 'asc' }, take: 1 },
            _count: { select: { reviews: true } }
          }
        },
        _count: { select: { items: true, downloadRecords: true, reviews: true, followers: true, following: true } }
      }
    })

    if (!profile) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    const badgeIds = parseBadgeIds((profile as any).badges)
    const badgeDetails = await getBadgeDetailsByIds(badgeIds)

    return NextResponse.json({
      id: profile.id, username: profile.username, role: profile.role,
      avatar: profile.avatar, bio: profile.bio, socialLinks: profile.socialLinks,
      isVerified: profile.isVerified, sellerLevel: profile.sellerLevel,
      totalSales: profile.totalSales, createdAt: profile.createdAt,
      badges: badgeIds,
      badgeDetails: badgeDetails,
      items: profile.items.map(item => ({
        ...item,
        logo: item.logo || (item.screenshots[0]?.url) || '/placeholder-item.png'
      })),
      _count: {
        items: profile._count.items,
        downloads: profile._count.downloadRecords,
        reviews: profile._count.reviews,
        followers: profile._count.followers,
        following: profile._count.following
      }
    })
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch profile' }, { status: 500 })
  }
}
