import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getServerSession } from 'next-auth/next'
import { authOptions } from '@/lib/auth'
import { writeFile, mkdir } from 'fs/promises'
import path from 'path'
import crypto from 'crypto'

export async function GET() {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const profile = await db.user.findUnique({
      where: { id: session.user.id },
      include: {
        _count: { select: { items: true, downloadRecords: true, reviews: true } }
      }
    })

    if (!profile) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    return NextResponse.json({
      id: profile.id, username: profile.username, email: profile.email,
      role: profile.role, avatar: profile.avatar, bio: profile.bio,
      socialLinks: profile.socialLinks, isVerified: profile.isVerified,
      sellerLevel: profile.sellerLevel, totalSales: profile.totalSales,
      walletBalance: profile.walletBalance, createdAt: profile.createdAt,
      _count: {
        items: profile._count.items,
        downloads: profile._count.downloadRecords,
        reviews: profile._count.reviews
      }
    })
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch profile' }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const formData = await request.formData()
    const bio = formData.get('bio') as string
    const socialLinksStr = formData.get('socialLinks') as string
    const avatarFile = formData.get('avatar') as File | null

    let socialLinks = {}
    try { socialLinks = socialLinksStr ? JSON.parse(socialLinksStr) : {} } catch { socialLinks = {} }

    const updateData: any = { bio, socialLinks }

    if (avatarFile && avatarFile.size > 0) {
      const uploadsDir = path.join(process.cwd(), 'public', 'uploads', 'avatars')
      await mkdir(uploadsDir, { recursive: true })
      const buffer = Buffer.from(await avatarFile.arrayBuffer())
      const fileName = `${crypto.randomUUID()}.jpg`
      await writeFile(path.join(uploadsDir, fileName), buffer)
      updateData.avatar = `/uploads/avatars/${fileName}`
    }

    const updatedProfile = await db.user.update({
      where: { id: session.user.id },
      data: updateData,
      include: { _count: { select: { items: true, downloadRecords: true, reviews: true } } }
    })

    return NextResponse.json({
      id: updatedProfile.id, username: updatedProfile.username, email: updatedProfile.email,
      role: updatedProfile.role, avatar: updatedProfile.avatar, bio: updatedProfile.bio,
      socialLinks: updatedProfile.socialLinks, createdAt: updatedProfile.createdAt,
      _count: {
        items: updatedProfile._count.items,
        downloads: updatedProfile._count.downloadRecords,
        reviews: updatedProfile._count.reviews
      }
    })
  } catch (error) {
    return NextResponse.json({ error: 'Failed to update profile' }, { status: 500 })
  }
}
