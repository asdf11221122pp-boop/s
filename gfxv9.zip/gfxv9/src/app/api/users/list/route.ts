import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { parseBadgeIds, getBadgeDetailsByIds } from '@/lib/badge-utils'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const limit = Math.min(parseInt(searchParams.get('limit') || '50'), 100)
    const search = searchParams.get('search') || ''

    const whereClause: any = { isActive: true, isBanned: false }

    if (search) {
      whereClause.OR = [
        { username: { contains: search, mode: 'insensitive' } },
      ]
    }

    const users = await db.user.findMany({
      where: whereClause,
      select: {
        id: true, username: true, avatar: true, bio: true, badges: true,
        isVerified: true, sellerLevel: true, totalSales: true, createdAt: true,
        _count: { select: { items: true, followers: true } }
      },
      orderBy: [{ totalSales: 'desc' }, { createdAt: 'desc' }],
      take: limit
    })

    // Fetch badge details for all users
    const usersWithBadges = await Promise.all(
      users.map(async (user) => {
        const badgeIds = parseBadgeIds((user as any).badges)
        const badgeDetails = badgeIds.length > 0 ? await getBadgeDetailsByIds(badgeIds) : []
        return { ...user, badges: badgeIds, badgeDetails }
      })
    )

    return NextResponse.json({ users: usersWithBadges })
  } catch (error) {
    return NextResponse.json({ users: [] }, { status: 500 })
  }
}
