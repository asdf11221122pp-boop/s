import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'
import { checkFeature } from '@/lib/feature-toggles'
import { parseBadgeIds, getBadgeDetailsByIds } from '@/lib/badge-utils'

export async function GET(request: NextRequest) {
  try {
    const blocked = await checkFeature('friends', 'Friends System')
    if (blocked) return blocked
    
    const session = await getServerSession(authOptions)
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const user = await db.user.findUnique({
      where: { email: session.user.email }
    })

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    const page = Math.max(1, parseInt(request.nextUrl.searchParams.get('page') || '1'))
    const limit = Math.min(100, parseInt(request.nextUrl.searchParams.get('limit') || '20'))
    const skip = (page - 1) * limit
    const sortBy = request.nextUrl.searchParams.get('sortBy') || 'recent' // recent, popular, verified

    // Get users that current user is not already friends with
    const userFriendsIds = await db.friend.findMany({
      where: {
        OR: [
          { user1Id: user.id },
          { user2Id: user.id }
        ]
      },
      select: {
        user1Id: true,
        user2Id: true
      }
    })

    const friendIds = new Set<string>()
    userFriendsIds.forEach(f => {
      if (f.user1Id === user.id) friendIds.add(f.user2Id)
      else friendIds.add(f.user1Id)
    })

    // Build where clause based on sort type
    let orderBy: any = { createdAt: 'desc' }
    if (sortBy === 'popular') {
      orderBy = { followers: { _count: 'desc' } }
    } else if (sortBy === 'verified') {
      orderBy = { isVerified: 'desc' }
    }

    const total = await db.user.count({
      where: {
        AND: [
          {
            NOT: {
              id: user.id
            }
          },
          {
            NOT: {
              id: { in: Array.from(friendIds) }
            }
          },
          {
            isBanned: false
          },
          {
            isActive: true
          }
        ]
      }
    })

    // Get suggested users
    const suggestedUsers = await db.user.findMany({
      where: {
        AND: [
          {
            NOT: {
              id: user.id
            }
          },
          {
            NOT: {
              id: { in: Array.from(friendIds) }
            }
          },
          {
            isBanned: false
          },
          {
            isActive: true
          }
        ]
      },
      select: {
        id: true,
        username: true,
        avatar: true,
        bio: true,
        badges: true,
        isActive: true,
        isVerified: true,
        _count: {
          select: { followers: true }
        }
      },
      skip: skip,
      take: limit,
      orderBy: orderBy
    })

    const totalPages = Math.ceil(total / limit)

    // Fetch badge details for all users
    const usersWithBadges = await Promise.all(
      suggestedUsers.map(async (u) => {
        const badgeIds = parseBadgeIds((u as any).badges)
        const badgeDetails = badgeIds.length > 0 ? await getBadgeDetailsByIds(badgeIds) : []
        return {
          id: u.id,
          username: u.username,
          avatar: u.avatar,
          bio: u.bio,
          isActive: u.isActive,
          isVerified: u.isVerified,
          badges: badgeIds,
          badgeDetails,
          followers: u._count.followers
        }
      })
    )

    return NextResponse.json({
      users: usersWithBadges,
      total: total,
      count: suggestedUsers.length,
      page: page,
      limit: limit,
      totalPages: totalPages,
      hasNextPage: page < totalPages,
      hasPreviousPage: page > 1
    })
  } catch (error) {
    console.error('Error fetching discover users:', error)
    return NextResponse.json(
      { error: 'Failed to fetch suggested users' },
      { status: 500 }
    )
  }
}
