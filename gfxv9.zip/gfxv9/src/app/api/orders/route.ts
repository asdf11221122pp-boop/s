import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { maybeAwardBadges } from '@/lib/badge-awarder'

export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { searchParams } = new URL(req.url)
  const type = searchParams.get('type') || 'buyer'

  const orders = await db.order.findMany({
    where: type === 'seller' ? { sellerId: session.user.id } : { buyerId: session.user.id },
    include: {
      item: { select: { id: true, title: true, slug: true, logo: true, price: true } },
      buyer: { select: { id: true, username: true, avatar: true } },
      seller: { select: { id: true, username: true, avatar: true, isVerified: true, sellerLevel: true } },
      coupon: { select: { code: true, discountValue: true, discountType: true } }
    },
    orderBy: { createdAt: 'desc' }
  })

  return NextResponse.json({ orders })
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { itemId, couponCode } = await req.json()
  if (!itemId) return NextResponse.json({ error: 'Item ID required' }, { status: 400 })

  const item = await db.item.findUnique({
    where: { id: itemId },
    include: { author: { select: { id: true, username: true, walletBalance: true } } }
  })
  if (!item) return NextResponse.json({ error: 'Item not found' }, { status: 404 })
  if (item.authorId === session.user.id) return NextResponse.json({ error: 'Cannot buy your own item' }, { status: 400 })

  // Check if already ordered
  const existingOrder = await db.order.findFirst({ where: { buyerId: session.user.id, itemId, status: { not: 'CANCELLED' } } })
  if (existingOrder) return NextResponse.json({ error: 'You already purchased this item' }, { status: 400 })

  const buyer = await db.user.findUnique({ where: { id: session.user.id } })
  if (!buyer) return NextResponse.json({ error: 'User not found' }, { status: 404 })

  let finalAmount = item.price
  let couponId: string | undefined
  let discountAmount = 0

  // Apply coupon
  if (couponCode) {
    const coupon = await db.coupon.findUnique({ where: { code: couponCode.toUpperCase() } })
    if (coupon && coupon.isActive && (!coupon.expiresAt || coupon.expiresAt > new Date())) {
      if (!coupon.maxUsage || coupon.usageCount < coupon.maxUsage) {
        if (!coupon.minOrderAmount || item.price >= coupon.minOrderAmount) {
          if (coupon.discountType === 'PERCENTAGE') {
            discountAmount = item.price * (coupon.discountValue / 100)
          } else {
            discountAmount = Math.min(coupon.discountValue, item.price)
          }
          finalAmount = Math.max(0, item.price - discountAmount)
          couponId = coupon.id
        }
      }
    }
  }

  // Check wallet balance for paid items
  if (finalAmount > 0 && buyer.walletBalance < finalAmount) {
    return NextResponse.json({ error: 'Insufficient wallet balance' }, { status: 400 })
  }

  // Create order and process payment in a transaction
  const order = await db.$transaction(async (tx) => {
    const newOrder = await tx.order.create({
      data: {
        buyerId: session.user.id,
        sellerId: item.authorId,
        itemId: item.id,
        amount: finalAmount,
        discountAmount,
        couponId,
        status: item.price === 0 ? 'DELIVERED' : 'PENDING',
        deliveredAt: item.price === 0 ? new Date() : null
      }
    })

    // Deduct from buyer wallet
    if (finalAmount > 0) {
      await tx.user.update({ where: { id: session.user.id }, data: { walletBalance: { decrement: finalAmount } } })
      // Credit seller (90% commission, 10% platform fee)
      const sellerEarnings = finalAmount * 0.9
      await tx.user.update({ where: { id: item.authorId }, data: { walletBalance: { increment: sellerEarnings }, totalSales: { increment: 1 } } })
    } else {
      await tx.user.update({ where: { id: item.authorId }, data: { totalSales: { increment: 1 } } })
    }

    // Update coupon usage
    if (couponId) {
      await tx.coupon.update({ where: { id: couponId }, data: { usageCount: { increment: 1 } } })
    }

    return newOrder
  })

  // Auto-award for free items (order is instantly DELIVERED in this code path).
  if (order.status === 'DELIVERED') {
    await maybeAwardBadges(session.user.id) // buyer
    await maybeAwardBadges(item.authorId) // seller
  }

  return NextResponse.json({ order, message: 'Order placed successfully!' })
}
