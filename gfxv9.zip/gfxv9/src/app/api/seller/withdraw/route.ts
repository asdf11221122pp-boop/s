import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

const MIN_WITHDRAW = 5
const MAX_WITHDRAW_PENDING = 1 // max 1 pending request at a time

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const requests = await db.withdrawRequest.findMany({
    where: { userId: session.user.id },
    orderBy: { createdAt: 'desc' }
  })

  return NextResponse.json({ requests })
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { amount, method, accountInfo } = await req.json()
  if (!amount || !method || !accountInfo) return NextResponse.json({ error: 'All fields required' }, { status: 400 })
  if (parseFloat(amount) < MIN_WITHDRAW) return NextResponse.json({ error: `Minimum withdrawal is $${MIN_WITHDRAW}` }, { status: 400 })

  const user = await db.user.findUnique({ where: { id: session.user.id } })
  if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 })
  if (user.walletBalance < parseFloat(amount)) return NextResponse.json({ error: 'Insufficient wallet balance' }, { status: 400 })

  // Check for pending requests
  const pending = await db.withdrawRequest.count({ where: { userId: session.user.id, status: 'PENDING' } })
  if (pending >= MAX_WITHDRAW_PENDING) return NextResponse.json({ error: 'You already have a pending withdrawal request' }, { status: 400 })

  const request = await db.$transaction(async (tx) => {
    const req = await tx.withdrawRequest.create({
      data: { userId: session.user.id, amount: parseFloat(amount), method, accountInfo }
    })
    // Hold the amount (deduct from balance)
    await tx.user.update({ where: { id: session.user.id }, data: { walletBalance: { decrement: parseFloat(amount) } } })
    return req
  })

  return NextResponse.json({ request, message: 'Withdrawal request submitted. Admin will process within 24-48 hours.' })
}
