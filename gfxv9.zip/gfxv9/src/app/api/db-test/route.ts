import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    // Test database connection
    await db.$connect()
    
    // Get user count
    const userCount = await db.user.count()
    
    // Get category count
    const categoryCount = await db.category.count()
    
    await db.$disconnect()
    
    return NextResponse.json({
      status: 'success',
      message: 'Database connection successful',
      data: {
        userCount,
        categoryCount,
        timestamp: new Date().toISOString()
      }
    })
  } catch (error) {
    return NextResponse.json(
      { 
        status: 'error', 
        message: 'Database connection failed',
        error: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    )
  }
}