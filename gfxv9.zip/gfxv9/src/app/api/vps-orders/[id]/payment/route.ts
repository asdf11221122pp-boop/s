import { NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { id } = await params
    const order = await db.vPSOrder.findUnique({ where: { id } })
    if (!order || order.userId !== session.user.id) {
      return NextResponse.json({ error: 'Not found' }, { status: 404 })
    }

    const body = await request.json()
    const { transactionRef } = body

    await db.vPSOrder.update({
      where: { id },
      data: { transactionRef }
    })

    // notify admins that payment info has been submitted
    if ((global as any).broadcastToAdmins) {
      await (global as any).broadcastToAdmins({
        type: 'VPS_ORDER_SUBMITTED',
        payload: { orderId: id }
      })
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error submitting payment', error)
    return NextResponse.json({ error: 'Failed to submit payment' }, { status: 500 })
  }
}
