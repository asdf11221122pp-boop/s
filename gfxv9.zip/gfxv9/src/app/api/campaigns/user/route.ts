import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

/**
 * GET: Get all active campaigns for user
 */
export async function GET() {
  try {
    const now = new Date()
    const campaigns = await db.campaign.findMany({
      where: { isActive: true },
      orderBy: { startDate: 'desc' }
    })

    // Get user's claimed campaigns if authenticated
    let claimed: string[] = []
    const session = await getServerSession(authOptions)
    if (session?.user?.id) {
      const user = await db.user.findUnique({
        where: { id: session.user.id },
        select: { claimedCampaigns: true }
      })
      if (user?.claimedCampaigns) {
        claimed = Array.isArray(user.claimedCampaigns) ? user.claimedCampaigns as string[] : []
      }
    }

    return NextResponse.json({ campaigns, claimed })
  } catch (error) {
    console.error('Error fetching campaigns:', error)
    return NextResponse.json({ campaigns: [], claimed: [] })
  }
}
