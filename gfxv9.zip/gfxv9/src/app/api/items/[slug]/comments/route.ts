import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { checkFeature } from '@/lib/feature-toggles'

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ slug: string }> }
) {
  try {
    const blocked = await checkFeature('reviews', 'Reviews & Ratings')
    if (blocked) return blocked
    
    const { slug } = await params

    const item = await db.item.findUnique({
      where: { slug },
    })

    if (!item) {
      return NextResponse.json(
        { error: 'Item not found' },
        { status: 404 }
      )
    }

    const reviews = await db.review.findMany({
      where: { itemId: item.id },
      include: {
        user: {
          select: { id: true, username: true, avatar: true }
        }
      },
      orderBy: { createdAt: 'desc' }
    })

    return NextResponse.json(reviews)
  } catch (error) {
    console.error('Error fetching comments:', error)
    return NextResponse.json(
      { error: 'Failed to fetch comments' },
      { status: 500 }
    )
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ slug: string }> }
) {
  try {
    const blocked = await checkFeature('reviews', 'Reviews & Ratings')
    if (blocked) return blocked
    
    const session = await getServerSession(authOptions)
    
    if (!session?.user || !session?.user?.id) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      )
    }

    const { slug } = await params
    const { rating, comment } = await request.json()

    if (!comment || !rating) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      )
    }

    const item = await db.item.findUnique({
      where: { slug },
    })

    if (!item) {
      return NextResponse.json(
        { error: 'Item not found' },
        { status: 404 }
      )
    }

    const review = await db.review.create({
      data: {
        itemId: item.id,
        userId: session.user.id,
        rating: parseInt(rating),
        comment: comment.substring(0, 1000),
      },
      include: {
        user: {
          select: { id: true, username: true, avatar: true }
        }
      }
    })

    return NextResponse.json(review)
  } catch (error) {
    console.error('Error posting comment:', error)
    return NextResponse.json(
      { error: 'Failed to post comment' },
      { status: 500 }
    )
  }
}
