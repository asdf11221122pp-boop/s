import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { isFeatureEnabled } from '@/lib/feature-toggles'

export async function GET(request: NextRequest) {
  try {
    const url = new URL(request.url)
    const position = (url.searchParams.get('position') || 'homepage').toString()
    const limit = Math.min(parseInt(url.searchParams.get('limit') || '10', 10) || 10, 20)

    const featureEnabled = await isFeatureEnabled('ads')
    if (!featureEnabled) return NextResponse.json({ ads: [] })

    const now = new Date()

    const ads = await db.ad.findMany({
      where: {
        position,
        isActive: true,
        AND: [
          {
            OR: [{ startDate: null }, { startDate: { lte: now } }],
          },
          {
            OR: [{ endDate: null }, { endDate: { gte: now } }],
          },
        ],
      },
      orderBy: { sortOrder: 'asc' },
      take: limit,
      select: {
        id: true,
        title: true,
        description: true,
        imageUrl: true,
        linkUrl: true,
        position: true,
        sortOrder: true,
      },
    })

    // Track impressions asynchronously (don't wait)
    Promise.all(
      ads.map(ad =>
        db.ad.update({
          where: { id: ad.id },
          data: { impressions: { increment: 1 } }
        }).catch(() => null)
      )
    ).catch(() => null)

    return NextResponse.json({ ads })
  } catch {
    return NextResponse.json({ ads: [] })
  }
}

export const revalidate = 60

export async function POST(request: NextRequest) {
  try {
    const { adId } = await request.json()
    if (adId) {
      await db.ad.update({
        where: { id: adId },
        data: { clicks: { increment: 1 } }
      }).catch(() => null)
    }
    return NextResponse.json({ success: true })
  } catch {
    return NextResponse.json({ success: false })
  }
}

