'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { CheckCircle, Loader2, Star, Upload, User, ArrowLeft, Zap, Award, TrendingUp, DollarSign } from 'lucide-react'
import { toast } from 'sonner'

export default function SellerApplyPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [existing, setExisting] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [form, setForm] = useState({ displayName: '', portfolioUrl: '', experience: '' })

  useEffect(() => {
    if (status === 'unauthenticated') router.push('/auth/signin')
    if (status === 'authenticated') checkExisting()
  }, [status])

  const checkExisting = async () => {
    try {
      const res = await fetch('/api/seller/apply')
      if (res.ok) {
        const data = await res.json()
        setExisting(data.application)
        if (data.application) setForm({ displayName: data.application.displayName, portfolioUrl: data.application.portfolioUrl || '', experience: data.application.experience })
      }
    } catch {} finally { setLoading(false) }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!form.displayName || !form.experience) { toast.error('Please fill in all required fields'); return }
    setSubmitting(true)
    try {
      const res = await fetch('/api/seller/apply', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form)
      })
      const data = await res.json()
      if (res.ok) { toast.success(data.message); setExisting(data.application) }
      else toast.error(data.error || 'Failed to submit')
    } catch { toast.error('Error submitting application') } finally { setSubmitting(false) }
  }

  const perks = [
    { icon: <DollarSign className="h-4 w-4" />, title: 'Earn Money', desc: '90% commission on every sale' },
    { icon: <Award className="h-4 w-4" />, title: 'Verified Badge', desc: 'Gain trust and credibility' },
    { icon: <TrendingUp className="h-4 w-4" />, title: 'Analytics', desc: 'Track your sales & performance' },
    { icon: <Zap className="h-4 w-4" />, title: 'Priority Support', desc: 'Dedicated seller support' },
  ]

  return (
    <div className="min-h-screen bg-[#0a0a0f]">
      <Navbar />
      <div className="container mx-auto px-4 py-12 max-w-2xl">
        <Link href="/dashboard">
          <Button variant="ghost" size="sm" className="text-white/50 hover:text-white hover:bg-white/5 gap-2 mb-6 rounded-xl">
            <ArrowLeft className="w-4 h-4" /> Back to Dashboard
          </Button>
        </Link>

        <div className="text-center mb-10">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center mx-auto mb-4 shadow-lg shadow-purple-500/30">
            <Star className="h-8 w-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">Become a Seller</h1>
          <p className="text-white/50">Apply to start selling your Minecraft creations and earn money</p>
        </div>

        {/* Perks */}
        <div className="grid grid-cols-2 gap-3 mb-8">
          {perks.map((perk, i) => (
            <div key={i} className="bg-white/[0.03] border border-white/8 rounded-xl p-4">
              <div className="flex items-center gap-2 mb-1 text-purple-400">{perk.icon}<span className="font-semibold text-white text-sm">{perk.title}</span></div>
              <p className="text-white/40 text-xs">{perk.desc}</p>
            </div>
          ))}
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-12"><Loader2 className="w-6 h-6 animate-spin text-purple-400" /></div>
        ) : existing ? (
          <div className="bg-white/[0.03] border border-white/10 rounded-2xl p-8 text-center">
            {existing.status === 'APPROVED' ? (
              <>
                <CheckCircle className="w-16 h-16 mx-auto text-green-400 mb-4" />
                <h2 className="text-xl font-bold text-white mb-2">You&apos;re a Verified Seller!</h2>
                <p className="text-white/50 text-sm mb-4">Your application was approved. Start uploading and selling your content.</p>
                <Link href="/upload"><Button className="bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl">Upload Content</Button></Link>
              </>
            ) : existing.status === 'REJECTED' ? (
              <>
                <div className="w-16 h-16 rounded-full bg-red-500/20 flex items-center justify-center mx-auto mb-4">
                  <User className="w-8 h-8 text-red-400" />
                </div>
                <h2 className="text-xl font-bold text-white mb-2">Application Not Approved</h2>
                <p className="text-white/50 text-sm">{existing.adminNote || 'Your application was not approved at this time. Please try again later.'}</p>
              </>
            ) : (
              <>
                <div className="w-16 h-16 rounded-full bg-yellow-500/20 flex items-center justify-center mx-auto mb-4">
                  <Loader2 className="w-8 h-8 text-yellow-400 animate-spin" />
                </div>
                <h2 className="text-xl font-bold text-white mb-2">Application Under Review</h2>
                <p className="text-white/50 text-sm mb-4">We&apos;re reviewing your application. This usually takes 1-3 business days.</p>
                <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30">Pending Review</Badge>
              </>
            )}
          </div>
        ) : (
          <div className="bg-white/[0.03] border border-white/10 rounded-2xl p-8">
            <h2 className="text-lg font-semibold text-white mb-6">Application Form</h2>
            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="space-y-2">
                <Label className="text-white/70 text-sm">Display Name *</Label>
                <Input value={form.displayName} onChange={e => setForm(p => ({ ...p, displayName: e.target.value }))}
                  placeholder="Your creator name" className="h-11 bg-white/5 border-white/10 text-white placeholder:text-white/30 rounded-xl" required />
              </div>
              <div className="space-y-2">
                <Label className="text-white/70 text-sm">Portfolio URL</Label>
                <Input value={form.portfolioUrl} onChange={e => setForm(p => ({ ...p, portfolioUrl: e.target.value }))}
                  placeholder="https://yourportfolio.com" type="url" className="h-11 bg-white/5 border-white/10 text-white placeholder:text-white/30 rounded-xl" />
              </div>
              <div className="space-y-2">
                <Label className="text-white/70 text-sm">Tell us about your experience *</Label>
                <Textarea value={form.experience} onChange={e => setForm(p => ({ ...p, experience: e.target.value }))}
                  placeholder="Describe your Minecraft content creation experience, skills, and what you plan to sell..."
                  className="bg-white/5 border-white/10 text-white placeholder:text-white/30 rounded-xl min-h-[120px] resize-none" required />
              </div>
              <Button type="submit" disabled={submitting} className="w-full h-11 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 text-white border-0 rounded-xl font-semibold">
                {submitting ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Submitting...</> : <><Upload className="w-4 h-4 mr-2" />Submit Application</>}
              </Button>
            </form>
          </div>
        )}
      </div>
      <Footer />
    </div>
  )
}
