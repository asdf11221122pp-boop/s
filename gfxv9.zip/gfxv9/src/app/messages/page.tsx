'use client'

import { useState } from 'react'
import Link from 'next/link'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { useEffect } from 'react'
import { Navbar } from '@/components/navbar'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Button } from '@/components/ui/button'
import { FriendRequestList } from '@/components/messaging/friend-request-list'
import { FriendList } from '@/components/messaging/friend-list'
import { PrivateChat } from '@/components/messaging/private-chat'
import { UserSearch } from '@/components/messaging/user-search'
import { MessageCircle, Users, Search, ArrowLeft } from 'lucide-react'

interface Friend {
  id: string
  username: string
  avatar?: string
  bio?: string
  isActive: boolean
}

export default function MessagesPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [selectedFriend, setSelectedFriend] = useState<Friend | null>(null)
  const [activeTab, setActiveTab] = useState('messages')

  useEffect(() => {
    if (status === 'unauthenticated') router.push('/auth/signin')
  }, [status])

  // ❌ REMOVE LOOP USEEFFECT (FIXED)

  return (
    <div className="min-h-screen bg-[#0a0a0f]">
      <Navbar />
      <div className="container mx-auto px-4 py-8 max-w-7xl">

        {/* Header */}
        <div className="mb-6 flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <MessageCircle className="w-5 h-5 text-purple-400" />
              <span className="text-sm font-medium text-purple-400 uppercase tracking-wider">Social</span>
            </div>
            <h1 className="text-3xl font-bold text-white">Messages & Friends</h1>
            <p className="text-white/40 mt-1 text-sm">Connect, chat, and manage your friendships</p>
          </div>

          <Link href="/">
            <Button variant="ghost" size="sm" className="text-white/50 hover:text-white hover:bg-white/5 gap-2 rounded-xl">
              <ArrowLeft className="w-4 h-4" />
              <span className="hidden sm:inline">Back</span>
            </Button>
          </Link>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="bg-white/5 border border-white/10 rounded-xl p-1 mb-6 inline-flex gap-1">

            <TabsTrigger value="messages" className="rounded-lg text-xs px-4 py-2 data-[state=active]:bg-purple-500/20 data-[state=active]:text-purple-300 text-white/50 hover:text-white">
              <MessageCircle className="w-3.5 h-3.5 mr-1.5" />
              Messages
            </TabsTrigger>

            <TabsTrigger value="friends" className="rounded-lg text-xs px-4 py-2 data-[state=active]:bg-purple-500/20 data-[state=active]:text-purple-300 text-white/50 hover:text-white">
              <Users className="w-3.5 h-3.5 mr-1.5" />
              Friends
            </TabsTrigger>

            <TabsTrigger value="discover" className="rounded-lg text-xs px-4 py-2 data-[state=active]:bg-purple-500/20 data-[state=active]:text-purple-300 text-white/50 hover:text-white">
              <Search className="w-3.5 h-3.5 mr-1.5" />
              Discover
            </TabsTrigger>

          </TabsList>

          <TabsContent value="messages">
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">

              <div className="lg:col-span-1 space-y-4">
                <FriendRequestList />

                {/* 🔥 FIX HERE */}
                <FriendList
                  onSelectFriend={(friend) => {
                    setSelectedFriend(friend)
                    setActiveTab('messages')
                  }}
                />
              </div>

              <div className="lg:col-span-3">
                <PrivateChat
                  selectedFriend={selectedFriend}
                  onBack={() => setSelectedFriend(null)}
                />
              </div>

            </div>
          </TabsContent>

          <TabsContent value="friends">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">

              <FriendRequestList />

              <FriendList
                onSelectFriend={(friend) => {
                  setSelectedFriend(friend)
                  setActiveTab('messages')
                }}
              />

            </div>
          </TabsContent>

          <TabsContent value="discover">
            <div className="max-w-lg">

              <UserSearch
                onSelectFriend={(friend) => {
                  setSelectedFriend(friend)
                  setActiveTab('messages')
                }}
              />

            </div>
          </TabsContent>

        </Tabs>
      </div>
    </div>
  )
}