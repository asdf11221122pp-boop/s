import { db } from '@/lib/db'

type ParsedBadgeCriteria =
  | { type: 'sell_delivered'; threshold: number }
  | { type: 'purchase_delivered'; threshold: number }
  | { type: 'review'; threshold: number }
  | { type: 'download'; threshold: number }
  | { type: 'following'; threshold: number }
  | { type: 'followers'; threshold: number }
  | { type: 'mystery'; threshold: number }

function parseBadgeIds(raw: unknown): string[] {
  if (Array.isArray(raw)) return raw.filter((x) => typeof x === 'string')
  if (typeof raw === 'string') {
    try {
      const parsed = JSON.parse(raw)
      if (Array.isArray(parsed)) return parsed.filter((x) => typeof x === 'string')
    } catch {
      // ignore
    }
  }
  return []
}

function parseCriteria(criteria: string): ParsedBadgeCriteria | null {
  const c = criteria.trim()
  if (!c) return null

  const firstReview = /first\s+review/i.test(c)
  const firstDownload = /first\s+download/i.test(c)
  const firstFollow = /first\s+follow/i.test(c)
  const firstMystery = /first\s+(mystery|reward)/i.test(c)
  const firstSell = /first\s+sell/i.test(c) || /first\s+order/i.test(c)
  const firstPurchase = /first\s+(purchase|buy)/i.test(c)

  if (firstReview) return { type: 'review', threshold: 1 }
  if (firstDownload) return { type: 'download', threshold: 1 }
  if (firstFollow) return { type: 'following', threshold: 1 }
  if (firstMystery) return { type: 'mystery', threshold: 1 }
  if (firstSell) return { type: 'sell_delivered', threshold: 1 }
  if (firstPurchase) return { type: 'purchase_delivered', threshold: 1 }

  const num = (re: RegExp) => {
    const m = c.match(re)
    if (!m) return null
    const n = Number.parseInt(m[1], 10)
    return Number.isFinite(n) && n > 0 ? n : null
  }

  const sellN = num(/sell\s+(\d+)/i)
  if (sellN !== null) return { type: 'sell_delivered', threshold: sellN }

  const soldN = num(/sold\s+(\d+)/i)
  if (soldN !== null) return { type: 'sell_delivered', threshold: soldN }

  const completeN = num(/complete\s+(\d+)/i)
  if (completeN !== null) return { type: 'sell_delivered', threshold: completeN }

  const deliveredN = num(/deliver(?:ed)?\s+(\d+)/i)
  if (deliveredN !== null) return { type: 'sell_delivered', threshold: deliveredN }

  const purchaseN = num(/purchase[s]?\s+(\d+)/i)
  if (purchaseN !== null) return { type: 'purchase_delivered', threshold: purchaseN }

  const purchasedN = num(/purchased\s+(\d+)/i)
  if (purchasedN !== null) return { type: 'purchase_delivered', threshold: purchasedN }

  const buyN = num(/buy[s]?\s+(\d+)/i)
  if (buyN !== null) return { type: 'purchase_delivered', threshold: buyN }

  const reviewN = num(/review[s]?\s+(\d+)/i)
  if (reviewN !== null) return { type: 'review', threshold: reviewN }

  const downloadN = num(/download[s]?\s+(\d+)/i)
  if (downloadN !== null) return { type: 'download', threshold: downloadN }

  const followingN = num(/following\s+(\d+)/i)
  if (followingN !== null) return { type: 'following', threshold: followingN }

  const followersN = num(/followers\s+(\d+)/i)
  if (followersN !== null) return { type: 'followers', threshold: followersN }

  const followN = num(/follow\s+(\d+)/i)
  if (followN !== null) return { type: 'following', threshold: followN }

  const mysteryN = num(/mystery\s+(\d+)/i)
  if (mysteryN !== null) return { type: 'mystery', threshold: mysteryN }

  const rewardN = num(/reward\s+(\d+)/i)
  if (rewardN !== null) return { type: 'mystery', threshold: rewardN }

  return null
}

async function getMetrics(userId: string, needed: Set<ParsedBadgeCriteria['type']>) {
  const result: Record<string, number> = {}

  const include = <T extends keyof typeof result>(k: T) => needed.has(k as any)

  if (include('sell_delivered' as any)) {
    result.sell_delivered = await db.order.count({ where: { sellerId: userId, status: 'DELIVERED' } })
  }
  if (include('purchase_delivered' as any)) {
    result.purchase_delivered = await db.order.count({ where: { buyerId: userId, status: 'DELIVERED' } })
  }
  if (include('review' as any)) {
    result.review = await db.review.count({ where: { userId } })
  }
  if (include('download' as any)) {
    result.download = await db.download.count({ where: { userId } })
  }
  if (include('following' as any)) {
    result.following = await db.follow.count({ where: { followerId: userId } })
  }
  if (include('followers' as any)) {
    result.followers = await db.follow.count({ where: { followingId: userId } })
  }
  if (include('mystery' as any)) {
    result.mystery = await db.mysteryRewardLog.count({ where: { userId } })
  }

  return result
}

/**
 * Automatic badge awarding for free-text criteria strings entered in the admin panel.
 */
export async function maybeAwardBadges(userId: string) {
  try {
    const user = await db.user.findUnique({
      where: { id: userId },
      select: { badges: true },
    })
    if (!user) return

    const currentIds = parseBadgeIds(user.badges)
    const currentSet = new Set(currentIds)

    const badges = await db.badge.findMany({
      where: { isActive: true, isAutomatic: true },
    })

    const parsed = badges
      .map((b) => ({ badge: b, parsed: b.criteria ? parseCriteria(b.criteria) : null }))
      .filter((x): x is { badge: (typeof badges)[number]; parsed: ParsedBadgeCriteria } => !!x.parsed)

    if (parsed.length === 0) return

    const needed = new Set(parsed.map((x) => x.parsed.type))
    const metrics = await getMetrics(userId, needed)

    const toAdd = parsed
      .filter(({ parsed: p }) => (metrics[p.type] || 0) >= p.threshold)
      .map(({ badge }) => badge.id)
      .filter((id) => !currentSet.has(id))

    if (toAdd.length === 0) return

    await db.user.update({
      where: { id: userId },
      data: { badges: [...currentIds, ...toAdd] },
    })
  } catch {
    // Do not block user actions if badge awarding fails.
  }
}

