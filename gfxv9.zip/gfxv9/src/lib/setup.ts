import { exec } from 'child_process'
import { promisify } from 'util'
import { existsSync } from 'fs'
import path from 'path'
import { db } from './db'

const execAsync = promisify(exec)

export async function setupDatabase(): Promise<void> {
  try {
    console.log('🔍 Checking database setup...')

    const databaseUrl = process.env.DATABASE_URL || ''
    const isSqlite = databaseUrl.toLowerCase().startsWith('file:')

    // For SQLite we can rely on the file existence.
    if (isSqlite) {
      const dbPath = path.join(process.cwd(), 'gfxstore.db')
      const dbExists = existsSync(dbPath)
      if (dbExists) {
        console.log('✅ SQLite database file already exists, skipping setup')
        return
      }
    } else {
      // For Postgres (and others), only run schema/seed if the schema is missing.
      try {
        const user = await db.user.findFirst({
          select: { id: true },
        })
        if (user) {
          console.log('✅ Database schema detected (remote DB), skipping setup')
          return
        }
      } catch (schemaErr) {
        console.log('ℹ️ Database schema not detected yet, will run prisma setup')
      }
    }

    console.log('📦 Setting up database...')

    // Run prisma db push
    console.log('⏳ Creating database schema...')
    await execAsync('npx prisma db push --skip-generate --accept-data-loss', {
      cwd: process.cwd(),
      maxBuffer: 10 * 1024 * 1024,
    })
    console.log('✅ Database schema created')

    // Run prisma seed
    console.log('⏳ Seeding initial data...')
    await execAsync('npx tsx prisma/seed.ts', {
      cwd: process.cwd(),
      maxBuffer: 10 * 1024 * 1024,
    })
    console.log('✅ Database seeded with initial data')

    console.log('🎉 Database setup completed successfully!')
    console.log('📝 Admin credentials:')
    console.log('   Email: kakmare.pa@gmail.com')
    console.log('   Password: akash9x1')
    
  } catch (error) {
    console.error('⚠️  Database setup note:', (error as any)?.message || error)
    console.log('If schema needs setup, run: npm run db:push && npm run db:seed')
    // Don't throw - let server continue running
  }
}
