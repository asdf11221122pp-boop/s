import { db } from '@/lib/db'
import { NextResponse } from 'next/server'

const featureCache = new Map<string, { enabled: boolean; expiry: number }>()
const CACHE_TTL = 30_000

export async function isFeatureEnabled(featureKey: string): Promise<boolean> {
  const cached = featureCache.get(featureKey)
  if (cached && Date.now() < cached.expiry) {
    return cached.enabled
  }

  try {
    const feature = await db.featureToggle.findUnique({
      where: { featureKey },
      select: { isEnabled: true }
    })
    const enabled = feature?.isEnabled ?? true
    featureCache.set(featureKey, { enabled, expiry: Date.now() + CACHE_TTL })
    return enabled
  } catch {
    return true
  }
}

export function featureDisabledResponse(featureName: string) {
  return NextResponse.json(
    { error: `${featureName} is currently disabled` },
    { status: 403 }
  )
}

export async function checkFeature(featureKey: string, featureName: string) {
  const enabled = await isFeatureEnabled(featureKey)
  if (!enabled) {
    return featureDisabledResponse(featureName)
  }
  return null
}
