import { NextAuthOptions } from 'next-auth'
import CredentialsProvider from 'next-auth/providers/credentials'
import { PrismaAdapter } from '@next-auth/prisma-adapter'
import { db } from '@/lib/db'
import bcrypt from 'bcryptjs'

export const authOptions: NextAuthOptions = {
  adapter: PrismaAdapter(db),
  secret: process.env.NEXTAUTH_SECRET || process.env.SESSION_SECRET,
  providers: [
    CredentialsProvider({
      name: 'credentials',
      credentials: {
        email: { label: 'Email', type: 'email' },
        password: { label: 'Password', type: 'password' }
      },
      async authorize(credentials) {
        if (!credentials?.email || !credentials?.password) {
          return null
        }

        try {
          const user = await db.user.findUnique({
            where: {
              email: credentials.email.toLowerCase()
            }
          })

          if (!user || !user.password) {
            return null
          }

          const isPasswordValid = await bcrypt.compare(
            credentials.password,
            user.password
          )

          if (!isPasswordValid) {
            return null
          }

          return {
            id: user.id,
            email: user.email,
            username: user.username,
            role: user.role,
          }
        } catch (error) {
          console.error('Auth error:', error instanceof Error ? error.message : String(error))
          return null
        }
      }
    })
  ],
  session: {
    strategy: 'jwt'
  },
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.role = user.role
        token.username = user.username
        token.avatar = (user as any).avatar || null
      }
      return token
    },
    async session({ session, token }) {
      if (token) {
        session.user.id = token.sub!
        session.user.username = token.username as string
        const dbUser = await db.user.findUnique({
          select: { role: true, avatar: true, username: true },
          where: { id: token.sub! }
        })
        session.user.role = dbUser?.role || (token.role as string)
        if (dbUser?.username) session.user.username = dbUser.username
        if (dbUser?.avatar) {
          session.user.image = dbUser.avatar
        } else if (token.avatar) {
          session.user.image = token.avatar as string
        }
      }
      return session
    }
  },
  pages: {
    signIn: '/auth/signin',
  }
}
