import Link from 'next/link'
import { Globe, Users, Zap, Shield, Heart, Package, MessageCircle, Upload } from 'lucide-react'

export function Footer() {
  return (
    <footer className="relative bg-[#070710] border-t border-white/[0.04] text-white overflow-hidden">
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute -left-40 top-20 w-80 h-80 rounded-full bg-purple-500/[0.03] blur-3xl" />
        <div className="absolute -right-40 bottom-10 w-80 h-80 rounded-full bg-blue-500/[0.03] blur-3xl" />
      </div>

      <div className="container mx-auto px-4 py-12 md:py-16 relative z-10">
        {/* Feature cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-12">
          {[
            { icon: <Globe className="h-5 w-5 text-blue-400" />, title: 'Global Access', desc: 'Available 24/7 worldwide', color: 'from-blue-500/10 to-blue-500/5 border-blue-500/10 hover:border-blue-500/30' },
            { icon: <Users className="h-5 w-5 text-purple-400" />, title: 'Community', desc: 'Thousands of creators', color: 'from-purple-500/10 to-purple-500/5 border-purple-500/10 hover:border-purple-500/30' },
            { icon: <Zap className="h-5 w-5 text-yellow-400" />, title: 'Lightning Fast', desc: 'Instant downloads', color: 'from-yellow-500/10 to-yellow-500/5 border-yellow-500/10 hover:border-yellow-500/30' },
            { icon: <Shield className="h-5 w-5 text-green-400" />, title: 'Secure', desc: 'Protected & safe', color: 'from-green-500/10 to-green-500/5 border-green-500/10 hover:border-green-500/30' },
          ].map((f, i) => (
            <div key={i} className={`group p-4 rounded-2xl bg-gradient-to-br ${f.color} border transition-all duration-300`}>
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-xl bg-white/[0.04] group-hover:scale-105 transition-transform">{f.icon}</div>
                <div>
                  <h4 className="font-semibold text-sm text-white">{f.title}</h4>
                  <p className="text-[11px] text-white/30">{f.desc}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="h-px bg-gradient-to-r from-transparent via-white/[0.06] to-transparent mb-10" />

        {/* Links grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-8 mb-10">
          {[
            { title: 'Product', links: [
              { href: '/browse', label: 'Browse' }, { href: '/categories', label: 'Categories' },
              { href: '/creators', label: 'Creators' }, { href: '/upload', label: 'Upload' },
              { href: '/freebies', label: 'Freebies' },
            ]},
            { title: 'Support', links: [
              { href: '/help', label: 'Help Center' }, { href: '/docs', label: 'Documentation' },
              { href: '/contact', label: 'Contact Us' }, { href: '/status', label: 'Status' },
            ]},
            { title: 'Legal', links: [
              { href: '/privacy', label: 'Privacy Policy' }, { href: '/terms', label: 'Terms of Service' },
              { href: '/guidelines', label: 'Guidelines' }, { href: '/dmca', label: 'DMCA' },
            ]},
            { title: 'Connect', links: [
              { href: 'https://discord.com', label: 'Discord', external: true },
              { href: 'https://github.com', label: 'GitHub', external: true },
              { href: 'https://twitter.com', label: 'Twitter / X', external: true },
            ]},
          ].map((section, i) => (
            <div key={i}>
              <h4 className="font-semibold text-xs text-white/50 uppercase tracking-wider mb-3">{section.title}</h4>
              <ul className="space-y-2">
                {section.links.map(link => (
                  <li key={link.href}>
                    <Link href={link.href} {...(link.external ? { target: '_blank', rel: 'noopener noreferrer' } : {})}
                      className="text-sm text-white/30 hover:text-purple-300 transition-colors">
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom bar */}
        <div className="border-t border-white/[0.04] pt-6 flex flex-col sm:flex-row justify-between items-center gap-3">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-md bg-gradient-to-br from-purple-500 to-blue-600 flex items-center justify-center">
              <Zap className="w-3 h-3 text-white" />
            </div>
            <span className="text-sm text-white/40">GfxStore &copy; {new Date().getFullYear()}</span>
          </div>
          <p className="text-xs text-white/20">Made with <Heart className="w-3 h-3 text-red-400/60 inline" /> for the Minecraft community</p>
        </div>
      </div>
    </footer>
  )
}
