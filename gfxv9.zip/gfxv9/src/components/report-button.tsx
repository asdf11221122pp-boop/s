'use client'

import { useState } from 'react'
import { useSession } from 'next-auth/react'
import { Button } from '@/components/ui/button'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Flag, Loader2, X } from 'lucide-react'
import { toast } from 'sonner'

const REPORT_REASONS = [
  { value: 'STOLEN_CONTENT', label: 'Stolen / Plagiarized Content' },
  { value: 'MISLEADING', label: 'Misleading Description' },
  { value: 'INAPPROPRIATE', label: 'Inappropriate Content' },
  { value: 'SPAM', label: 'Spam / Duplicate' },
  { value: 'MALWARE', label: 'Malware / Harmful Content' },
  { value: 'COPYRIGHT', label: 'Copyright Infringement' },
  { value: 'OTHER', label: 'Other' },
]

interface ReportButtonProps {
  itemId?: string
  reportedUserId?: string
  itemTitle?: string
}

export function ReportButton({ itemId, reportedUserId, itemTitle }: ReportButtonProps) {
  const { data: session } = useSession()
  const [open, setOpen] = useState(false)
  const [reason, setReason] = useState('')
  const [description, setDescription] = useState('')
  const [submitting, setSubmitting] = useState(false)

  if (!session) return null

  const handleSubmit = async () => {
    if (!reason) { toast.error('Please select a reason'); return }
    setSubmitting(true)
    try {
      const res = await fetch('/api/report', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ itemId, reportedUserId, reason, description })
      })
      const data = await res.json()
      if (res.ok) {
        toast.success('Report submitted. Thank you for helping keep the community safe.')
        setOpen(false); setReason(''); setDescription('')
      } else {
        toast.error(data.error || 'Failed to submit report')
      }
    } catch { toast.error('Failed to submit report') } finally { setSubmitting(false) }
  }

  return (
    <>
      <Button
        variant="ghost"
        size="sm"
        onClick={() => setOpen(true)}
        className="h-8 text-xs text-red-400/70 hover:text-red-400 hover:bg-red-500/10 gap-1.5 rounded-lg"
      >
        <Flag className="h-3 w-3" />
        Report
      </Button>

      {open && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={() => setOpen(false)} />
          <div className="relative bg-[#0f0f1a] border border-white/10 rounded-2xl p-6 w-full max-w-md shadow-2xl">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Flag className="h-4 w-4 text-red-400" />
                <h2 className="font-semibold text-white">Report {itemTitle || 'this content'}</h2>
              </div>
              <button onClick={() => setOpen(false)} className="text-white/30 hover:text-white/70 transition-colors">
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="space-y-4">
              <div>
                <Label className="text-white/60 text-sm mb-2 block">Reason *</Label>
                <Select onValueChange={setReason}>
                  <SelectTrigger className="bg-white/5 border-white/10 text-white rounded-xl h-10">
                    <SelectValue placeholder="Select a reason..." />
                  </SelectTrigger>
                  <SelectContent className="bg-[#0f0f1a] border-white/10">
                    {REPORT_REASONS.map(r => (
                      <SelectItem key={r.value} value={r.value} className="text-white/80 hover:bg-white/5">{r.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-white/60 text-sm mb-2 block">Additional Details (optional)</Label>
                <Textarea
                  value={description}
                  onChange={e => setDescription(e.target.value)}
                  placeholder="Provide more context about your report..."
                  className="bg-white/5 border-white/10 text-white placeholder:text-white/30 rounded-xl min-h-[80px] resize-none text-sm"
                />
              </div>
              <div className="flex gap-2">
                <Button onClick={handleSubmit} disabled={submitting} className="flex-1 h-10 bg-red-500/20 hover:bg-red-500/30 text-red-400 border-0 rounded-xl gap-2">
                  {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Flag className="h-4 w-4" />}
                  Submit Report
                </Button>
                <Button variant="ghost" onClick={() => setOpen(false)} className="h-10 text-white/50 hover:bg-white/5 rounded-xl px-4">Cancel</Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
