'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Check, X, Clock, UserCheck, Loader2 } from 'lucide-react'
import { toast } from 'sonner'

interface FriendRequest {
  id: string
  senderId: string
  receiverId: string
  status: string
  createdAt: string
  sender?: { id: string; username: string; avatar?: string; bio?: string }
  receiver?: { id: string; username: string; avatar?: string; bio?: string }
}

export function FriendRequestList() {
  const [received, setReceived] = useState<FriendRequest[]>([])
  const [sent, setSent] = useState<FriendRequest[]>([])
  const [loading, setLoading] = useState(true)
  const [actionLoading, setActionLoading] = useState<string | null>(null)

  useEffect(() => {
    fetchRequests()
    const interval = setInterval(fetchRequests, 15000)
    return () => clearInterval(interval)
  }, [])

  const fetchRequests = async () => {
    try {
      const res = await fetch('/api/friends/requests')
      if (res.ok) {
        const data = await res.json()
        setReceived(data.received || [])
        setSent(data.sent || [])
      }
    } catch (error) {
      console.error('Error fetching requests:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleAccept = async (requestId: string) => {
    setActionLoading(requestId)
    try {
      const res = await fetch('/api/friends/accept-request', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ requestId })
      })
      if (res.ok) {
        setReceived(prev => prev.filter(r => r.id !== requestId))
        toast.success('Friend request accepted!')
      } else {
        const data = await res.json()
        toast.error(data.error || 'Failed to accept request')
      }
    } catch { toast.error('Error accepting request') } finally { setActionLoading(null) }
  }

  const handleReject = async (requestId: string) => {
    setActionLoading(requestId)
    try {
      const res = await fetch('/api/friends/reject-request', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ requestId })
      })
      if (res.ok) {
        setReceived(prev => prev.filter(r => r.id !== requestId))
        setSent(prev => prev.filter(r => r.id !== requestId))
        toast.success('Request declined')
      } else { toast.error('Failed to decline request') }
    } catch { toast.error('Error declining request') } finally { setActionLoading(null) }
  }

  return (
    <div className="bg-slate-900 border border-white/10 rounded-2xl overflow-hidden">
      <div className="p-4 border-b border-white/10 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <UserCheck className="w-4 h-4 text-purple-400" />
          <span className="font-semibold text-white text-sm">Friend Requests</span>
        </div>
        {received.length > 0 && (
          <Badge className="bg-red-500/20 text-red-400 border-red-500/30 text-xs">
            {received.length} new
          </Badge>
        )}
      </div>

      <Tabs defaultValue="received" className="w-full">
        <TabsList className="w-full grid grid-cols-2 bg-white/5 rounded-none border-b border-white/10 h-9">
          <TabsTrigger value="received" className="rounded-none text-xs data-[state=active]:bg-purple-500/20 data-[state=active]:text-purple-300">
            Received {received.length > 0 && <span className="ml-1 bg-red-500 text-white text-[9px] rounded-full px-1">{received.length}</span>}
          </TabsTrigger>
          <TabsTrigger value="sent" className="rounded-none text-xs data-[state=active]:bg-purple-500/20 data-[state=active]:text-purple-300">
            Sent {sent.length > 0 && <span className="ml-1 bg-slate-500 text-white text-[9px] rounded-full px-1">{sent.length}</span>}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="received" className="m-0 max-h-64 overflow-y-auto">
          {loading ? (
            <div className="flex items-center justify-center py-6">
              <Loader2 className="w-5 h-5 animate-spin text-purple-400" />
            </div>
          ) : received.length === 0 ? (
            <div className="py-6 text-center">
              <UserCheck className="w-8 h-8 mx-auto text-white/20 mb-2" />
              <p className="text-sm text-white/40">No pending requests</p>
            </div>
          ) : (
            <div className="p-2 space-y-2">
              {received.map(req => (
                <div key={req.id} className="flex items-center gap-3 p-2 rounded-xl bg-white/5">
                  <Avatar className="h-8 w-8 flex-shrink-0">
                    <AvatarImage src={req.sender?.avatar || undefined} />
                    <AvatarFallback className="bg-purple-500/20 text-purple-300 text-xs">
                      {req.sender?.username?.slice(0, 2).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-white truncate">{req.sender?.username}</p>
                    <p className="text-xs text-white/40 truncate">{req.sender?.bio || 'Wants to be friends'}</p>
                  </div>
                  <div className="flex gap-1 flex-shrink-0">
                    <Button
                      size="icon"
                      className="h-7 w-7 bg-green-500/20 hover:bg-green-500 text-green-400 hover:text-white border-0 rounded-lg"
                      onClick={() => handleAccept(req.id)}
                      disabled={actionLoading === req.id}
                    >
                      {actionLoading === req.id ? <Loader2 className="w-3 h-3 animate-spin" /> : <Check className="w-3 h-3" />}
                    </Button>
                    <Button
                      size="icon"
                      variant="ghost"
                      className="h-7 w-7 text-red-400 hover:bg-red-500/20 rounded-lg"
                      onClick={() => handleReject(req.id)}
                      disabled={actionLoading === req.id}
                    >
                      <X className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="sent" className="m-0 max-h-64 overflow-y-auto">
          {loading ? (
            <div className="flex items-center justify-center py-6">
              <Loader2 className="w-5 h-5 animate-spin text-purple-400" />
            </div>
          ) : sent.length === 0 ? (
            <div className="py-6 text-center">
              <Clock className="w-8 h-8 mx-auto text-white/20 mb-2" />
              <p className="text-sm text-white/40">No sent requests</p>
            </div>
          ) : (
            <div className="p-2 space-y-2">
              {sent.map(req => (
                <div key={req.id} className="flex items-center gap-3 p-2 rounded-xl bg-white/5">
                  <Avatar className="h-8 w-8 flex-shrink-0">
                    <AvatarImage src={req.receiver?.avatar || undefined} />
                    <AvatarFallback className="bg-blue-500/20 text-blue-300 text-xs">
                      {req.receiver?.username?.slice(0, 2).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-white truncate">{req.receiver?.username}</p>
                    <div className="flex items-center gap-1">
                      <Clock className="w-3 h-3 text-yellow-400" />
                      <p className="text-xs text-yellow-400">Pending</p>
                    </div>
                  </div>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-6 text-xs text-red-400 hover:bg-red-500/20 px-2"
                    onClick={() => handleReject(req.id)}
                    disabled={actionLoading === req.id}
                  >
                    Cancel
                  </Button>
                </div>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}
