'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { MessageCircle, Search, Users, Loader2 } from 'lucide-react'

interface Friend {
  id: string
  username: string
  avatar?: string
  bio?: string
  isActive: boolean
}

interface FriendListProps {
  onSelectFriend?: (friend: Friend) => void
}

export function FriendList({ onSelectFriend }: FriendListProps) {
  const [friends, setFriends] = useState<Friend[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState('')
  const [page, setPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [total, setTotal] = useState(0)
  const [limit] = useState(30)

  useEffect(() => { fetchFriends(1) }, [])

  const fetchFriends = async (pageNum: number) => {
    try {
      setLoading(true)
      const res = await fetch(`/api/friends/list?page=${pageNum}&limit=${limit}`)
      if (res.ok) {
        const data = await res.json()
        setFriends(data.friends || [])
        setTotal(data.total || 0)
        setTotalPages(data.totalPages || 1)
        setPage(pageNum)
      } else {
        console.error('Failed to fetch friends:', res.status)
      }
    } catch (error) {
      console.error('Error fetching friends:', error)
    } finally { setLoading(false) }
  }

  const handleNextPage = () => {
    if (page < totalPages) {
      fetchFriends(page + 1)
    }
  }

  const handlePreviousPage = () => {
    if (page > 1) {
      fetchFriends(page - 1)
    }
  }

  const filteredFriends = friends.filter(f =>
    f.username.toLowerCase().includes(searchQuery.toLowerCase())
  )

  return (
    <div className="bg-white/[0.03] border border-white/8 rounded-2xl overflow-hidden">
      <div className="p-4 border-b border-white/10 flex items-center gap-2">
        <Users className="w-4 h-4 text-blue-400" />
        <span className="font-semibold text-white text-sm">Friends</span>
        <span className="text-xs text-white/40">({total})</span>
      </div>

      <div className="p-3">
        <div className="relative mb-3">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-white/30" />
          <Input
            placeholder="Search friends..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="pl-9 h-9 bg-white/5 border-white/10 text-white placeholder:text-white/30 text-sm rounded-xl"
          />
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="w-5 h-5 animate-spin text-purple-400" />
          </div>
        ) : filteredFriends.length === 0 ? (
          <div className="text-center py-8">
            <Users className="w-8 h-8 mx-auto text-white/15 mb-2" />
            <p className="text-sm text-white/30">{friends.length === 0 ? 'No friends yet' : 'No matches'}</p>
          </div>
        ) : (
          <div className="space-y-1 max-h-64 overflow-y-auto">
            {filteredFriends.map(friend => (
              <div
                key={friend.id}
                className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-white/5 transition-colors cursor-pointer"
                onClick={() => onSelectFriend?.(friend)}
              >
                <Avatar className="h-8 w-8 flex-shrink-0">
                  {friend.avatar && <AvatarImage src={friend.avatar} alt={friend.username} onError={(e) => {e.currentTarget.style.display = 'none'}} />}
                  <AvatarFallback className="bg-blue-500/20 text-blue-300 text-xs">{friend.username.slice(0, 2).toUpperCase()}</AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-white text-sm truncate">{friend.username}</p>
                  <div className="flex items-center gap-1.5">
                    <span className={`w-1.5 h-1.5 rounded-full ${friend.isActive ? 'bg-green-400' : 'bg-white/20'}`} />
                    <p className="text-xs text-white/40">{friend.isActive ? 'Online' : 'Offline'}</p>
                  </div>
                </div>
                <Button
                  size="sm"
                  className="h-7 w-7 p-0 text-purple-400 hover:text-purple-300 hover:bg-purple-500/20 bg-purple-500/10 rounded-lg flex-shrink-0 transition-all duration-200"
                  onClick={e => { e.stopPropagation(); onSelectFriend?.(friend) }}
                  title="Send message"
                >
                  <MessageCircle className="w-3.5 h-3.5" />
                </Button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Pagination Controls */}
      {total > limit && (
        <div className="border-t border-white/10 p-3 flex items-center justify-between bg-white/[0.02]">
          <Button
            size="sm"
            variant="ghost"
            onClick={handlePreviousPage}
            disabled={page === 1}
            className="h-8 text-xs text-white/70 hover:text-white hover:bg-white/10 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            ← Previous
          </Button>
          <span className="text-xs text-white/50">
            Page {page} of {totalPages}
          </span>
          <Button
            size="sm"
            variant="ghost"
            onClick={handleNextPage}
            disabled={page === totalPages}
            className="h-8 text-xs text-white/70 hover:text-white hover:bg-white/10 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Next →
          </Button>
        </div>
      )}
    </div>
  )
}
