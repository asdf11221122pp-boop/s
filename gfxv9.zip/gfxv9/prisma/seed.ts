import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'

const db = new PrismaClient()

async function main() {
  try {
    const adminExists = await db.user.findUnique({
      where: { email: 'kakmare.pa@gmail.com' }
    })

    const hashedPassword = await bcrypt.hash('akash9x1', 12)

    if (!adminExists) {
      console.log('Creating admin user...')
      await db.user.create({
        data: {
          email: 'kakmare.pa@gmail.com',
          username: 'admin',
          password: hashedPassword,
          role: 'ADMIN',
          walletBalance: 1000
        }
      })
    } else {
      const needsHash = !adminExists.password?.startsWith('$2')
      if (needsHash) {
        console.log('Updating admin password hash...')
        await db.user.update({
          where: { email: 'kakmare.pa@gmail.com' },
          data: { password: hashedPassword }
        })
      }
      console.log('Admin user already exists')
    }

    const membershipExists = await db.membership.findFirst()

    if (!membershipExists) {
      console.log('Creating memberships...')
      await db.membership.createMany({
        data: [
          {
            name: 'Basic',
            roleName: 'USER',
            description: 'Get started with basic features',
            price: 9.99,
            color: '#3b82f6',
            sortOrder: 1,
            isActive: true,
            features: ['Basic support', 'Standard features']
          },
          {
            name: 'Pro',
            roleName: 'PRO',
            description: 'Advanced features for creators',
            price: 19.99,
            color: '#8b5cf6',
            sortOrder: 2,
            isActive: true,
            features: ['Priority support', 'Advanced features', 'Custom branding']
          },
          {
            name: 'Premium',
            roleName: 'PREMIUM',
            description: 'All features unlocked',
            price: 49.99,
            color: '#f59e0b',
            sortOrder: 3,
            isActive: true,
            features: ['24/7 support', 'All features', 'Custom domain', 'API access']
          }
        ]
      })
    } else {
      console.log('Memberships already exist')
    }

    const categoryExists = await db.category.findFirst()
    if (!categoryExists) {
      console.log('Creating categories...')
      await db.category.createMany({
        data: [
          { name: 'Skins', slug: 'skins', description: 'Minecraft character skins' },
          { name: 'Textures', slug: 'textures', description: 'Texture packs' },
          { name: 'Mods', slug: 'mods', description: 'Game modifications' }
        ]
      })
    }

    console.log('✅ Database seeded successfully')
  } catch (error) {
    console.error('Seed error:', error)
    process.exit(1)
  } finally {
    await db.$disconnect()
  }
}

main()
