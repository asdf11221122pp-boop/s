# GFXv9 Store — Installation & Setup Guide

GFXv9 Store is a full-featured digital marketplace for selling GFX templates, graphics, and design assets. Built with Next.js 15, PostgreSQL, and real-time WebSocket support.

---

## Requirements

Before starting, make sure your VPS has:

| Requirement | Version |
|---|---|
| Node.js | 18.x or 20.x (recommended) |
| npm / pnpm | pnpm 8+ recommended |
| PostgreSQL | 14+ |
| Git | any |

---

## Step 1 — Install pnpm (if not installed)

```bash
npm install -g pnpm
```

---

## Step 2 — Clone / Upload Files

If using Git:
```bash
git clone <your-repo-url> gfxv9
cd gfxv9
```

Or upload the zip and extract:
```bash
unzip gfxv9.zip -d gfxv9
cd gfxv9
```

---

## Step 3 — Install Dependencies

```bash
pnpm install
```

This installs all packages for the entire monorepo (frontend, backend, shared libs).

---

## Step 4 — Setup PostgreSQL Database

Create a database on your VPS:

```bash
sudo -u postgres psql
```

```sql
CREATE DATABASE gfxv9;
CREATE USER gfxuser WITH PASSWORD 'your_strong_password_here';
GRANT ALL PRIVILEGES ON DATABASE gfxv9 TO gfxuser;
\q
```

---

## Step 5 — Configure Environment Variables

Go into the main app directory:

```bash
cd artifacts/gfxv9
```

Create a `.env` file:

```bash
nano .env
```

Paste the following (fill in your values):

```env
# ─── DATABASE ────────────────────────────────────────────
DATABASE_URL="postgresql://gfxuser:your_strong_password_here@localhost:5432/gfxv9"

# ─── AUTH SECRETS ─────────────────────────────────────────
# Generate a strong random string (run: openssl rand -hex 32)
SESSION_SECRET="paste_your_generated_secret_here"
NEXTAUTH_SECRET="paste_same_or_different_secret_here"

# ─── SITE URL ─────────────────────────────────────────────
# Replace with your actual domain or server IP
NEXTAUTH_URL="https://yourdomain.com"

# ─── PORT ─────────────────────────────────────────────────
PORT=5000

# ─── NODE ENVIRONMENT ─────────────────────────────────────
NODE_ENV=production
```

**Generate a strong secret:**
```bash
openssl rand -hex 32
```

Go back to project root:
```bash
cd ../..
```

---

## Step 6 — Setup Database Tables

This creates all necessary database tables automatically:

```bash
pnpm --filter @workspace/gfxv9 run db:push
```

---

## Step 7 — Create Admin Account

Run the admin creation script:

```bash
cd artifacts/gfxv9
npx tsx create-admin.ts
cd ../..
```

Or you can register normally from the website and then manually update the role in the database:

```sql
UPDATE "User" SET role = 'ADMIN' WHERE email = 'your@email.com';
```

---

## Step 8 — Build the Application

```bash
pnpm --filter @workspace/gfxv9 run build
```

This creates an optimized production build. Takes 1–3 minutes.

---

## Step 9 — Run the Application

**Option A — Direct run (for testing):**
```bash
pnpm --filter @workspace/gfxv9 run start
```

**Option B — PM2 (recommended for production — auto-restart on crash/reboot):**

Install PM2:
```bash
npm install -g pm2
```

Start with PM2:
```bash
pm2 start "pnpm --filter @workspace/gfxv9 run start" --name gfxv9
pm2 save
pm2 startup
```

The site will now run on port 5000 (or whatever PORT you set).

---

## Step 10 — Setup Nginx Reverse Proxy (recommended)

Install Nginx:
```bash
sudo apt install nginx
```

Create config:
```bash
sudo nano /etc/nginx/sites-available/gfxv9
```

Paste:
```nginx
server {
    listen 80;
    server_name yourdomain.com www.yourdomain.com;

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```

Enable site:
```bash
sudo ln -s /etc/nginx/sites-available/gfxv9 /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

---

## Step 11 — SSL Certificate (HTTPS) — Optional but Recommended

```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d yourdomain.com -d www.yourdomain.com
```

---

## Useful PM2 Commands

```bash
pm2 status          # check app status
pm2 logs gfxv9      # view logs
pm2 restart gfxv9   # restart app
pm2 stop gfxv9      # stop app
```

---

## File Upload Storage

Uploaded files are saved to:
```
artifacts/gfxv9/public/uploads/
```

Files persist across server restarts. They are only deleted if you manually delete them or re-upload a fresh copy of the project.

**Backup this folder regularly:**
```bash
cp -r artifacts/gfxv9/public/uploads /your/backup/path/
```

---

## Admin Panel

After setup, access the admin panel at:
```
https://yourdomain.com/admin
```

From the admin panel you can:
- Manage users and roles
- Add/edit memberships (Basic, Pro, Premium)
- Manage badges and mystery rewards
- View orders and custom requests
- Enable/disable maintenance mode

---

## Troubleshooting

**Database connection error:**
- Check `DATABASE_URL` in `.env`
- Make sure PostgreSQL is running: `sudo systemctl status postgresql`

**Port already in use:**
- Change `PORT=5000` in `.env` to another port (e.g. 3000 or 8000)

**Build errors:**
- Make sure Node.js 18+ is installed: `node --version`
- Delete `.next` folder and rebuild: `rm -rf artifacts/gfxv9/.next && pnpm --filter @workspace/gfxv9 run build`

**Prisma errors:**
- Re-run: `pnpm --filter @workspace/gfxv9 run db:push`

---

## Summary (Quick Reference)

```bash
pnpm install
# fill in artifacts/gfxv9/.env
pnpm --filter @workspace/gfxv9 run db:push
pnpm --filter @workspace/gfxv9 run build
pm2 start "pnpm --filter @workspace/gfxv9 run start" --name gfxv9
```

That's it! Your GFXv9 Store should now be live.
